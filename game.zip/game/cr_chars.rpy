# ==========================================================================
#  cr_chars.rpy : ภาพตัวละครและตำแหน่งบนจอ
#  kid  = ตัวเอก (เด็ก)       สีหน้า: normal surprised think worry happy determined
#  zero = เสียงปริศนาจากคอมพิวเตอร์ (หน้าต่างภาพจอ D3)   แบบ: normal smile glitch
#  (ภาพเงาคนเก็บไว้ที่ _archive/zero_shadow นอกโฟลเดอร์ game)
#  ใช้ในบท:  show kid think at kid_pos   แล้วเปลี่ยนสีหน้าระหว่างพูดได้ เช่น  me surprised "..."
# ==========================================================================

image kid normal = "images/chars/kid_normal.png"
image kid surprised = "images/chars/kid_surprised.png"
image kid think = "images/chars/kid_think.png"
image kid worry = "images/chars/kid_worry.png"
image kid happy = "images/chars/kid_happy.png"
image kid determined = "images/chars/kid_determined.png"

# เสียงปริศนา = หน้าต่างภาพจอ CRT (จากภาพฉาก D3) ลอยอยู่มุมขวาบน
# สัญญาณรบกวนวิ่ง และเคอร์เซอร์กะพริบเหมือนมีคนกำลังพิมพ์อยู่
image zero normal:
    "images/chars/zero_win_0.png"
    pause 0.2
    "images/chars/zero_win_1.png"
    pause 0.2
    "images/chars/zero_win_2.png"
    pause 0.2
    "images/chars/zero_win_3.png"
    pause 0.2
    repeat

image zero smile = "zero normal"

image zero glitch:
    "images/chars/zero_win_glitch_0.png"
    pause 0.06
    "images/chars/zero_win_glitch_1.png"
    pause 0.05
    "images/chars/zero_win_glitch_2.png"
    pause 0.07
    repeat

transform kid_pos:
    xanchor 0.0 xpos 30
    yanchor 1.0 ypos 1080
    on show:
        alpha 0.0 xoffset -40
        easein 0.3 alpha 1.0 xoffset 0
    on replace:
        alpha 1.0 xoffset 0

# ไฟจอกระพริบไม่สม่ำเสมอ เหมือนไฟตกในตึกร้าง
transform crt_flicker:
    alpha 1.0
    pause 2.3
    alpha 0.72
    pause 0.05
    alpha 1.0
    pause 0.6
    alpha 0.85
    pause 0.04
    alpha 1.0
    pause 3.4
    alpha 0.6
    pause 0.03
    alpha 1.0
    pause 0.08
    alpha 0.8
    pause 0.04
    alpha 1.0
    repeat

# หน้าต่างเสียงปริศนา: เปิดขึ้นแบบจอ CRT (เส้นแสงเส้นเดียวแล้วขยาย) และปิดแบบยุบเป็นเส้น
transform zero_pos:
    anchor (0.5, 0.5)
    pos (1540, 570)
    on show:
        alpha 1.0 xzoom 0.0 yzoom 0.01
        linear 0.10 xzoom 1.0
        linear 0.14 yzoom 1.0
        crt_flicker
    on replace:
        alpha 1.0 xzoom 1.0 yzoom 1.0
        crt_flicker
    on hide:
        linear 0.10 yzoom 0.01
        linear 0.08 xzoom 0.0

init python:

    def unk_voice(event, interact=True, **kwargs):
        """เสียงบี๊บสั้นๆ ทุกครั้งที่เสียงปริศนาเริ่มพูด"""
        if event == "show" and interact:
            renpy.sound.play("audio/sfx_blip.ogg", channel="audio")
