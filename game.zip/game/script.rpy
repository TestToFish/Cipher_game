# ==========================================================================
#  script.rpy : เนื้อเรื่องและลำดับเกมของเดโม "Cipher Tower" (ชั้น 10 - 8)
#  บทสนทนาแต่ละจุดสำรวจเขียนเป็น label แยก แก้ไขเนื้อเรื่องได้ที่นี่เลย
# ==========================================================================

define me = Character("เชน", color="#ffd86b", image="kid")
define unk = Character("เสียงปริศนา {size=-12}จากคอมพิวเตอร์{/size}", color="#5be3a1", image="zerowin", callback=unk_voice)

# สถานะเกม (เซฟ/โหลดได้อัตโนมัติ)
default current_room = "f10"
default unlocked = ["f10"]
default items_got = []
default explored = set()
default solved = set()
default intro_seen = set()
default seen_puzzles = set()
default tips_seen = set()

default pz_hint = 0
default pz_msg = ""
default pz_wrong = 0
default pz_walk = False

# สถิติสำหรับหน้าสรุป
default t_start = 0
default wrong_total = 0
default hints_used = 0
default walk_used = 0


# --------------------------------------------------------------------------
#  เริ่มเกม
# --------------------------------------------------------------------------

label start:

    $ t_start = time.time()
    $ current_room = "f10"
    stop music fadeout 2.0

    scene expression BG("images/bg_d1.jpg")
    with fade

    "คืนที่ลมเย็นพัดแรงผิดปกติ ตึกสูงร้างกลางเมืองยืนนิ่งท่ามกลางหมอก"
    "ทั้งตึกมืดสนิท ยกเว้นหน้าต่างบานเดียวที่ชั้นบนสุด มีแสงสีเหลืองอ่อนส่องออกมา"

    scene black
    with fade

    "ความมืด... แล้วก็เสียงฮัมเบาๆ ของเครื่องคอมพิวเตอร์"
    show kid worry at kid_pos
    me "อึก... หัวผมเจ็บไปหมด นี่มันที่ไหนกัน?"

    jump enter_room


# --------------------------------------------------------------------------
#  เข้าห้อง
# --------------------------------------------------------------------------

label enter_room:

    scene expression BG(R(current_room)["bg"])
    with fade
    play music "audio/music_explore.ogg" if_changed fadeout 1.0 fadein 2.0

    if current_room not in intro_seen:
        $ intro_seen.add(current_room)
        if renpy.has_label(R(current_room)["intro"]):
            call expression R(current_room)["intro"]

    jump explore


label intro_f10:
    show kid worry at kid_pos
    "คุณลืมตาขึ้น พบว่าตัวเองอยู่ในห้องแคบๆ ประตูเหล็กถูกล็อกไว้จากด้านนอก"
    me "ผมถูกจับมาขังสินะ... แต่ห้องนี้ดูแปลก ๆ มีทั้งโปสเตอร์ตัวอักษร ชั้นหนังสือ แล้วก็คอมพิวเตอร์เครื่องเก่า"
    me determined "ลองสำรวจดู มองหาเครื่องหมาย ! สิ มันน่าจะมีเบาะแสอยู่"
    call tip_explore
    return


label intro_f9:
    show kid think at kid_pos
    "ชั้น 9 เป็นสำนักงานร้าง ลมเย็นโกรกผ่านหน้าต่างที่แตกเป็นรูหลายบาน กระดาษปลิวว่อนไปทั่ว"
    me "รอบนี้ดูไม่มีโน้ตบอกอะไรเลย... ต้องหาวิธีเอง"
    return


label intro_f8:
    show kid think at kid_pos
    "ชั้น 8 เป็นห้อง IT เสียงพัดลมครางต่ำ ไฟ LED บนตู้เซิร์ฟเวอร์กะพริบเขียวแดง"
    me "ห้องนี้ดูใหม่กว่าสองห้องก่อนหน้า... คนที่ใช้ตึกนี้ต่อน่าจะมาทำงานที่นี่"
    return


# --------------------------------------------------------------------------
#  กล่องแนะนำ (tutorial)
# --------------------------------------------------------------------------

label tip_explore:
    call screen cr_tip("วิธีเล่น\n\n1. คลิกวัตถุหรือเครื่องหมาย ! เพื่อสำรวจ แล้วอ่านบทสนทนา\n2. ความรู้ที่ได้จะเข้าสมุดโน้ต (ปุ่มมุมขวาบน หรือกด N)\n3. เมื่อพร้อม คลิกที่ประตูเพื่อลองถอดรหัส")
    return


label tip_notebook:
    call screen cr_tip("คุณได้ความรู้ชิ้นแรกแล้ว\n\nเปิดสมุดโน้ต (ปุ่มมุมขวาบน หรือกด N) เพื่ออ่านทบทวนได้ทุกเมื่อ ความรู้เหล่านี้จะใช้ถอดรหัสที่ประตู")
    return


# --------------------------------------------------------------------------
#  วนสำรวจห้อง
# --------------------------------------------------------------------------

label explore:

    hide kid
    hide zerowin
    hide zero
    hide drkey
    play music "audio/music_explore.ogg" if_changed fadeout 1.0 fadein 1.5
    call screen cr_explore(current_room)
    $ act = _return

    if act[0] == "travel":
        $ dest = act[1]
        jump travel_to

    if act[0] == "devend":
        jump fend_route

    if act[0] == "spot":
        $ sid = act[1]
        if renpy.has_label(SPOTS[sid]["script"]):
            call expression SPOTS[sid]["script"]
        else:
            call fs_generic(sid)
        $ all_done = finish_spot(sid)

        $ letter_no = SPOTS[sid].get("letter")
        if letter_no and letter_no not in letters_read:
            call show_letter(letter_no)

        if "notebook" not in tips_seen and items_got:
            $ tips_seen.add("notebook")
            call tip_notebook

        if all_done:
            show kid determined at kid_pos
            me "ดูครบทุกจุดแล้ว... ได้เวลาลองถอดรหัสแล้ว"
        jump explore

    jump door_interact


# --------------------------------------------------------------------------
#  ประตู / ปริศนา
# --------------------------------------------------------------------------

label door_interact:

    $ door_pid = door_puzzle(current_room)
    if door_pid is None:
        jump leave_room

    # ชั้น 5: เสียงปริศนายื่นข้อเสนอก่อนให้ลองประตู (ทางแยก A)
    if mode == "full" and current_room == "F5" and "c4" not in flags:
        call fc4

    call run_puzzle(door_pid)
    if _return == "solved":
        if door_puzzle(current_room) is None:
            jump leave_room
        jump door_interact
    jump explore


# เปิดหน้าปริศนาหนึ่งข้อ (ใช้กับประตู ตู้เซฟ ห้องกุญแจหลัก)
# คืนค่า "solved" หรือ "closed"
label run_puzzle(pid):

    $ pz_id = pid
    $ pz_load(pid)
    if pid not in seen_puzzles:
        $ seen_puzzles.add(pid)
        call screen cr_tip(P(pid)["tip"])

    play music "audio/music_puzzle.ogg" if_changed fadeout 1.0 fadein 1.0
    jump run_puzzle_ask


label run_puzzle_ask:

    call screen cr_puzzle(P(pz_id))
    $ guess_text = _return

    # ปิดหน้าปริศนา (รวมกรณีที่หน้าจอคืนค่าว่างกลับมา เช่น หลังกด Ignore ตอนมี error)
    if guess_text is None or guess_text == "__close__":
        $ pz_save(pz_id)
        return "closed"

    # รหัสทดสอบ (ไม่แสดงให้ผู้เล่นเห็น): เปิดเมนู DEV
    if is_dev_code(guess_text):
        $ persistent.dev = True
        play sound "audio/sfx_item.ogg"
        call screen cr_dev(in_puzzle=True)
        if _return == "solve":
            $ guess_text = P(pz_id)["answer"]
        else:
            $ pz_msg = "เปิดโหมดทดสอบแล้ว (ปุ่ม DEV มุมขวาบน)"
            jump run_puzzle_ask

    if normalize(guess_text) == normalize(P(pz_id)["answer"]):
        $ solved.add(pz_id)
        $ pz_msg = ""
        if mode == "full" and not pz_walk and pz_id.startswith("P"):
            $ understand += 1
        $ pz_save(pz_id)
        stop music fadeout 1.0
        play sound "audio/sfx_unlock.ogg"
        if renpy.has_label(P(pz_id)["success"]):
            call expression P(pz_id)["success"]
        return "solved"

    $ pz_wrong += 1
    $ wrong_total += 1
    play sound "audio/sfx_wrong.ogg"

    if normalize(guess_text) == "":
        $ pz_msg = "ยังไม่ได้พิมพ์รหัส"
    elif pz_wrong % 2 == 0:
        $ bump_hint(len(P(pz_id)["hints"]))
        $ pz_msg = "รหัสไม่ถูกต้อง เกมเพิ่มคำใบ้ให้แล้ว ดูด้านล่าง"
    else:
        $ pz_msg = "รหัสไม่ถูกต้อง ลองดูเบาะแสในสมุดโน้ตอีกครั้ง"
    jump run_puzzle_ask


label leave_room:

    $ nxt = R(current_room)["next"]
    if nxt:
        $ floor_no = R(nxt)["floor"]
        call stairs(floor_no)
        $ current_room = nxt
        if nxt not in unlocked:
            $ unlocked.append(nxt)
        jump enter_room

    if mode == "full":
        jump f1_unlocked

    jump ending


# เดินทางกลับไปชั้นที่ผ่านแล้ว (เลือกจากแผนผัง)
label travel_to:
    if dest == current_room:
        jump explore
    $ going_up = R(dest)["floor"] > R(current_room)["floor"]
    call stairs(R(dest)["floor"], going_up)
    $ current_room = dest
    jump enter_room


label stairs(floor_no, up=False):
    scene expression BG("images/bg_d4.jpg")
    with fade
    play sound "audio/sfx_steps.ogg"
    if up:
        "เชนไต่บันไดกลับขึ้นไป เสียงฝีเท้าก้องไปทั่วช่องบันไดมืด"
    else:
        "เชนก้าวลงบันไดทีละขั้น เสียงฝีเท้าก้องไปทั่วช่องบันไดมืด"
    show text "{font=fonts/Loma.otf}{size=96}{color=#ffd86b}ชั้น [floor_no]{/color}{/size}{/font}" as floor_label at truecenter
    with dissolve
    pause 1.5
    hide floor_label
    with dissolve
    return


# --------------------------------------------------------------------------
#  ชั้น 10: จุดสำรวจ
# --------------------------------------------------------------------------

label spot_f10_poster:
    show kid think at kid_pos
    "โปสเตอร์ใบใหญ่แปะอยู่บนผนัง เป็นแถบตัวอักษรสองแถวเรียงขนานกัน"
    me "แถวบนกับแถวล่างเลื่อนไม่ตรงกัน... เหมือนมีคนจงใจเลื่อนไปทีละช่อง"
    "นี่คือหลักการของ Caesar Cipher เลื่อนตัวอักษรไปตามจำนวนที่ตกลงกัน"
    return


label spot_f10_shelf:
    show kid surprised at kid_pos
    "ชั้นหนังสือเก่าๆ เต็มไปด้วยหนังสือเกี่ยวกับรหัสลับและประวัติศาสตร์"
    me "เล่มนี้พูดถึงจูเลียส ซีซาร์... รหัสนี้ใช้กันตั้งแต่สมัยโรมันเลยงั้นเหรอ"
    return


label spot_f10_tally:
    show kid worry at kid_pos
    "รอยขีดเป็นกลุ่มละห้าขีด เรียงเต็มผนังเกือบทั้งด้าน"
    me "มีคนเคยถูกขังที่นี่มาก่อน... นานแค่ไหนกันนะ"
    "ขีดสุดท้ายยังดูใหม่อยู่เลย"
    return


label spot_f10_desk:
    show kid surprised at kid_pos
    "บนโต๊ะมีกระดาษโน้ตแผ่นเล็กแปะอยู่กับจอคอมพิวเตอร์ เขียนด้วยลายมือเร่งรีบ"
    me happy "“ใช้ shift 3 เหมือนเดิม เดี๋ยวก็ลืม”... นี่คือกุญแจของรหัสนี่เอง!"
    return


label solved_door1:
    show kid think at kid_pos
    "ตึก... เสียงกลอนประตูคลายออก"
    me "ESCAPE... ใครตั้งรหัสแบบนี้กัน"
    scene expression BG("images/bg_d3.jpg")
    with dissolve
    play sound "audio/sfx_crt.ogg"
    "จอคอมพิวเตอร์สว่างวาบขึ้นมาเอง ตัวอักษรสีเขียวไหลลงมาทีละบรรทัด"
    unk "เร็วกว่าที่คิดไว้นะ... ยินดีด้วย"
    unk "แต่ชั้นต่อไปไม่ได้ง่ายแบบนี้หรอก"
    show kid surprised at kid_pos
    me "ใคร... ใครอยู่ตรงนั้น!?"
    "จอดับลงอีกครั้ง เหลือเพียงเสียงฮัมของเครื่อง"
    return


# --------------------------------------------------------------------------
#  ชั้น 9: จุดสำรวจ
# --------------------------------------------------------------------------

label spot_f9_board:
    show kid think at kid_pos
    "กระดาษหลายแผ่นถูกแปะไว้ข้างประตู บางแผ่นถูกลมพัดหลุดปลิวไปกลางห้อง"
    me "ทุกแผ่นถูกเข้ารหัสไว้หมด... คนที่นี่ชอบซ่อนข้อความจริงๆ"
    return


label spot_f9_disk:
    show kid surprised at kid_pos
    "บนโต๊ะมีจานทองเหลืองสองชั้นหมุนได้ วางอยู่ใต้โคมไฟ"
    me "ตัวอักษรวงนอกกับวงในหมุนแยกกัน... นี่คือเครื่องมือถอดรหัสซีซาร์ของจริงนี่"
    "คุณลองหมุนดู ตัวอักษรเลื่อนไปทีละช่องตามที่หมุน"
    return


label spot_f9_cabinet:
    show kid think at kid_pos
    "ลิ้นชักตู้เอกสารเปิดค้าง มีแฟ้มรายงานความปลอดภัยโผล่ออกมา"
    me "“รหัสซีซาร์มี key ได้แค่ 25 แบบ ลองทีละตัวก็เจอ”... ใครเขียนรายงานนี้กัน"
    return


label spot_f9_window:
    show kid worry at kid_pos
    "หน้าต่างบานใหญ่ กระจกแตกเป็นรูหลายบาน ลมเย็นพัดกระดาษปลิวไปมา"
    me "สูงขนาดนี้... ข้างล่างมีอะไรบ้างนะ"
    "คุณไม่กล้ามองลงไปนาน"
    return


label solved_door2:
    "เสียงกลอนคลายออก เสียงดังกว่าชั้นบน"
    show kid think at kid_pos
    me "DOWNWARD... ลงไปข้างล่าง งั้นสินะ"
    play sound "audio/sfx_crt.ogg"
    show zerowin normal at zerowin_pos
    unk smile "ลองทุกกุญแจจนเจอ... วิธีที่ดีเลยนะ แต่ไม่เสมอไปหรอก"
    return


# --------------------------------------------------------------------------
#  ชั้น 8: จุดสำรวจ
# --------------------------------------------------------------------------

label spot_f8_rack:
    show kid think at kid_pos
    "หน้าจอเล็กๆ บนตู้แสดงข้อความ: “ข้อมูลทั้งหมดในนี้ถูกเก็บเป็น Base64 ปลอดภัยแน่นอน!”"
    me "อืม... นั่นไม่ใช่ความปลอดภัยเลยนะ นั่นเป็นแค่การแปลงรูปแบบ"
    return


label spot_f8_board:
    show kid happy at kid_pos
    "ไวท์บอร์ดเต็มไปด้วยจุดและขีด เหมือนตัวเลขฐานสอง กับตารางตัวอักษร"
    me "ตัดเป็นชุดละ 6 บิต แล้วดูตาราง... นี่คือวิธีทำ Base64 นี่เอง"
    return


label spot_f8_manual:
    show kid surprised at kid_pos
    "หนังสือคู่มือโปรแกรมเมอร์วางทิ้งไว้บนพื้น เปิดค้างหน้าตาราง ASCII"
    me "A คือ 65, B คือ 66... คอมพิวเตอร์เห็นตัวอักษรเป็นตัวเลขแบบนี้เอง"
    return


label spot_f8_desk:
    show kid think at kid_pos
    "จอคอมพิวเตอร์เปิดไฟล์บันทึกค้างไว้"
    me happy "ผู้ดูแลคนใหม่คิดว่า Base64 ซับซ้อนกว่า Caesar... ผมว่าเขาเข้าใจผิดแล้วล่ะ"
    return


label solved_door3:
    show kid happy at kid_pos
    "ประตูเปิดออก เสียงลมจากช่องบันไดด้านนอกพัดเข้ามา"
    me "FREEDOM... เสรีภาพ"
    return


# --------------------------------------------------------------------------
#  ฉากปิดเดโม + หน้าสรุป
# --------------------------------------------------------------------------

label ending:

    scene expression BG("images/bg_d7.jpg")
    with fade
    play music "audio/music_ending.ogg" fadein 2.0

    "คุณเดินไปที่หน้าต่างที่แตก ก้มมองลงไปตามผนังตึกที่ดิ่งลงสู่ความมืด"
    "ไกลลงไปสุดทาง มีจุดแสงสีแดงดวงเล็กๆ ที่ชั้นล่างสุด"
    show kid worry at kid_pos
    me "ล็อบบี้อยู่ข้างล่างนั่น... ไกลมากเลย"
    play sound "audio/sfx_crt.ogg"
    show zerowin glitch at zerowin_pos
    unk "นี่แค่สามชั้นเอง ยังเหลืออีกเยอะ"
    unk smile "รหัสข้างล่างไม่ใจดีแบบนี้ ลงมาสิ ถ้าคิดว่าไหว"
    me determined "...ได้ จะลงไปให้ถึงให้ได้"
    hide kid
    hide zerowin
    with dissolve

    call screen cr_summary
    if _return == "replay":
        $ renpy.full_restart()

    return
