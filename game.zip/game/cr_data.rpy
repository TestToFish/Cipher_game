# ==========================================================================
#  cr_data.rpy : ข้อมูลของเดโม "Cipher Tower" (ชั้น 10 - 8)
#  ห้อง / จุดสำรวจ / ความรู้ในสมุดโน้ต / ปริศนา / ฟังก์ชันตัวช่วย
#  (ข้อความที่แสดงบนจอห้ามมี [ ] % และ { } นอกจาก tag ของ Ren'Py)
# ==========================================================================

init python:

    import time

    DEMO = True   # เวอร์ชันเต็มจะตั้งเป็น False และเพิ่มชั้น 7-1

    FONT = "fonts/Loma.otf"
    MONO = "fonts/DejaVuSansMono.ttf"

    ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    B64CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    # พิกัดจุดสำรวจวัดจากภาพต้นฉบับขนาด 1672x941 แล้วแปลงเป็น 1920x1080 อัตโนมัติ
    # ถ้าเปลี่ยนภาพใหม่ ปรับ IMG_W / IMG_H หรือแก้กล่อง (x1, y1, x2, y2) ได้เลย
    IMG_W, IMG_H = 1672.0, 941.0
    SX = 1920.0 / IMG_W
    SY = 1080.0 / IMG_H

    def box(x1, y1, x2, y2):
        return {"x": int(x1 * SX), "y": int(y1 * SY),
                "w": int((x2 - x1) * SX), "h": int((y2 - y1) * SY)}

    def spot(sid, label, script, item, b, alert=None):
        """alert = (x, y) จุดกลางของเครื่องหมาย ! ในภาพต้นฉบับ (ไม่ใส่ = เหนือวัตถุ)"""
        d = box(*b)
        d.update({"id": sid, "label": label, "script": script, "item": item})
        if alert:
            d["ax"] = int(alert[0] * SX) - 24
            d["ay"] = int(alert[1] * SY) - 24
        else:
            d["ax"] = d["x"] + d["w"] // 2 - 24
            d["ay"] = d["y"] - 78
        return d

    def BG(path):
        """ยืดภาพพื้นหลังให้เต็มจอเสมอ ไม่ว่าไฟล์จะขนาดเท่าไร (เช่น 1672x941)"""
        return Transform(path, xysize=(config.screen_width, config.screen_height))

    def door_box(b):
        d = box(*b)
        return (d["x"], d["y"], d["w"], d["h"])

    # ----------------------------------------------------------------------
    # ตัวช่วยจัดข้อความ
    # ----------------------------------------------------------------------
    def mono(s, size=26):
        return "{font=" + MONO + "}{size=" + str(size) + "}" + s + "{/size}{/font}"

    def paras(*parts):
        return "\n\n".join(parts)

    def caesar_table():
        shifted = ALPHA[3:] + ALPHA[:3]
        return mono("CODE  : " + shifted + "\nREAL  : " + ALPHA, 24)

    def base64_table():
        rows = []
        for i in range(0, 64, 8):
            rows.append(" ".join(str(i + j).zfill(2) + "=" + B64CHARS[i + j] for j in range(8)))
        return mono("\n".join(rows), 24)

    def ascii_table():
        rows = []
        for i in range(0, 26, 3):
            cells = []
            for j in range(i, min(i + 3, 26)):
                code = 65 + j
                cells.append(ALPHA[j] + "=" + str(code) + " (" + format(code, "08b") + ")")
            rows.append("   ".join(cells))
        return mono("\n".join(rows), 24)

    def normalize(s):
        return "".join(s.split()).upper()

    # ----------------------------------------------------------------------
    # ตรรกะของเครื่องมือในเกม
    # ----------------------------------------------------------------------
    def caesar_dec(ch, s):
        if ch in ALPHA:
            return ALPHA[(ALPHA.index(ch) - s) % 26]
        return ch

    def caesar_text(t, s):
        return "".join(caesar_dec(c, s) for c in t)

    def b64_prefix(cipher, picked):
        """ดัชนีตัวอักษรที่คลิกต่อเนื่องจากตัวซ้ายสุด (ไม่นับ =)"""
        out = []
        i = 0
        while i < len(cipher) and cipher[i] != "=" and i in picked:
            out.append(i)
            i += 1
        return out

    def b64_bits6(ch):
        return format(B64CHARS.index(ch), "06b")

    def b64_bytes(bits):
        res = []
        for k in range(0, len(bits) - 7, 8):
            b = bits[k:k + 8]
            v = int(b, 2)
            res.append((b, v, chr(v) if 32 <= v < 127 else "?"))
        return res

    def bump_hint(maxn):
        global pz_hint, hints_used
        if pz_hint < maxn:
            pz_hint += 1
            hints_used += 1

    def use_walk():
        global pz_walk, walk_used
        if not pz_walk:
            pz_walk = True
            walk_used += 1

    def elapsed_text():
        secs = max(0, int(time.time() - t_start))
        return str(secs // 60) + " นาที " + str(secs % 60) + " วินาที"

    # ----------------------------------------------------------------------
    # ความรู้ (ไอเท็ม) ในสมุดโน้ต
    # ----------------------------------------------------------------------
    ITEMS = {
        "caesar_intro": {
            "title": "Caesar Cipher คืออะไร",
            "body": paras(
                "{b}Caesar Cipher (รหัสซีซาร์){/b}",
                "เป็นรหัสลับที่เก่าแก่ที่สุดแบบหนึ่ง ใช้วิธี {b}เลื่อนตัวอักษร{/b} ไปตามจำนวนที่ตกลงกันไว้ เรียกว่า {b}shift{/b} หรือ {b}key{/b}",
                "ตัวอย่าง shift = 3 : A กลายเป็น D, B เป็น E, C เป็น F ... และ X เป็น A, Y เป็น B, Z เป็น C (วนกลับมาต้น)",
                "แถว CODE คือตัวอักษรที่เห็นในรหัส แถว REAL คือตัวอักษรจริง:",
                caesar_table(),
                "ตัวอย่าง: CAT เข้ารหัสเป็น FDW",
                "การ {b}ถอดรหัส{/b} ทำย้อนกลับ คือถอยกลับ 3 ตัว เช่น F ถอยกลับเป็น C",
            ),
        },
        "caesar_history": {
            "title": "ประวัติของรหัสซีซาร์",
            "body": paras(
                "{b}ทำไมถึงชื่อ Caesar{/b}",
                "เล่ากันว่า {b}จูเลียส ซีซาร์{/b} ผู้นำโรมัน ใช้รหัสนี้ส่งคำสั่งทางทหาร โดยเลื่อนตัวอักษรไป 3 ตำแหน่ง",
                "สมัยนั้นคนส่วนใหญ่อ่านหนังสือไม่ออก แค่นี้ก็ถือว่าลับพอแล้ว แต่ปัจจุบัน {b}ไม่ปลอดภัย{/b} ห้ามใช้ปกป้องข้อมูลจริง",
            ),
        },
        "shift_hint": {
            "title": "โน้ตบนโต๊ะ (shift)",
            "body": paras(
                "{b}โน้ตที่เขียนด้วยลายมือเร่งรีบ{/b}",
                "“ใช้ shift 3 เหมือนเดิม เดี๋ยวก็ลืม เลยจดไว้ตรงนี้”",
                "จำไว้ว่า: ข้อความที่เข้ารหัสด้วย shift 3 ต้อง {b}ถอยกลับ 3{/b} ถึงจะอ่านออก",
                "เช่น H ถอยกลับ 3 ตัว (H, G, F, E) ได้ E",
            ),
        },
        "wheel_howto": {
            "title": "วิธีใช้วงล้อซีซาร์",
            "body": paras(
                "{b}วงล้อซีซาร์ (เครื่องมือในเกม){/b}",
                "1. กดปุ่ม เครื่องมือ (มุมขวาบน หรือในหน้ากรอกรหัส) เพื่อเปิดวงล้อ",
                "2. กดปุ่ม ลด หรือ เพิ่ม เพื่อเปลี่ยนค่า shift แถวบนคือตัวอักษรในรหัส แถวล่างคือตัวอักษรจริง",
                "3. คลิกตัวอักษรของรหัสเพื่อดูว่าถอดได้เป็นตัวอะไร หรือกดแสดงทั้งข้อความ",
                "4. ถ้าไม่รู้ shift ให้ลองหมุนทีละค่าจนอ่านออกเป็นคำ",
            ),
        },
        "brute_force": {
            "title": "Brute force: ลองทุกกุญแจ",
            "body": paras(
                "{b}Brute force{/b}",
                "คือการ {b}ลองทุกกุญแจที่เป็นไปได้{/b} จนกว่าจะเจอ",
                "รหัสซีซาร์มี shift ที่เป็นไปได้แค่ 25 แบบ (1 ถึง 25) ลองครบทุกแบบได้ในไม่กี่นาที แม้ไม่รู้กุญแจก็แกะได้",
                "บทเรียน: ถ้ากุญแจมีน้อยแบบ ก็ไม่ปลอดภัย รหัสสมัยใหม่จึงใช้กุญแจที่ยาวจนลองไม่ครบ",
            ),
        },
        "encoding_intro": {
            "title": "Encoding ไม่ใช่ Encryption",
            "body": paras(
                "{b}Encoding vs Encryption{/b}",
                "{b}Encoding{/b} = แปลงข้อมูลเป็นรูปแบบอื่นเพื่อให้ส่งหรือเก็บสะดวก ใครก็แปลงกลับได้ ไม่มีกุญแจลับ",
                "{b}Encryption{/b} = ทำให้อ่านไม่ได้ ยกเว้นคนที่มีกุญแจ",
                "Base64 เป็น {b}encoding{/b} ไม่ใช่การเข้ารหัสเพื่อความลับ ถ้าเห็นรหัสผ่านถูกเก็บเป็น Base64 แปลว่าไม่ได้ถูกปกป้องเลย",
            ),
        },
        "base64_how": {
            "title": "Base64 ทำงานอย่างไร",
            "body": paras(
                "{b}Base64{/b}",
                "1. แปลงตัวอักษรเป็นรหัส ASCII แล้วเป็นเลขฐานสอง (8 บิตต่อตัว)\n"
                "2. เรียงบิตต่อกัน แล้ว {b}ตัดเป็นชุดละ 6 บิต{/b}\n"
                "3. แต่ละชุด (ค่า 0-63) ไปดูตัวอักษรในตารางด้านล่าง\n"
                "4. ถ้าข้อมูลไม่ครบ 3 ไบต์ จะเติม = ปิดท้าย",
                "ตาราง Base64:",
                base64_table(),
                "ตัวอย่าง: Hi เป็นบิต 01001000 01101001 ตัดชุดละ 6 บิตได้ 010010 000110 100100 (เติม 0 ให้ครบ) ค่า 18, 6, 36 ตัวอักษร S, G, k และเติม = ได้ SGk=",
                "{b}ถอดรหัสทำย้อนกลับ:{/b} ตัวอักษร เป็นเลข 0-63 เป็นบิต 6 ตัว รวมแล้วตัดใหม่ชุดละ 8 บิต เป็นเลข เป็นตัวอักษร ASCII (เครื่องมือ Base64 ในเกมช่วยแปลงให้ ส่วนการคลิกเรียงตัวอักษรคุณเป็นคนทำ)",
            ),
        },
        "ascii_table": {
            "title": "ตาราง ASCII (A-Z)",
            "body": paras(
                "{b}ASCII ตัวพิมพ์ใหญ่{/b}",
                "คอมพิวเตอร์เก็บตัวอักษรเป็นตัวเลข ตัวพิมพ์ใหญ่ A-Z คือ 65-90",
                ascii_table(),
            ),
        },
        "admin_log": {
            "title": "บันทึกของผู้ดูแลคนใหม่",
            "body": paras(
                "{b}บันทึก{/b}",
                "“เจ้าของห้องเดิมใช้ shift cipher ผมว่ามันเชยไป เลยเปลี่ยนมาใช้ Base64 แทน ดูซับซ้อนกว่าเยอะ!”",
                "(เกร็ด: จริงๆ แล้ว Base64 แกะง่ายกว่า Caesar เสียอีก เพราะไม่ต้องใช้กุญแจเลย)",
            ),
        },
    }

    # ----------------------------------------------------------------------
    # ปริศนาประตู
    #   auto  = วงล้อแสดงผลทั้งข้อความอัตโนมัติ (ใช้กับด่าน brute force)
    #   tip   = กล่องแนะนำที่เด้งขึ้นเมื่อเปิดหน้ารหัสครั้งแรก
    #   walk  = "ดูวิธีทำ" แบบทีละขั้น (ปุ่มโผล่เมื่อตอบผิดหลายครั้ง)
    # ----------------------------------------------------------------------
    PUZZLES = {
        "door1": {
            "id": "door1",
            "title": "ประตูชั้น 10",
            "desc": "แผ่นป้ายข้างประตูมีรหัสผ่านที่ถูกเข้ารหัสไว้ ถอดรหัสให้ได้ แล้วพิมพ์คำที่ได้ (ตัวพิมพ์เล็กใหญ่ไม่สำคัญ)",
            "cipher": "HVFDSH",
            "answer": "ESCAPE",
            "auto": False,
            "hints": [
                "ลองดูโน้ตบนโต๊ะและโปสเตอร์ในห้อง มีเรื่อง “การเลื่อนตัวอักษร” อยู่",
                "รหัสนี้เข้ารหัสด้วย shift 3 ดังนั้นต้องถอยกลับ 3 ตัวอักษร",
                "ตัวแรก H ถอยกลับ 3 ตัว (G, F, E) ได้ E ลองทำต่อทีละตัว หรือเปิดวงล้อตั้ง shift = 3",
            ],
            "walk": "1. โน้ตบนโต๊ะบอกว่า shift = 3\n"
                    "2. เปิดเครื่องมือ (วงล้อซีซาร์) แล้วตั้ง shift = 3\n"
                    "3. คลิกตัวอักษรของรหัสทีละตัว: H เป็น E, V เป็น S, F เป็น C, D เป็น A, S เป็น P, H เป็น E\n"
                    "4. อ่านต่อกันได้ ESCAPE",
            "tip": "นี่คือหน้ากรอกรหัสของประตู\n\n"
                   "รหัสด้านบนถูกเข้ารหัสไว้ ใช้ความรู้จากสมุดโน้ตถอดให้ได้ แล้วพิมพ์คำตอบ\n"
                   "กด เครื่องมือ เพื่อเปิดวงล้อซีซาร์ช่วย กด สมุดโน้ต เพื่อดูความรู้ที่เก็บมา\n"
                   "ตอบผิดไม่เสียอะไร และมีคำใบ้ให้เสมอ",
            "success": "solved_door1",
        },
        "door2": {
            "id": "door2",
            "title": "ประตูชั้น 9",
            "desc": "รอบนี้ไม่มีโน้ตบอก shift ลองหมุนวงล้อทีละค่าแล้วดูว่าค่าไหนได้ข้อความที่อ่านออก",
            "cipher": "MXFWFJAM",
            "answer": "DOWNWARD",
            "auto": True,
            "hints": [
                "รหัสนี้ไม่มีโน้ตบอก shift คุณต้องลองเอง ดูเรื่อง Brute force ในสมุดโน้ต",
                "shift ที่เป็นไปได้มีแค่ 1 ถึง 25 หมุนวงล้อทีละหนึ่ง แล้วอ่านข้อความด้านล่าง",
                "ถ้าข้อความที่ได้เป็นคำภาษาอังกฤษที่อ่านออก นั่นคือคำตอบ ลองแถว ๆ shift 9",
            ],
            "walk": "1. เปิดเครื่องมือ (วงล้อซีซาร์) ผลลัพธ์จะแสดงทั้งข้อความอัตโนมัติ\n"
                    "2. กดเพิ่มทีละ 1 จาก shift = 1 แล้วอ่านผล: ส่วนใหญ่จะเป็นตัวอักษรเรียงมั่ว\n"
                    "3. ที่ shift = 9 ข้อความจะอ่านออกเป็นคำ DOWNWARD\n"
                    "4. พิมพ์ DOWNWARD ลงในช่องรหัส",
            "tip": "ด่านนี้ไม่มีโน้ตบอก shift\n\n"
                   "แต่คุณไม่จำเป็นต้องเดา ลองหมุนวงล้อทีละค่า (shift 1 ถึง 25) แล้วอ่านผล\n"
                   "วิธีลองทุกกุญแจแบบนี้เรียกว่า Brute force",
            "success": "solved_door2",
        },
        "door3": {
            "id": "door3",
            "title": "ประตูชั้น 8",
            "desc": "บนจอที่ประตูมีข้อความแปลก ๆ ลงท้ายด้วย == ลองถอดรหัสแล้วพิมพ์คำที่ได้",
            "cipher": "RlJFRURPTQ==",
            "answer": "FREEDOM",
            "auto": False,
            "hints": [
                "เครื่องหมาย = ท้ายข้อความเป็นเบาะแสว่าเป็น Base64 ดูวิธีทำในสมุดโน้ต",
                "แบ่งข้อความเป็นชุดละ 4 ตัวอักษร: RlJF | RURP | TQ==",
                "เปิดเครื่องมือ Base64 แล้วคลิกตัวอักษรเรียงจากซ้ายไปขวา ตัวช่วยจะแปลงเป็นบิตและตัวอักษรให้ ดูผลที่ได้",
            ],
            "walk": "1. R เป็นเลข 17 คือ 010001, l เป็น 37 คือ 100101, J เป็น 9 คือ 001001, F เป็น 5 คือ 000101\n"
                    "2. รวมบิต 010001100101001001000101 ตัดชุดละ 8 บิต: 01000110, 01010010, 01000101\n"
                    "3. เป็นเลข 70, 82, 69 ตาม ASCII คือ F, R, E\n"
                    "4. ชุดถัดไป RURP ได้ E, D, O และ TQ== ได้ M รวมกันเป็น FREEDOM",
            "tip": "ด่านนี้เป็น Base64\n\n"
                   "กด เครื่องมือ เพื่อเปิดตัวช่วย Base64 แล้วคลิกตัวอักษรของรหัสเรียงจากซ้ายไปขวา\n"
                   "ตัวช่วยจะแปลงเป็นบิต รวมกัน แล้วตัดเป็นตัวอักษรให้ดู",
            "success": "solved_door3",
        },
    }

    # ----------------------------------------------------------------------
    # ห้อง / จุดสำรวจ (กล่อง = x1, y1, x2, y2 ในภาพต้นฉบับ 1672x941)
    # ----------------------------------------------------------------------
    ROOMS = {
        "f10": {
            "floor": 10,
            "name": "ชั้น 10: ห้องขัง",
            "bg": "images/bg_d2.jpg",
            "intro": "intro_f10",
            "puzzle": "door1",
            "next": "f9",
            "tool": "wheel",
            "map": (0, 0),
            "door": door_box((1360, 225, 1610, 695)),
            "spots": [
                spot("f10_poster", "โปสเตอร์บนผนัง", "spot_f10_poster", "caesar_intro", (355, 260, 610, 420)),
                spot("f10_shelf", "ชั้นหนังสือ", "spot_f10_shelf", "caesar_history", (635, 220, 840, 695)),
                spot("f10_tally", "รอยขีดบนผนัง", "spot_f10_tally", None, (930, 240, 1265, 395)),
                spot("f10_desk", "โต๊ะและคอมพิวเตอร์", "spot_f10_desk", "shift_hint", (845, 405, 1290, 700), alert=(1215, 465)),
            ],
        },
        "f9": {
            "floor": 9,
            "name": "ชั้น 9: สำนักงานร้าง",
            "bg": "images/bg_d5.jpg",
            "intro": "intro_f9",
            "puzzle": "door2",
            "next": "f8",
            "tool": "wheel",
            "map": (0, 1),
            "door": door_box((1385, 235, 1610, 690)),
            "spots": [
                spot("f9_board", "กระดาษข้างประตู", "spot_f9_board", None, (1295, 395, 1390, 590)),
                spot("f9_disk", "จานรหัสทองเหลือง", "spot_f9_disk", "wheel_howto", (215, 455, 395, 595)),
                spot("f9_cabinet", "ตู้เอกสารเหล็ก", "spot_f9_cabinet", "brute_force", (505, 330, 690, 730)),
                spot("f9_window", "หน้าต่างบานใหญ่", "spot_f9_window", None, (695, 180, 1280, 505)),
            ],
        },
        "f8": {
            "floor": 8,
            "name": "ชั้น 8: ห้อง IT",
            "bg": "images/bg_d6.jpg",
            "intro": "intro_f8",
            "puzzle": "door3",
            "next": None,
            "tool": "b64",
            "map": (0, 2),
            "door": door_box((1370, 190, 1630, 740)),
            "spots": [
                spot("f8_rack", "ตู้เซิร์ฟเวอร์", "spot_f8_rack", "encoding_intro", (100, 50, 480, 780), alert=(290, 120)),
                spot("f8_board", "ไวท์บอร์ด", "spot_f8_board", "base64_how", (505, 250, 970, 555)),
                spot("f8_manual", "หนังสือบนพื้น", "spot_f8_manual", "ascii_table", (530, 770, 960, 850)),
                spot("f8_desk", "คอมพิวเตอร์ผู้ดูแล", "spot_f8_desk", "admin_log", (975, 400, 1355, 760), alert=(1105, 380)),
            ],
        },
    }

    ROOM_ORDER = ["f10", "f9", "f8"]
    START_ROOM = "f10"

    SPOTS = {}
    for _rid in ROOM_ORDER:
        for _s in ROOMS[_rid]["spots"]:
            SPOTS[_s["id"]] = _s

    # ----------------------------------------------------------------------
    # ฟังก์ชันที่ใช้ตอนเล่น (อ่าน/เขียนตัวแปรที่เซฟได้จาก default ใน script.rpy)
    # ----------------------------------------------------------------------
    def unexplored(room_id):
        return [s for s in R(room_id)["spots"] if s["id"] not in explored]

    def finish_spot(sid):
        """เรียกหลังบทสนทนาของจุดสำรวจจบ: บันทึกว่าสำรวจแล้ว + เก็บความรู้
        คืนค่า True ถ้านี่คือจุดสุดท้ายของห้องที่เพิ่งสำรวจครบ"""
        spot_ = SPOTS[sid]
        first_time = sid not in explored
        explored.add(sid)
        item = spot_["item"]
        if item and item not in items_got:
            items_got.append(item)
            renpy.notify("บันทึกลงสมุดโน้ตแล้ว: " + item_info(item)["title"])
            renpy.sound.play("audio/sfx_item.ogg", channel="audio")
        return first_time and not unexplored(current_room) and not door_done(current_room)

    # ----------------------------------------------------------------------
    # ฟอนต์ไทย (ตัวหนา)
    # ----------------------------------------------------------------------
    config.font_replacement_map[FONT, True, False] = ("fonts/Loma-Bold.otf", False, False)

init 1000 python:
    # สไตล์ของ template ตั้งฟอนต์ของตัวเองผ่าน gui.text_properties จึงต้องตั้งทีละสไตล์
    for _name in (
        "default", "say_dialogue", "say_label", "say_thought", "notify_text",
        "button_text", "label_text", "prompt_text", "input", "choice_button_text",
        "navigation_button_text", "main_menu_text", "quick_button_text",
        "game_menu_label_text", "history_text", "history_name_text",
        "slot_button_text", "confirm_prompt_text",
    ):
        try:
            getattr(style, _name).font = FONT
        except Exception:
            pass

    style.default.language = "eastasian"  # ภาษาไทยไม่มีเว้นวรรค ให้ตัดบรรทัดได้ทุกตัวอักษร
    config.window_title = "Cipher Tower"
