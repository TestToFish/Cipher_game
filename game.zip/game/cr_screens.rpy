# ==========================================================================
#  cr_screens.rpy : หน้าจอสำรวจ / สมุดโน้ต / แผนผังตึก / ปริศนา /
#                   วงล้อซีซาร์ / ตัวช่วย Base64 / กล่องแนะนำ / หน้าสรุป
# ==========================================================================

# ---------- สไตล์ ----------

style cr_text is default:
    font "fonts/Loma.otf"
    size 30
    color "#e8e4f5"

style cr_title is cr_text:
    size 46
    color "#ffd86b"
    bold True

style cr_body is cr_text:
    size 30
    line_spacing 8

style cr_muted is cr_text:
    size 26
    color "#8f89a8"

style cr_mono is cr_text:
    font "fonts/DejaVuSansMono.ttf"

style cr_btn is button:
    activate_sound "audio/sfx_click.ogg"
    hover_sound "audio/sfx_hover.ogg"
    background Solid("#1a1626")
    hover_background Solid("#2f2850")
    insensitive_background Solid("#14111d")
    padding (26, 10)

style cr_btn_text is cr_text:
    size 28
    idle_color "#e8e4f5"
    hover_color "#ffd86b"
    insensitive_color "#5a5575"

style cr_vbar is default:
    bar_vertical True
    xsize 12
    base_bar Solid("#2a2440")
    thumb Solid("#6b5bd6")
    hover_thumb Solid("#8f7ff0")
    unscrollable "hide"

style cr_item_btn is button:
    activate_sound "audio/sfx_click.ogg"
    background None
    hover_background Solid("#2a2440")
    selected_background Solid("#3a3260")
    padding (16, 10)
    xfill True

style cr_item_btn_text is cr_text:
    size 28
    idle_color "#e8e4f5"
    hover_color "#ffd86b"
    selected_color "#5be3a1"

style cr_alert is button:
    background Solid("#e0453a")
    hover_background Solid("#ff6a5e")
    padding (18, 2)

style cr_alert_text is cr_text:
    size 46
    bold True
    color "#ffffff"

style cr_hud_frame is empty:
    background Solid("#0d0b14cc")
    padding (22, 8)

style cr_input is input:
    font "fonts/DejaVuSansMono.ttf"
    size 44
    color "#ffffff"
    kerning 4

style cr_letter_btn is button:
    background Solid("#0d0b14")
    hover_background Solid("#2a2440")
    xysize (84, 100)

style cr_letter_btn_text is cr_mono:
    size 56
    color "#5be3a1"
    hover_color "#ffd86b"
    xalign 0.5
    yalign 0.5

style cr_cell is cr_mono:
    size 32
    xsize 48
    text_align 0.5

# ---------- ทรานส์ฟอร์ม ----------

transform cr_bounce:
    yoffset 0
    easein 0.45 yoffset -14
    easeout 0.45 yoffset 0
    repeat

# ---------- กรอบหน้าต่างมาตรฐาน (ใช้ซ้ำ) ----------

screen cr_panel(w, h):
    add Solid("#000000cc")
    frame:
        background Solid("#6b5bd6")
        padding (5, 5)
        align (0.5, 0.5)
        frame:
            background Solid("#1a1626")
            padding (36, 28)
            xysize (w, h)
            transclude

# ---------- ฉากสำรวจห้อง ----------
# คืนค่า: ("spot", id) หรือ ("door",)

screen cr_explore(room_id):

    $ room = ROOMS[room_id]
    $ dx, dy, dw, dh = room["door"]
    $ pid = room["puzzle"]
    $ dsolved = pid in solved

    key "K_n" action Show("cr_notebook")
    key "K_m" action Show("cr_map")

    # จุดสำรวจ: กดได้ทั้งตัววัตถุและเครื่องหมาย !
    for s in room["spots"]:
        button:
            xpos s["x"]
            ypos s["y"]
            xysize (s["w"], s["h"])
            background None
            hover_background Solid("#ffd86b33")
            activate_sound "audio/sfx_spot.ogg"
            action Return(("spot", s["id"]))
            tooltip s["label"]

        if s["id"] not in explored:
            button:
                style "cr_alert"
                xpos s["ax"]
                ypos s["ay"]
                at cr_bounce
                activate_sound "audio/sfx_spot.ogg"
                action Return(("spot", s["id"]))
                tooltip s["label"]
                text "!" style "cr_alert_text"

    # ประตู + ป้ายสถานะ
    button:
        xpos dx
        ypos dy
        xysize (dw, dh)
        background None
        hover_background Solid("#ffd86b33")
        activate_sound ("audio/sfx_click.ogg" if dsolved else "audio/sfx_locked.ogg")
        action Return(("door",))
        tooltip ("ประตู (ปลดล็อกแล้ว)" if dsolved else "ประตู (ล็อกอยู่)")

    frame:
        background Solid("#5be3a1" if dsolved else "#e0453a")
        padding (16, 2)
        xpos dx + dw // 2 - 70
        ypos dy - 56
        text ("ปลดล็อกแล้ว" if dsolved else "ล็อกอยู่") style "cr_text" size 24 color "#0d0b14"

    # HUD
    frame:
        style "cr_hud_frame"
        xpos 30
        ypos 24
        text room["name"] style "cr_text" size 30

    hbox:
        xalign 1.0
        yalign 0.0
        xoffset -30
        yoffset 24
        spacing 14
        if pid in seen_puzzles and not dsolved:
            textbutton "เครื่องมือ" style "cr_btn" action tool_action(room_id)
        textbutton "แผนผัง (M)" style "cr_btn" action Show("cr_map")
        textbutton "สมุดโน้ต (N)" style "cr_btn" action Show("cr_notebook")
        textbutton "ตั้งค่า" style "cr_btn" action Show("cr_settings")

    $ todo_n = len(unexplored(room_id))
    frame:
        style "cr_hud_frame"
        xpos 30
        yalign 1.0
        yoffset -30
        if todo_n > 0:
            text ("จุดที่ยังไม่ได้สำรวจ: " + str(todo_n)) style "cr_muted"
        else:
            text "สำรวจครบแล้ว ลองไปที่ประตู" style "cr_muted" color "#5be3a1"

    $ tip = GetTooltip()
    if tip:
        frame:
            style "cr_hud_frame"
            xalign 0.5
            yalign 1.0
            yoffset -30
            text tip style "cr_text" color "#ffd86b"

# ---------- กล่องแนะนำ (tutorial) ----------

screen cr_tip(msg):

    modal True
    zorder 150
    add Solid("#000000aa")

    frame:
        background Solid("#ffd86b")
        padding (4, 4)
        align (0.5, 0.45)
        frame:
            background Solid("#1a1626")
            padding (44, 34)
            xsize 1100
            vbox:
                spacing 28
                text msg style "cr_body"
                textbutton "เข้าใจแล้ว":
                    style "cr_btn"
                    xalign 1.0
                    action Return()

# ---------- สมุดโน้ต ----------

screen cr_notebook():

    modal True
    zorder 250      # อยู่เหนือทุกหน้า รวมถึงหน้าสรุปผลหลังจบเกม (200)
    default sel = (items_got[-1] if items_got else None)

    on "show" action Play("sound", "audio/sfx_page.ogg")
    key "game_menu" action Hide("cr_notebook")
    key "K_n" action Hide("cr_notebook")

    use cr_panel(1560, 900):

        fixed:
            xysize (1488, 844)

            text "สมุดโน้ต" style "cr_title" pos (0, 0)
            text ("บันทึกแล้ว " + str(len(items_got)) + " หัวข้อ") style "cr_muted" pos (260, 18)

            textbutton "ปิด":
                style "cr_btn"
                xalign 1.0
                ypos 0
                action Hide("cr_notebook")

            # รายการหัวข้อ (ซ้าย)
            frame:
                background Solid("#0d0b14")
                pos (0, 96)
                xysize (480, 740)
                padding (0, 0)
                viewport id "cr_nb_list":
                    xysize (464, 740)
                    mousewheel True
                    draggable True
                    vbox:
                        xsize 464
                        spacing 4
                        if not items_got:
                            null height 16
                            text "ยังไม่มีบันทึก\nสำรวจห้องเพื่อเก็บความรู้" style "cr_muted" xpos 16
                        for iid in items_got:
                            textbutton ITEMS[iid]["title"]:
                                style "cr_item_btn"
                                selected (sel == iid)
                                action SetScreenVariable("sel", iid)
            vbar value YScrollValue("cr_nb_list") style "cr_vbar" pos (466, 96) ysize 740

            # เนื้อหา (ขวา)
            frame:
                background Solid("#0d0b14")
                pos (504, 96)
                xysize (984, 740)
                padding (0, 0)
                viewport id "cr_nb_body":
                    xysize (964, 740)
                    mousewheel True
                    draggable True
                    frame:
                        background None
                        padding (24, 20)
                        xsize 950
                        if sel:
                            text ITEMS[sel]["body"] style "cr_body"
                        else:
                            text "เลือกหัวข้อทางซ้ายเพื่ออ่าน" style "cr_muted"
            vbar value YScrollValue("cr_nb_body") style "cr_vbar" pos (1474, 96) ysize 740

# ---------- แผนผังตึก (แนวตั้ง ชั้นบนอยู่บน) ----------

screen cr_map():

    modal True
    zorder 120

    on "show" action Play("sound", "audio/sfx_page.ogg")
    key "game_menu" action Hide("cr_map")
    key "K_m" action Hide("cr_map")

    use cr_panel(1560, 860):

        text "แผนผังตึก" style "cr_title"

        textbutton "ปิด":
            style "cr_btn"
            xalign 1.0
            action Hide("cr_map")

        # เส้นเชื่อมชั้น
        for i in range(len(ROOM_ORDER) - 1):
            $ a = ROOMS[ROOM_ORDER[i]]["map"]
            $ b = ROOMS[ROOM_ORDER[i + 1]]["map"]
            if a[0] == b[0]:
                add Solid("#4a4270"):
                    xpos 100 + a[0] * 460 + 165
                    ypos 110 + a[1] * 200 + 150
                    xysize (10, (b[1] - a[1]) * 200 - 150)

        for rid in ROOM_ORDER:
            $ r = ROOMS[rid]
            $ opened = rid in unlocked
            $ here = (rid == current_room)
            frame:
                xpos 100 + r["map"][0] * 460
                ypos 110 + r["map"][1] * 200
                xysize (340, 150)
                padding (6, 6)
                background Solid("#ffd86b" if here else ("#4a4270" if opened else "#2a2540"))

                frame:
                    background Solid("#2a2540" if opened else "#15121f")
                    xfill True
                    yfill True
                    padding (14, 8)

                    vbox:
                        spacing 6
                        if opened:
                            text r["name"] style "cr_text" size 26
                            if here:
                                text "(คุณอยู่ที่นี่)" style "cr_text" size 22 color "#ffd86b"
                            $ todo = unexplored(rid)
                            if todo:
                                hbox:
                                    spacing 8
                                    for s in todo:
                                        frame:
                                            background Solid("#e0453a")
                                            padding (12, 0)
                                            text "!" style "cr_alert_text" size 28
                            else:
                                text "สำรวจครบแล้ว" style "cr_text" size 22 color "#5be3a1"
                        else:
                            text "???" style "cr_muted"

        text "! = ยังมีจุดที่ยังไม่ได้สำรวจ  |  ชั้นล่างลงไปคือทางออก":
            style "cr_muted"
            xpos 100
            yalign 1.0

# ---------- ปริศนาประตู ----------
# คืนค่า: คำตอบที่พิมพ์ (string) หรือ "__close__"

screen cr_puzzle(pz):

    modal True
    zorder 100
    default guess = ""

    key "game_menu" action Return("__close__")

    # ถ้านิ่งนาน เกมให้คำใบ้เพิ่มเอง
    timer 40.0 repeat True action Function(bump_hint, len(pz["hints"]))

    use cr_panel(1420, 980):

        vbox:
            spacing 16
            xfill True

            text pz["title"] style "cr_title"
            text pz["desc"] style "cr_body"

            frame:
                background Solid("#0d0b14")
                xfill True
                padding (20, 22)
                text pz["cipher"]:
                    style "cr_mono"
                    size 72
                    color "#5be3a1"
                    kerning 8
                    xalign 0.5

            hbox:
                spacing 16
                frame:
                    background Solid("#0d0b14")
                    xsize 900
                    padding (18, 10)
                    input:
                        style "cr_input"
                        value ScreenVariableInputValue("guess")
                        length 24
                        allow "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/= "
                textbutton "ปลดล็อก" style "cr_btn" action Return(guess)

            if pz_msg:
                text pz_msg style "cr_text" color "#ff7a7a" size 28

            for i in range(pz_hint):
                text ("คำใบ้ " + str(i + 1) + "/" + str(len(pz["hints"])) + ": " + pz["hints"][i]):
                    style "cr_muted"
                    size 25

            if pz_walk:
                frame:
                    background Solid("#0d0b14")
                    xfill True
                    padding (20, 14)
                    text ("วิธีทำทีละขั้น\n" + pz["walk"]) style "cr_text" size 25 color "#ffd86b"

            hbox:
                spacing 14
                textbutton "เครื่องมือ" style "cr_btn" action tool_action(current_room)
                textbutton "สมุดโน้ต" style "cr_btn" action Show("cr_notebook")
                if pz_hint < len(pz["hints"]):
                    textbutton "ขอคำใบ้" style "cr_btn" action Function(bump_hint, len(pz["hints"]))
                if (pz_wrong >= 3 or pz_hint >= len(pz["hints"])) and not pz_walk:
                    textbutton "ดูวิธีทำ" style "cr_btn" action Function(use_walk)
                textbutton "ปิด" style "cr_btn" action Return("__close__")

# ---------- วงล้อซีซาร์ ----------

screen cr_wheel(cipher, auto=False):

    modal True
    zorder 130
    default sh = 0
    default rev = []
    default show_all = auto

    key "game_menu" action Hide("cr_wheel")

    use cr_panel(1560, 900):

        vbox:
            spacing 18
            xfill True

            text "วงล้อซีซาร์" style "cr_title"
            text "เลือกค่า shift แถวบนคือตัวอักษรที่เห็นในรหัส แถวล่างคือตัวอักษรจริงที่ถอดได้" style "cr_muted" size 26

            hbox:
                spacing 24
                textbutton "ลด" style "cr_btn" activate_sound "audio/sfx_tick.ogg" action SetScreenVariable("sh", (sh - 1) % 26)
                text ("shift = " + str(sh)):
                    style "cr_mono"
                    size 44
                    color "#ffd86b"
                    yalign 0.5
                textbutton "เพิ่ม" style "cr_btn" activate_sound "audio/sfx_tick.ogg" action SetScreenVariable("sh", (sh + 1) % 26)

            frame:
                background Solid("#0d0b14")
                padding (20, 14)
                vbox:
                    spacing 4
                    hbox:
                        text "รหัส  " style "cr_text" size 24 xsize 150 yalign 0.5
                        for i in range(26):
                            text ALPHA[(i + sh) % 26] style "cr_cell" color "#5be3a1"
                    hbox:
                        text "จริง  " style "cr_text" size 24 xsize 150 yalign 0.5
                        for i in range(26):
                            text ALPHA[i] style "cr_cell" color "#ffd86b"

            text ("ข้อความรหัสของประตู: คลิกตัวอักษรเพื่อดูว่าถอดได้เป็นตัวอะไร") style "cr_muted" size 26

            hbox:
                spacing 12
                for i, ch in enumerate(cipher):
                    vbox:
                        spacing 6
                        textbutton ch:
                            style "cr_letter_btn"
                            action ToggleSetMembership(rev, i)
                        if show_all or (i in rev):
                            text caesar_dec(ch, sh) style "cr_mono" size 56 color "#ffd86b" xalign 0.5
                        else:
                            text "?" style "cr_mono" size 56 color "#4a4270" xalign 0.5

            hbox:
                spacing 14
                textbutton ("ซ่อนผลทั้งข้อความ" if show_all else "แสดงผลทั้งข้อความ"):
                    style "cr_btn"
                    action ToggleScreenVariable("show_all")
                textbutton "ปิด" style "cr_btn" action Hide("cr_wheel")

# ---------- ตัวช่วย Base64 ----------

screen cr_b64(cipher):

    modal True
    zorder 130
    default picked = []

    key "game_menu" action Hide("cr_b64")

    $ idxs = b64_prefix(cipher, picked)
    $ bits = "".join([b64_bits6(cipher[i]) for i in idxs])
    $ bytes_ = b64_bytes(bits)

    use cr_panel(1560, 900):

        vbox:
            spacing 16
            xfill True

            text "ตัวช่วย Base64" style "cr_title"
            text "คลิกตัวอักษรของรหัสเรียงจากซ้ายไปขวา ตัวช่วยจะแปลงเป็นเลข 6 บิต รวมกัน แล้วตัดเป็นชุดละ 8 บิต (ตามขั้นตอนในสมุดโน้ต)" style "cr_muted" size 26

            hbox:
                spacing 10
                for i, ch in enumerate(cipher):
                    vbox:
                        spacing 4
                        if ch == "=":
                            text "=" style "cr_mono" size 56 color "#4a4270" xalign 0.5 yminimum 100
                        else:
                            textbutton ch:
                                style "cr_letter_btn"
                                sensitive (i not in picked and (i == 0 or (i - 1) in picked))
                                action SetScreenVariable("picked", picked + [i])
                        if i in idxs:
                            text (str(B64CHARS.index(ch)) + "\n" + b64_bits6(ch)) style "cr_mono" size 20 color "#8f89a8" xalign 0.5
                        else:
                            text "" size 20

            text "บิตที่รวมได้ (ชุดละ 6 บิต):" style "cr_muted" size 24
            frame:
                background Solid("#0d0b14")
                xfill True
                padding (16, 10)
                text (" ".join([b64_bits6(cipher[i]) for i in idxs]) if idxs else "-") style "cr_mono" size 26 color "#5be3a1"

            text "ตัดใหม่ชุดละ 8 บิต แล้วเทียบตาราง ASCII:" style "cr_muted" size 24
            frame:
                background Solid("#0d0b14")
                xfill True
                yminimum 200
                padding (16, 10)
                vbox:
                    spacing 2
                    if bytes_:
                        for b8, v, c in bytes_:
                            text (b8 + " = " + str(v) + " = " + c) style "cr_mono" size 26 color "#ffd86b"
                    else:
                        text "-" style "cr_mono" size 26 color "#4a4270"

            hbox:
                spacing 14
                textbutton "ล้าง" style "cr_btn" action SetScreenVariable("picked", [])
                textbutton "ปิด" style "cr_btn" action Hide("cr_b64")

# ---------- หน้าสรุปผล ----------
# คืนค่า: "replay" หรือ "end"

screen cr_summary():

    modal True
    zorder 200

    key "K_n" action Show("cr_notebook")
    add Solid("#0d0b14")

    frame:
        background Solid("#6b5bd6")
        padding (5, 5)
        align (0.5, 0.5)
        frame:
            background Solid("#1a1626")
            padding (50, 40)
            xysize (1400, 900)
            vbox:
                spacing 20
                xfill True

                text "ผ่านด่านทดลองครบแล้ว" style "cr_title" xalign 0.5

                frame:
                    background Solid("#0d0b14")
                    xfill True
                    padding (24, 16)
                    vbox:
                        spacing 8
                        text ("เวลาที่ใช้: " + elapsed_text()) style "cr_text"
                        text ("ถอดรหัสได้: " + str(len(solved)) + " ประตู") style "cr_text"
                        text ("ความรู้ที่เก็บได้: " + str(len(items_got)) + " ชิ้น") style "cr_text"
                        text ("ตอบผิด: " + str(wrong_total) + " ครั้ง   ใช้คำใบ้: " + str(hints_used) + " ครั้ง   ดูวิธีทำ: " + str(walk_used) + " ครั้ง") style "cr_muted"

                text "สิ่งที่คุณได้เรียนรู้" style "cr_text" color "#5be3a1"
                text "- Caesar Cipher: เลื่อนตัวอักษรตามค่า shift ถอดได้โดยเลื่อนกลับ\n- Brute force: ถ้ากุญแจมีน้อยแบบ ลองทุกแบบก็แกะได้ (Caesar มีแค่ 25 แบบ)\n- Base64: เป็น encoding ไม่ใช่ encryption ใครก็ถอดได้ ไม่มีกุญแจลับ" style "cr_body" size 28

                text "ในเกมเต็ม: ตึก 10 ชั้น โจทย์สุ่มทุกรอบ เนื้อเรื่อง ทางแยก และหลายตอนจบ" style "cr_muted"

                hbox:
                    xalign 0.5
                    spacing 24
                    textbutton "สมุดโน้ต (N)" style "cr_btn" action Show("cr_notebook")
                    textbutton "เล่นอีกครั้ง" style "cr_btn" action Return("replay")
                    textbutton "จบ" style "cr_btn" action Return("end")
