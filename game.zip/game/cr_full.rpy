# ==========================================================================
#  cr_full.rpy : ข้อมูลและฟังก์ชันของเวอร์ชันเต็ม (ชั้น F10 - F1)
#  - ห้องเวอร์ชันเต็มใช้ id ตัวพิมพ์ใหญ่ (F10..F1) แยกจากเดโม (f10..f8)
#  - โจทย์ทุกชั้นสุ่มจาก cr_gen.py ตอนเริ่มเกม เก็บไว้ในตัวแปร gen (เซฟได้)
#  - ฟังก์ชัน R() / P() ใช้ได้ทั้งเดโมและเวอร์ชันเต็ม
# ==========================================================================

# สถานะของเวอร์ชันเต็ม (เซฟ/โหลดได้)
default mode = "demo"          # "demo" หรือ "full"
default run_seed = 0
default gen = {}               # โจทย์ที่สุ่มได้ในรอบนี้ (id -> dict)
default dyn_items = {}         # ความรู้/เบาะแสที่สร้างจากโจทย์ที่สุ่มได้
default pzs = {}               # สถานะคำใบ้/ตอบผิด แยกตามโจทย์
default subst_maps = {}        # ตารางสลับตัวอักษรที่ผู้เล่นเติมไว้ (แยกตามโจทย์)
default letters_read = []      # จดหมายดร.คีย์ที่อ่านแล้ว (เลข 1-10)
default trust = 0              # ความไว้ใจ -5..+5 (ผู้เล่นไม่เห็นตัวเลข)
default understand = 0         # ด่านที่ผ่านโดยไม่กด "ดูวิธีทำ"
default choice_a = None        # "honest" / "lie" / "refuse"
default choice_b = None        # "help" / "deal" / "refuse"
default choice_c = None        # "exit" / "vault" / "destroy"
default free_hints = 0         # คำใบ้ฟรีจากทางแยก A
default flags = set()          # เหตุการณ์ที่เกิดแล้ว (คัตซีน ฯลฯ)
default dev_show_answers = False

# ค่าที่จำข้ามรอบการเล่น
default persistent.dev = False             # โหมดทดสอบ (เปิดด้วยรหัสลับ)
default persistent.dev_floor = None        # เริ่มเรื่องเต็มที่ชั้นที่เลือก (DEV)
default persistent.endings_seen = set()    # ตอนจบที่เคยเห็น

init 1 python:

    import cr_gen

    # รหัสสำหรับทดสอบ: เก็บเฉพาะค่า hash (ผู้เล่นเปิดไฟล์ก็ไม่เห็นรหัสจริง)
    # เปลี่ยนรหัส: คำนวณ cr_gen.sha256_hex("รหัสใหม่ตัวพิมพ์ใหญ่") แล้วใส่แทนค่าข้างล่าง
    DEV_HASH = "c71cdb2211ca533c04234e5c5d4997a26a2e90a93b95cb1956aa4363d8a481db"

    def is_dev_code(s):
        return cr_gen.sha256_hex(normalize(s)) == DEV_HASH

    FULL_ORDER = ["F10", "F9", "F8", "F7", "F6", "F5", "F4", "F3", "F2", "F1"]

    # ------------------------------------------------------------------
    # ความรู้เพิ่มเติมของเวอร์ชันเต็ม
    # ------------------------------------------------------------------
    ITEMS.update({
        "atbash": {"title": "Atbash: รหัสกระจก", "body": paras(
            "{b}Atbash{/b}",
            "รหัสโบราณที่ใช้กับอักษรฮีบรูมากว่า 2,500 ปี จับคู่ตัวอักษรจากหัวกับท้าย: A คู่ Z, B คู่ Y, C คู่ X",
            mono("A B C D E F G H I J K L M\nZ Y X W V U T S R Q P O N", 24),
            "จุดเด่น: {b}ไม่มีกุญแจ{/b} ถอดกับเข้ารหัสใช้วิธีเดียวกัน ใครรู้วิธีก็อ่านได้ทันที",
        )},
        "rot13": {"title": "ROT13: เลื่อนครึ่งทาง", "body": paras(
            "{b}ROT13{/b}",
            "คือรหัสซีซาร์ที่ shift = 13 พอดีครึ่งหนึ่งของตัวอักษร 26 ตัว",
            "เพราะ 13 + 13 = 26 การเข้ารหัสซ้ำสองครั้งจะได้ข้อความเดิมกลับมา",
            "ในอินเทอร์เน็ตยุคแรก คนใช้ ROT13 ซ่อนเฉลยหรือสปอยล์ ไม่ได้ใช้เพื่อความลับจริง",
        )},
        "kerckhoffs": {"title": "หลักของ Kerckhoffs", "body": paras(
            "{b}หลักของ Kerckhoffs (ปี 1883){/b}",
            "ระบบรหัสที่ดีต้องปลอดภัย {b}แม้ศัตรูรู้วิธีเข้ารหัสทั้งหมด{/b} ความลับต้องอยู่ที่ {b}กุญแจ{/b} อย่างเดียว",
            "ชั้นนี้ทุกคนรู้ว่าเป็นรหัสซีซาร์ สิ่งที่ซ่อนคือค่า shift ถ้าหากุญแจเจอ ก็อ่านได้ทันที",
        )},
        "clue_p8": {"title": "โน้ตของคนตั้งรหัส (ชั้น 8)", "body": paras(
            "{b}โน้ตแปะข้างคอมพิวเตอร์{/b}",
            "“กันลืม: กุญแจของประตูชั้นนี้ จดไว้บนไวท์บอร์ดเป็นขีด ๆ ใครจะไปรู้ว่าขีดพวกนั้นคือตัวเลข”",
        )},
        "substitution": {"title": "รหัสสลับตัวอักษร", "body": paras(
            "{b}Substitution Cipher{/b}",
            "แทนตัวอักษรแต่ละตัวด้วยตัวอื่นแบบสุ่ม ไม่ได้เลื่อนเป็นระเบียบแบบซีซาร์",
            "จำนวนวิธีสลับมีถึง 26! (ประมาณ 4 x 10 ยกกำลัง 26) ลองทุกแบบไม่ไหวแน่นอน",
            "แต่ถ้ารู้คีย์บางส่วน หรือรู้ว่าข้อความน่าจะมีคำอะไร ก็เดาส่วนที่เหลือจากรูปคำได้",
            "เครื่องมือ: ตารางสลับตัวอักษร คลิกตัวอักษรรหัส แล้วเลือกตัวที่คิดว่าเป็นตัวจริง",
        )},
        "frequency": {"title": "การนับความถี่ตัวอักษร", "body": paras(
            "{b}Frequency Analysis{/b}",
            "นักปราชญ์อาหรับ {b}อัล-คินดี{/b} ค้นพบเมื่อกว่า 1,100 ปีก่อนว่า ตัวอักษรแต่ละตัวในภาษาหนึ่ง ๆ ปรากฏบ่อยไม่เท่ากัน",
            "ภาษาอังกฤษ: E เจอบ่อยที่สุด ตามด้วย T, A, O, I, N คำ 3 ตัวที่เจอบ่อยสุดคือ THE",
            "รหัสสลับตัวอักษรเปลี่ยนหน้าตาตัวอักษร แต่ {b}เปลี่ยนความถี่ไม่ได้{/b} ข้อความยิ่งยาวยิ่งแกะง่าย",
        )},
        "clue_p5": {"title": "กระดาษต่อเนื่อง (ชั้น 5)", "body": paras(
            "{b}กระดาษพิมพ์ยาวเหยียด{/b}",
            "ข้อความภาษาอังกฤษยาวทั้งหน้าที่ถูกสลับตัวอักษร เว้นวรรคระหว่างคำยังอยู่ครบ",
            "ท้ายกระดาษมีลายมือเขียนว่า: “ประโยคสุดท้ายบอกรหัสผ่านเสมอ THE PASSWORD IS ...”",
        )},
        "vigenere": {"title": "รหัส Vigenère", "body": paras(
            "{b}Vigenère Cipher{/b}",
            "ใช้ {b}คีย์เวิร์ด{/b} บอกว่าตัวอักษรแต่ละตัวเลื่อนไปเท่าไร A = 0, B = 1, C = 2 ... แล้ววนคีย์เวิร์ดซ้ำไปเรื่อย ๆ",
            mono("ข้อความ  H E L L O\nคีย์     K E Y K E\nเลื่อน   10 4 24 10 4\nรหัส     R I J V S", 24),
            "ตัว L สองตัวกลายเป็น J กับ V ไม่เหมือนกัน การนับความถี่แบบเดิมจึงใช้ไม่ได้",
            "เคยถูกเรียกว่า {b}รหัสที่ไม่มีวันแตก{/b} อยู่ 300 ปี จนชาร์ลส์ แบบเบจ และฟรีดริช คาสิสกี หาวิธีหาความยาวคีย์ได้",
        )},
        "xor": {"title": "XOR และ One-time pad", "body": paras(
            "{b}XOR{/b}",
            "เทียบบิตทีละตำแหน่ง: {b}เหมือนกันได้ 0 ต่างกันได้ 1{/b}",
            mono("ข้อความ  0100 0001  (A = 65)\nคีย์     0010 1100\nXOR      0110 1101  = รหัส", 24),
            "XOR รหัสกับคีย์เดิมอีกครั้งจะได้ข้อความเดิมกลับมา",
            "ถ้าคีย์ยาวเท่าข้อความ สุ่มจริง และใช้ครั้งเดียว เรียกว่า {b}One-time pad{/b} เป็นรหัสที่พิสูจน์แล้วว่าแกะไม่ได้ แต่คีย์ 8 บิตใช้ซ้ำทุกตัวแบบชั้นนี้ไม่ปลอดภัย",
        )},
        "clue_p3": {"title": "สวิตช์ 8 ตัว (ชั้น 3)", "body": paras(
            "{b}ป้ายเล็กใต้แผงสวิตช์{/b}",
            "“คีย์ XOR = สถานะสวิตช์ทั้ง 8 อ่านจากซ้ายไปขวา ไฟเขียว = 1 ไฟดับ = 0”",
        )},
        "hash": {"title": "Hash: ลายนิ้วมือของข้อมูล", "body": paras(
            "{b}Hash Function{/b}",
            "แปลงข้อมูลยาวเท่าไรก็ได้ ให้เป็นค่าความยาวคงที่ ข้อมูลเดิมได้ hash เดิมเสมอ แต่ {b}ย้อนกลับไม่ได้{/b}",
            "ระบบที่ดีจึงเก็บแค่ hash ของรหัสผ่าน ตอนล็อกอินเอารหัสที่พิมพ์ไป hash แล้วเทียบ",
            "จุดอ่อน: ถ้ารหัสผ่านเป็นคำที่เดาง่าย คนร้ายก็ลอง hash คำยอดนิยมแล้วเทียบได้ จึงควรตั้งรหัสผ่านที่ยาวและเดายาก",
            "ในเกมแสดง hash แบบ SHA-256 แค่ 16 ตัวแรก",
        )},
        "rsa": {"title": "กุญแจสาธารณะ กุญแจส่วนตัว", "body": paras(
            "{b}Public-key cryptography{/b}",
            "มีกุญแจเป็นคู่: {b}กุญแจสาธารณะ (e, n){/b} แจกให้ใครก็ได้ไว้ล็อก, {b}กุญแจส่วนตัว (d, n){/b} เก็บไว้กับตัวไว้เปิด",
            "เข้ารหัส: c = m ยกกำลัง e แล้ว mod n\nถอดรหัส: m = c ยกกำลัง d แล้ว mod n",
            "mod n คือเศษจากการหารด้วย n เช่น 40 mod 33 = 7",
            "ระบบ RSA จริงใช้ตัวเลขยาวหลายร้อยหลัก จนหา d จาก e และ n ไม่ได้ในเวลาชั่วชีวิต",
        )},
    })

    # ------------------------------------------------------------------
    # จดหมายของดร.คีย์ (ร่าง: จะเขียนบทจริงในขั้นเขียนบท)
    # ------------------------------------------------------------------
    LETTERS = {
        1: ("ฉบับที่ 1: ทำไมฉันรักรหัส", "ถึงใครก็ตามที่อ่านอยู่\n\nตอนเด็ก ฉันอ่านเจอว่าจูเลียส ซีซาร์ส่งคำสั่งถึงแม่ทัพโดยเลื่อนตัวอักษรไปสามตัว ฉันนั่งเลื่อนตัวอักษรทั้งคืน แล้วรู้สึกเหมือนได้ถือกุญแจของโลกทั้งใบ\n\nตึกนี้คือที่ที่ฉันอยากให้เด็กทุกคนได้รู้สึกแบบนั้น\n\n— คีรี"),
        2: ("ฉบับที่ 2: ลูกศิษย์ที่ลองทุกกุญแจ", "วันนี้มีเด็กคนหนึ่งแกะรหัสซีซาร์ของฉันได้ในห้านาที เขาไม่ได้เดา เขาลองทุกกุญแจทีละค่า\n\nฉันดีใจมาก เพราะเขาเพิ่งค้นพบด้วยตัวเองว่า รหัสที่มีกุญแจให้ลองน้อยเกินไป ไม่มีวันปลอดภัย\n\n— คีรี"),
        3: ("ฉบับที่ 3: กุญแจซ่อนในสิ่งที่เห็น", "คนชอบคิดว่ารหัสที่ดีคือรหัสที่ไม่มีใครรู้วิธีทำ ฉันคิดตรงข้าม\n\nให้ทุกคนรู้วิธีได้เลย ขอแค่เก็บกุญแจไว้ให้ดี แล้วอย่าเขียนกุญแจไว้บนกระดานให้ใครเห็นก็พอ\n\n— คีรี"),
        4: ("ฉบับที่ 4: ภาษาของเครื่อง", "เด็กชายเงียบ ๆ ที่ใส่หูฟังตลอดเวลาถามฉันว่า Base64 เป็นรหัสลับใช่ไหม\n\nฉันบอกเขาว่า ไม่ใช่ มันแค่เปลี่ยนชุดของตัวอักษร ใครก็แปลงกลับได้ การแปลงรูปแบบกับการเก็บความลับเป็นคนละเรื่องกัน\n\nเขาจดทุกคำ แต่ฉันไม่แน่ใจว่าเขาเข้าใจหรือแค่จำ\n\n— คีรี"),
        5: ("ฉบับที่ 5: 26 แฟกทอเรียล", "ลูกสาวโทรมาวันนี้ เธอบอกว่าฉันรักตัวอักษรมากกว่าคนในบ้าน\n\nฉันอธิบายไม่ได้ว่า การสลับตัวอักษรมีวิธีมากกว่าจำนวนดาวในจักรวาล แต่การขอโทษใครสักคนกลับยากกว่านั้นอีก\n\n— คีรี"),
        6: ("ฉบับที่ 6: ตัว E", "บริษัทหนึ่งมาเสนอเงินให้ฉันสร้างเครื่องมือเจาะรหัส พวกเขาบอกว่าจะใช้มันเพื่อความปลอดภัย\n\nอัล-คินดีสอนว่า ข้อความทุกข้อความทิ้งร่องรอยไว้เสมอ ฉันกลัวว่ามือที่ถือเครื่องมือของฉันจะไม่ได้ใช้มันอ่านแค่ข้อความของศัตรู\n\n— คีรี"),
        7: ("ฉบับที่ 7: รหัสที่ไม่มีวันแตก", "Vigenère ถูกเรียกว่ารหัสที่ไม่มีวันแตกอยู่สามร้อยปี จนมีคนหาวิธีแกะได้\n\nไม่มีรหัสไหนปลอดภัยตลอดไป ฉันปฏิเสธบริษัทนั้นไปแล้ว พวกเขาไม่ชอบคำตอบนี้\n\n— คีรี"),
        8: ("ฉบับที่ 8: กุญแจที่ใช้ครั้งเดียว", "มือฉันสั่นจนเขียนตัวตรงไม่ได้ หมอบอกว่าฉันมีเวลาไม่มากนัก\n\nOne-time pad ปลอดภัยที่สุดเพราะกุญแจถูกใช้ครั้งเดียวแล้วทิ้ง บางทีเวลาของคนก็เป็นแบบนั้น ใช้ได้ครั้งเดียว\n\n— คีรี"),
        9: ("ฉบับที่ 9: ลายนิ้วมือ", "ฉันลืมรหัสผ่านของตัวเองเป็นครั้งแรกในชีวิต\n\nแต่ไม่เป็นไร ระบบไม่เคยจำรหัสผ่านของฉันอยู่แล้ว มันจำแค่ลายนิ้วมือของมัน สิ่งที่สำคัญจริงไม่จำเป็นต้องจำ ขอแค่จำได้เมื่อเห็นอีกครั้ง\n\n— คีรี"),
        10: ("ฉบับที่ 10: ถึงหลาน", "ถึงเชน หลานรัก\n\nตาตั้งชื่อหลานจาก blockchain ทุกบล็อกต่อกับบล็อกก่อนหน้า ความรู้ก็เหมือนกัน ส่งต่อจากคนหนึ่งไปอีกคน\n\nกุญแจทองเหลืองที่หลานห้อยคออยู่ คือกุญแจส่วนตัว ตัวเลขด้านหลังคือสิ่งที่ประตูข้างล่างรออยู่ ส่วนกุญแจสาธารณะ ตาแขวนไว้ให้ทุกคนเห็นบนประตูแล้ว\n\nใครก็ล็อกได้ แต่มีแค่หลานที่เปิดได้\n\n— ตา"),
    }

    ENDINGS = {
        1: "ร่วมทาง",
        2: "ผู้สืบทอดกุญแจ",
        3: "ทางเดียวดาย",
        4: "เย็นชา",
        5: "บทเรียน",
    }

    TEACH_TEXT = {
        "caesar": "Caesar Cipher: เลื่อนตัวอักษรตามค่า shift",
        "atbash": "Atbash: รหัสกระจก ไม่มีกุญแจ",
        "rot13": "ROT13: Caesar ที่ shift 13 เข้ารหัสซ้ำได้ข้อความเดิม",
        "kerckhoffs": "หลักของ Kerckhoffs: ความลับต้องอยู่ที่กุญแจ ไม่ใช่วิธี",
        "base64": "Base64: encoding ไม่ใช่ encryption",
        "ascii": "ASCII: คอมพิวเตอร์เก็บตัวอักษรเป็นตัวเลข",
        "substitution": "Substitution: สลับตัวอักษรแบบสุ่ม เดาจากรูปคำได้",
        "frequency": "Frequency analysis: นับความถี่ตัวอักษรเพื่อแกะรหัสสลับ",
        "vigenere": "Vigenère: เลื่อนไม่เท่ากันตามคีย์เวิร์ด",
        "xor": "XOR: เหมือนได้ 0 ต่างได้ 1 และย้อนกลับด้วยคีย์เดิม",
        "hash": "Hash: ลายนิ้วมือของข้อมูล ย้อนกลับไม่ได้",
        "brute_pin": "Brute force: รหัสสั้นต่อให้ hash ก็ลองครบได้",
        "rsa": "กุญแจสาธารณะ/ส่วนตัว: ล็อกด้วยกุญแจหนึ่ง เปิดด้วยอีกกุญแจหนึ่ง",
    }

    # ------------------------------------------------------------------
    # ห้องของเวอร์ชันเต็ม
    # ------------------------------------------------------------------
    # (item, letter) ของแต่ละจุด: item = ความรู้ที่ได้, letter = เลขจดหมายที่ซ่อนอยู่
    SPOT_META = {
        "F10_poster": ("caesar_intro", None), "F10_shelf": ("caesar_history", 1),
        "F10_tally": (None, None), "F10_desk": ("clue_p10", None),
        "F9_board": ("atbash", None), "F9_disk": ("wheel_howto", None),
        "F9_cabinet": ("rot13", 2), "F9_window": ("brute_force", None),
        "F8_rack": ("kerckhoffs", None), "F8_board": (None, None),
        "F8_manual": (None, 3), "F8_desk": ("clue_p8", None),
        "F7_fridge": (None, None), "F7_shelf": ("ascii_table", None), "F7_tv": ("clue_p7", None),
        "F7_photo": (None, None), "F7_sofa": (None, 4), "F7_clock": (None, None),
        "F6_bed": (None, 5), "F6_stain": ("clue_p6", None), "F6_bucket": (None, None),
        "F6_window": (None, None), "F6_desk": ("substitution", None), "F6_camera": (None, None),
        "F5_fuse": (None, None), "F5_generator": (None, 6), "F5_toolbox": (None, None),
        "F5_gauges": ("frequency", None), "F5_paper": ("clue_p5", None), "F5_intercom": (None, None),
        "F4_valves": (None, None), "F4_crate": (None, 7), "F4_board": ("clue_p4_board", None),
        "F4_tags": ("clue_p4_tags", None), "F4_tape": ("vigenere", None),
        "F3_locker": (None, 8), "F3_fan": (None, None), "F3_monitors": (None, None),
        "F3_lamp": ("xor", None), "F3_switches": ("clue_p3", None), "F3_console": (None, None),
        "F2_safe": (None, None), "F2_board": ("clue_p2", None), "F2_terminal": ("hash", None),
        "F2_headphones": (None, None), "F2_keys": (None, None), "F2_window": (None, None),
        "F2_cot": (None, None),
        "F1_frontdoor": (None, None), "F1_stairs": (None, None), "F1_counter": (None, None),
        "F1_painting": ("rsa", 10), "F1_chandelier": (None, None), "F1_lever": (None, None),
        "F1_vault": (None, None),
    }

    def fspot(sid, label, b, alert=None):
        item, letter = SPOT_META.get(sid, (None, None))
        d = spot(sid, label, "fs_" + sid, item, b, alert)
        d["letter"] = letter
        return d

    FROOMS = {
        "F10": {"floor": 10, "name": "ชั้น 10: ห้องขัง", "bg": "images/bg_d2.jpg", "intro": "fintro_F10",
                "puzzles": ["P10"], "next": "F9", "door": door_box((1360, 225, 1610, 695)), "spots": [
            fspot("F10_poster", "โปสเตอร์บนผนัง", (355, 260, 610, 420)),
            fspot("F10_shelf", "ชั้นหนังสือ", (635, 220, 840, 695)),
            fspot("F10_tally", "รอยขีดบนผนัง", (930, 240, 1265, 395)),
            fspot("F10_desk", "โต๊ะและคอมพิวเตอร์", (845, 405, 1290, 700), alert=(1215, 465)),
        ]},
        "F9": {"floor": 9, "name": "ชั้น 9: สำนักงานร้าง", "bg": "images/bg_d5.jpg", "intro": "fintro_F9",
               "puzzles": ["P9"], "next": "F8", "door": door_box((1385, 235, 1610, 690)), "spots": [
            fspot("F9_board", "กระดาษข้างประตู", (1295, 395, 1390, 590)),
            fspot("F9_disk", "จานรหัสทองเหลือง", (215, 455, 395, 595)),
            fspot("F9_cabinet", "ตู้เอกสารเหล็ก", (505, 330, 690, 730)),
            fspot("F9_window", "หน้าต่างบานใหญ่", (695, 180, 1280, 505)),
        ]},
        "F8": {"floor": 8, "name": "ชั้น 8: ห้อง IT", "bg": "images/bg_d6.jpg", "intro": "fintro_F8",
               "puzzles": ["P8"], "next": "F7", "door": door_box((1370, 190, 1630, 740)), "spots": [
            fspot("F8_rack", "ตู้เซิร์ฟเวอร์", (100, 50, 480, 780), alert=(290, 120)),
            fspot("F8_board", "ไวท์บอร์ด", (505, 250, 970, 555)),
            fspot("F8_manual", "หนังสือบนพื้น", (530, 770, 960, 850)),
            fspot("F8_desk", "คอมพิวเตอร์ผู้ดูแล", (975, 400, 1355, 760), alert=(1105, 380)),
        ]},
    }

    _NEXT = {"F7": "F6", "F6": "F5", "F5": "F4", "F4": "F3", "F3": "F2", "F2": "F1", "F1": None}
    for _src_id, _src in FULL_ROOMS.items():
        _rid = "F" + _src_id[1:]
        FROOMS[_rid] = {
            "floor": int(_src_id[1:]), "name": _src["name"], "bg": _src["bg"], "intro": "fintro_" + _rid,
            "puzzles": (["L1", "L2"] if _rid == "F1" else ["P" + _src_id[1:]]),
            "ovp": (["P2", "S2"] if _rid == "F2" else None),
            "next": _NEXT[_rid],
            "door": (door_box(_src["door"]) if _src["door"] else None),
            "spots": [fspot("F" + s[0][1:], s[1], s[3]) for s in _src["spots"]],
        }
        if _rid == "F1":
            FROOMS[_rid]["ovp"] = ["L1"]

    for _rid in FULL_ORDER:
        for _s in FROOMS[_rid]["spots"]:
            SPOTS[_s["id"]] = _s

    # ------------------------------------------------------------------
    # ตัวช่วยที่ใช้ได้ทั้งเดโมและเวอร์ชันเต็ม
    # ------------------------------------------------------------------
    def R(rid):
        return FROOMS[rid] if rid in FROOMS else ROOMS[rid]

    def P(pid):
        return gen[pid] if pid in gen else PUZZLES[pid]

    def room_puzzles(rid):
        r = R(rid)
        return r.get("puzzles") or [r["puzzle"]]

    def door_puzzle(rid):
        """โจทย์ของประตูที่ยังไม่ผ่าน (None = ผ่านครบแล้ว)"""
        for pid in room_puzzles(rid):
            if pid not in solved:
                return pid
        return None

    def door_done(rid):
        return door_puzzle(rid) is None

    def room_order():
        return FULL_ORDER if mode == "full" else ROOM_ORDER

    def item_info(iid):
        if iid in dyn_items:
            return dyn_items[iid]
        return ITEMS.get(iid, {"title": iid, "body": ""})

    def room_overlays(rid):
        r = R(rid)
        out = []
        for pid in (r.get("ovp") or room_puzzles(rid)):
            if pid in gen:
                out.extend(gen[pid].get("overlays", []))
        return out

    def tool_action_p(pz, rtool=None):
        t = pz.get("tool", rtool)
        a = pz.get("tool_args", {})
        if t == "b64":
            return Show("cr_b64", cipher=a.get("cipher", pz["cipher"]))
        if t == "mirror":
            return Show("cr_mirror", cipher=a["cipher"])
        if t == "base":
            return Show("cr_baseconv", cipher=a["cipher"], base=a["base"])
        if t == "subst":
            return Show("cr_subst", pid=pz["id"], cipher=a["cipher"], given=a["given"], freq=a["freq"])
        if t == "vig":
            return Show("cr_vig", cipher=a["cipher"])
        if t == "xor":
            return Show("cr_xor", cipher=a["cipher"])
        if t == "hash":
            return Show("cr_hash", target=a["target"], hmode=a["mode"])
        if t == "rsa":
            return Show("cr_rsa", nums=a["nums"], n=a["n"], e=a["e"])
        return Show("cr_wheel", cipher=a.get("cipher", pz["cipher"]), auto=a.get("auto", pz.get("auto", False)))

    def tool_action(room_id):
        pid = door_puzzle(room_id) or room_puzzles(room_id)[-1]
        return tool_action_p(P(pid), R(room_id).get("tool"))

    # ------------------------------------------------------------------
    # สร้างรอบใหม่ของเวอร์ชันเต็ม
    # ------------------------------------------------------------------
    def build_dyn_items(g):
        items = {}
        for p in g.values():
            items.update(p.get("items", {}))
        p7 = g["P7"]
        if p7["clue"]["kind"] == "b64":
            items["clue_p7"] = dict(ITEMS["base64_how"])
            items["clue_p7"]["title"] = "ทีวีเก่า: Base64"
        else:
            base = "ฐานสอง (0 กับ 1)" if p7["clue"]["kind"] == "bin" else "ฐานสิบหก (0-9 และ A-F)"
            items["clue_p7"] = {"title": "ทีวีเก่า: ตัวเลขบนจอ", "body": paras(
                "{b}ตัวเลขที่ทีวีแสดงซ้ำไปซ้ำมา{/b}",
                mono(p7["cipher"], 26),
                "ตัวเลขเหล่านี้เป็นเลข" + base + " แต่ละกลุ่มคือตัวอักษร 1 ตัว",
                "แปลงเป็นเลขฐานสิบก่อน แล้วเทียบตาราง ASCII (A = 65 ถึง Z = 90)",
                "ตัวอย่าง: 01000001 = 64 + 1 = 65 = A และ 41 (ฐานสิบหก) = 4 x 16 + 1 = 65 = A",
            )}
        pairs = g["P6"]["clue"]["pairs"]
        items["clue_p6"] = {"title": "ตัวอักษรบนคราบน้ำ (ชั้น 6)", "body": paras(
            "{b}คู่ตัวอักษรที่เขียนไว้บนผนัง{/b}",
            mono("\n".join("%s = %s" % (a, b) for a, b in pairs), 28),
            "ด้านซ้ายคือตัวในรหัส ด้านขวาคือตัวจริง บางคู่อาจไม่ได้ใช้กับรหัสที่ประตู",
        )}
        c4 = g["P4"]["clue"]
        items["clue_p4_board"] = {"title": "คำบนกระดานดำ (ชั้น 4)", "body": paras(
            "{b}คำที่เขียนบนกระดานดำ{/b}", mono("   ".join(c4["board"]), 28))}
        items["clue_p4_tags"] = {"title": "คำบนป้ายโลหะ (ชั้น 4)", "body": paras(
            "{b}คำที่สลักบนป้ายโลหะ 5 ใบ{/b}", mono("   ".join(c4["tags"]), 28),
            "โน้ตบนท่อ: “คีย์เวิร์ดคือคำที่อยู่ทั้งบนกระดานและบนป้าย”")}
        items["clue_p2"] = {"title": "รายการบนบอร์ด (ชั้น 2)", "body": paras(
            "{b}รหัสผ่านยอดนิยมที่ยามจดไว้{/b}",
            mono("\n".join(g["P2"]["clue"]["list"]), 28),
            "หัวกระดาษเขียนว่า “ห้ามใช้รหัสพวกนี้!” แต่ดูเหมือนจะมีคนใช้อยู่ดี")}
        items["brass_key"] = {"title": "กุญแจทองเหลือง", "body": paras(
            "{b}กุญแจทองเหลืองที่ห้อยคอ{/b}",
            "แม่บอกว่าเป็นของจากตา ส่งมาให้ตั้งแต่เชนเกิด",
            "ด้านหลังสลักตัวเลขไว้: " + mono(str(g["L3"]["clue"]["d"]), 34),
            "ยังไม่รู้ว่าตัวเลขนี้หมายถึงอะไร",
        )}
        return items

    def new_full_run(seed=None):
        global run_seed, gen, dyn_items
        if seed is None:
            seed = renpy.random.randint(1, 999999)
        run_seed = seed
        gen = cr_gen.make_run(seed)
        dyn_items = build_dyn_items(gen)

    # ------------------------------------------------------------------
    # ทางแยก / ตอนจบ
    # ------------------------------------------------------------------
    def add_trust(n):
        global trust
        trust = max(-5, min(5, trust + n))

    def ending_id():
        if choice_c == "destroy":
            return 5
        if choice_c == "vault":
            return 2
        if trust <= -2:
            return 4
        if choice_b in ("help", "deal") and trust >= 2:
            return 1
        return 3

    def read_letter(n):
        if n not in letters_read:
            letters_read.append(n)

    def letters_count():
        return len(letters_read)

    # ------------------------------------------------------------------
    # ภาพซ้อนบนฉาก (ตัวเลข/คำที่สุ่ม): ตัวช่วยวาดเข็มนาฬิกา
    # ------------------------------------------------------------------
    def clock_hands(ov):
        cx, cy, r = ov["x"] * SX, ov["y"] * SY, ov["r"] * SX
        m_deg = ov["minute"] * 6
        h_deg = (ov["hour"] % 12) * 30 + ov["minute"] * 0.5

        def hand(length, width, deg, color):
            L = int(length)
            bar = Fixed(Solid(color, xpos=L, xysize=(L, width)), xysize=(2 * L, width))
            return Transform(bar, rotate=deg - 90, rotate_pad=False, transform_anchor=True,
                             anchor=(0.5, 0.5), pos=(int(cx), int(cy)))

        return Fixed(hand(r * 0.55, 7, h_deg, "#2a2320"), hand(r * 0.85, 4, m_deg, "#2a2320"),
                     Transform(Solid("#2a2320", xysize=(12, 12)), anchor=(0.5, 0.5), pos=(int(cx), int(cy))))

    # ------------------------------------------------------------------
    # สถานะของโจทย์แต่ละข้อ (คำใบ้/ตอบผิด/ดูวิธีทำ แยกกัน)
    # ------------------------------------------------------------------
    def pz_load(pid):
        global pz_hint, pz_wrong, pz_walk, pz_msg, free_hints
        st = pzs.get(pid)
        gift = False
        if st is None:
            st = {"hint": 0, "wrong": 0, "walk": False}
            if mode == "full" and free_hints > 0 and pid.startswith("P"):
                st["hint"] = 1
                free_hints -= 1
                gift = True
            pzs[pid] = st
        pz_hint, pz_wrong, pz_walk = st["hint"], st["wrong"], st["walk"]
        pz_msg = "เสียงปริศนาส่งคำใบ้มาให้ 1 ข้อ ตามที่สัญญาไว้" if gift else ""

    def pz_save(pid):
        pzs[pid] = {"hint": pz_hint, "wrong": pz_wrong, "walk": pz_walk}

    # ------------------------------------------------------------------
    # ตารางสลับตัวอักษร (ชั้น 6 และ 5)
    # ------------------------------------------------------------------
    def subst_map(pid, given):
        if pid in subst_maps:
            return subst_maps[pid]
        return dict(given)

    def subst_set(pid, given, c, p):
        m = dict(subst_map(pid, given))
        if c in given:
            return
        if p is None:
            m.pop(c, None)
        else:
            for k in [k for k, v in m.items() if v == p and k not in given]:
                del m[k]
            m[c] = p
        subst_maps[pid] = m
        renpy.restart_interaction()

    def subst_preview(cipher, m):
        out = []
        for ch in cipher:
            if ch in ALPHA:
                if ch in m:
                    out.append("{color=#ffd86b}" + m[ch] + "{/color}")
                else:
                    out.append("{color=#5a5575}" + ch.lower() + "{/color}")
            else:
                out.append(ch)
        return "".join(out)

    def letter_counts(cipher):
        return dict((ch, cipher.count(ch)) for ch in ALPHA)

    # ------------------------------------------------------------------
    # เครื่องมืออื่น ๆ
    # ------------------------------------------------------------------
    def vig_columns(cipher, key):
        key = "".join(ch for ch in key.upper() if ch in ALPHA)
        cols, j = [], 0
        for ch in cipher:
            if ch in ALPHA and key:
                k = key[j % len(key)]
                cols.append((ch, k, ALPHA.index(k), ALPHA[(ALPHA.index(ch) - ALPHA.index(k)) % 26]))
                j += 1
            else:
                cols.append((ch, "", 0, "?" if ch in ALPHA else ch))
        return cols

    def xor_rows(cipher, bits):
        key = int("".join(str(b) for b in bits), 2)
        rows = []
        for h in cipher.split():
            v = int(h, 16)
            r = v ^ key
            rows.append((h, format(v, "08b"), format(r, "08b"), r, chr(r) if 32 <= r < 127 else "?"))
        return rows

    def hash_of(s):
        return cr_gen.short_hash(normalize(s)) if normalize(s) else ""

    def brute_pin(target):
        for i in range(1000):
            pin = "%03d" % i
            if cr_gen.short_hash(pin) == target:
                return (pin, i + 1)
        return ("ไม่พบ", 1000)

    def rsa_rows(nums, n, d):
        rows = []
        for c in nums:
            m = pow(c, d, n)
            rows.append((c, m, ALPHA[m - 1] if 1 <= m <= 26 else "?"))
        return rows

    def to_int(s, default=0):
        try:
            return int(s)
        except Exception:
            return default

    # ------------------------------------------------------------------
    # โหมดทดสอบ (DEV)
    # ------------------------------------------------------------------
    def dev_unlock_to(rid):
        """ผ่านทุกชั้นที่อยู่เหนือ rid และปลดล็อกถึงชั้นนั้น"""
        for r in FULL_ORDER:
            if r not in unlocked:
                unlocked.append(r)
            if r == rid:
                break
            for pid in room_puzzles(r):
                solved.add(pid)

    def dev_all_letters():
        for n in range(1, 11):
            read_letter(n)

    def dev_explore_room():
        for s in R(current_room)["spots"]:
            explored.add(s["id"])
            if s["item"] and s["item"] not in items_got:
                items_got.append(s["item"])

    def dev_set_ending_route(eid):
        global choice_b, choice_c, trust
        dev_all_letters()
        if eid == 1:
            choice_b, choice_c, trust = "help", "exit", 3
        elif eid == 2:
            choice_c = "vault"
        elif eid == 3:
            choice_b, choice_c, trust = "refuse", "exit", 0
        elif eid == 4:
            choice_c, trust = "exit", -3
        else:
            choice_c = "destroy"

    # ------------------------------------------------------------------
    # ตัวช่วยสำหรับ screen: ตัวแปรภายใน screen มองไม่เห็นจากใน lambda / generator
    # จึงต้องคำนวณในฟังก์ชันปกติแทน
    # ------------------------------------------------------------------
    def bin_sum_text(g):
        return "รวมหลักที่เป็น 1: " + " + ".join(str(2 ** (7 - k)) for k in range(8) if g[k] == "1") + " = " + str(int(g, 2))

    def top_letters(counts, n):
        return sorted([c for c in ALPHA if counts[c] > 0], key=lambda c: -counts[c])[:n]

    def freq_line(counts, top):
        return "  ".join(c + "(" + str(counts[c]) + ")" for c in top)

    def bits_value(bits):
        return int("".join(str(b) for b in bits), 2)

    def join_col(rows, idx):
        return "".join(r[idx] for r in rows)

    def count_full_solved():
        return len([p for p in solved if p in gen])

    def b64_bits_join(cipher, idxs, sep):
        return sep.join(b64_bits6(cipher[i]) for i in idxs)


    # ------------------------------------------------------------------
    # ข้อความบนฉากที่ผูกกับกรอบจุดสำรวจ (ขนาดตัวอักษรปรับให้พอดีกรอบอัตโนมัติ)
    # ------------------------------------------------------------------
    NOTE_STYLES = {                  # (พื้นหลัง, สีตัวอักษร)
        "marker": ("#f4f3eee0", "#1c2a4a"),   # ไวท์บอร์ด
        "chalk": ("#16201ce6", "#f2f2ea"),    # กระดานดำ
        "paint": ("#0d0b14c8", "#ffe28a"),    # เขียนบนผนัง
        "paper": ("#efe4c8ee", "#2a2418"),    # กระดาษบนบอร์ด
        "metal": ("#d9d4c6ee", "#2a2118"),    # ป้ายโลหะ
        "screen": ("#06150fe6", "#7dffbf"),   # จอทีวี
    }

    TOOL_SCREENS = ["cr_wheel", "cr_b64", "cr_mirror", "cr_baseconv", "cr_subst",
                    "cr_vig", "cr_xor", "cr_hash", "cr_rsa"]

    def tool_is_open():
        for n in TOOL_SCREENS:
            if renpy.get_screen(n):
                return True
        return False

    def note_layout(ov):
        s = SPOTS[ov["spot"]]
        m = ov.get("margin", 0.08)
        x = s["x"] + int(s["w"] * m)
        y = s["y"] + int(s["h"] * m)
        w = s["w"] - 2 * int(s["w"] * m)
        h = s["h"] - 2 * int(s["h"] * m)
        if "fit" in ov:                       # ใช้เฉพาะบางส่วนของกรอบ (สัดส่วน x, y, w, h)
            fx, fy, fw, fh = ov["fit"]
            x, y, w, h = x + int(w * fx), y + int(h * fy), int(w * fw), int(h * fh)
        lines = ov["lines"]
        longest = max(len(l) for l in lines) if lines else 1
        size = min(int((h - 12) / max(1, len(lines)) / 1.3), int((w - 16) / (longest * 0.62)))
        size = max(14, min(ov.get("max", 46), size))
        bg, fg = NOTE_STYLES[ov.get("style", "paint")]
        return x, y, w, h, size, bg, fg

    def led_layout(ov):
        s = SPOTS[ov["spot"]]
        size = max(16, min(30, s["w"] // 8 - 14))
        return s["x"], max(0, s["y"] - size - 20), s["w"], size
