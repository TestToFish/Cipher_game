# ==========================================================================
#  cr_menu.rpy : หน้าล็อบบี้ (เมนูหลัก), หน้าตั้งค่า, หน้าวิธีเล่น
#  ใช้ label main_menu: Ren'Py จะเรียก label นี้แทนเมนูเดิมของ template เสมอ
#  ไม่ว่า screens.rpy ในโปรเจกต์จะมี screen main_menu อยู่หรือไม่
#  ทุกอย่างใช้สีล้วน + ภาพใน gui/ ของแพ็กนี้ ไม่พึ่งภาพของ template
# ==========================================================================

init offset = 100

# ---------- สไตล์ ----------

style cr_menu_btn is button:
    background None
    hover_background Solid("#ffd86b22")
    padding (24, 10, 40, 10)
    xminimum 440
    activate_sound "audio/sfx_click.ogg"
    hover_sound "audio/sfx_hover.ogg"

style cr_menu_btn_text is cr_text:
    size 46
    idle_color "#e8e4f5"
    hover_color "#ffd86b"
    outlines [(3, "#0d0b14", 0, 0)]

style cr_hbar is default:
    xsize 620
    ysize 22
    left_bar Solid("#6b5bd6")
    right_bar Solid("#2a2440")
    thumb Solid("#ffd86b", xysize=(16, 34))
    thumb_offset 8
    yalign 0.5

style cr_opt_btn is cr_btn:
    selected_background Solid("#6b5bd6")

style cr_opt_btn_text is cr_btn_text:
    selected_color "#ffffff"

style cr_label is cr_text:
    size 32
    color "#ffd86b"
    min_width 330
    yalign 0.5

# ---------- ทรานส์ฟอร์ม ----------

transform cr_title_in:
    alpha 0.0 yoffset -24
    pause 0.2
    easein 1.0 alpha 1.0 yoffset 0

transform cr_btn_in(d):
    alpha 0.0 xoffset -40
    pause d
    easein 0.45 alpha 1.0 xoffset 0

transform cr_window_glow:
    alpha 0.45
    ease 1.8 alpha 1.0
    ease 1.8 alpha 0.45
    repeat

transform cr_blink_slow:
    alpha 0.9
    ease 1.2 alpha 0.35
    ease 1.2 alpha 0.9
    repeat

# ---------- หน้าล็อบบี้ ----------

label main_menu:
    scene black
    play music "audio/music_menu.ogg" if_changed fadein 1.0
    call screen cr_lobby
    return

screen cr_lobby():

    default secret_taps = 0

    add BG("gui/main_menu.png")
    add "gui/cr_glow.png" xcenter 921 ycenter 341 at cr_window_glow
    add "gui/cr_shade.png"

    # ชื่อเกม
    vbox:
        xpos 120
        ypos 110
        spacing 6
        at cr_title_in
        text "CIPHER TOWER":
            style "cr_mono"
            size 104
            color "#ffd86b"
            kerning 6
            outlines [(5, "#0d0b14", 0, 0)]
        text "หนีออกจากตึกร้าง ด้วยวิชาถอดรหัส":
            style "cr_text"
            size 38
            color "#e8e4f5"
            outlines [(3, "#0d0b14", 0, 0)]

    # ปุ่ม
    vbox:
        xpos 96
        ypos 400
        spacing 6
        if renpy.newest_slot() is not None and renpy.has_screen("load"):
            textbutton "เล่นต่อ" at cr_btn_in(0.4) style "cr_menu_btn" action ShowMenu("load")
        textbutton "เรื่องเต็ม" at cr_btn_in(0.5) style "cr_menu_btn" action [SetField(persistent, "dev_floor", None), Start("start_full")]
        textbutton "เดโม (5 นาที)" at cr_btn_in(0.55) style "cr_menu_btn" action Start()
        textbutton "วิธีเล่น" at cr_btn_in(0.6) style "cr_menu_btn" action Show("cr_howto")
        textbutton "ตั้งค่า" at cr_btn_in(0.7) style "cr_menu_btn" action Show("cr_settings")
        if not renpy.variant("web"):
            textbutton "ออกจากเกม" at cr_btn_in(0.8) style "cr_menu_btn" action Quit(confirm=False)

    # ข้อมูลด้านล่าง
    # แตะข้อความนี้ 5 ครั้งเพื่อเปิดช่องใส่รหัสทดสอบ (ไม่มีอะไรบอกผู้เล่น)
    button:
        xpos 120
        yalign 1.0
        yoffset -40
        background None
        padding (0, 0)
        action If(secret_taps >= 4, [SetScreenVariable("secret_taps", 0), Show("cr_devcode")], SetScreenVariable("secret_taps", secret_taps + 1))
        text "เรื่องเต็ม 10 ชั้น  |  เดโม 3 ชั้น 5 นาที  |  สอนพื้นฐานการเข้ารหัส":
            style "cr_muted"
            outlines [(2, "#0d0b14", 0, 0)]

    text "คลิกเพื่อเลือก":
        style "cr_muted"
        xalign 1.0
        yalign 1.0
        xoffset -50
        yoffset -40
        at cr_blink_slow

# ---------- หน้าตั้งค่า (ใช้ได้ทั้งในล็อบบี้และระหว่างเล่น) ----------

screen cr_settings():

    modal True
    zorder 150

    key "game_menu" action Hide("cr_settings")

    use cr_panel(1180, 780):

        fixed:
            xysize (1108, 724)

            text "ตั้งค่า" style "cr_title"
            textbutton "ปิด":
                style "cr_btn"
                xalign 1.0
                action Hide("cr_settings")

            vbox:
                ypos 110
                spacing 34

                hbox:
                    spacing 20
                    text "เพลง" style "cr_label"
                    bar value Preference("music volume") style "cr_hbar"

                hbox:
                    spacing 20
                    text "เสียงเอฟเฟกต์" style "cr_label"
                    bar value Preference("sound volume") style "cr_hbar"
                    textbutton "ทดสอบ" style "cr_btn" action Play("sound", "audio/sfx_item.ogg") yalign 0.5

                hbox:
                    spacing 20
                    text "ความเร็วข้อความ" style "cr_label"
                    bar value Preference("text speed") style "cr_hbar"

                hbox:
                    spacing 20
                    text "ปิดเสียงทั้งหมด" style "cr_label"
                    textbutton "เปิด" style "cr_opt_btn" action Preference("all mute", "disable")
                    textbutton "ปิดเสียง" style "cr_opt_btn" action Preference("all mute", "enable")

                if not renpy.variant("web"):
                    hbox:
                        spacing 20
                        text "การแสดงผล" style "cr_label"
                        textbutton "หน้าต่าง" style "cr_opt_btn" action Preference("display", "window")
                        textbutton "เต็มจอ" style "cr_opt_btn" action Preference("display", "fullscreen")

            hbox:
                yalign 1.0
                spacing 16
                if not main_menu:
                    if renpy.has_screen("save"):
                        textbutton "เซฟเกม" style "cr_btn" action ShowMenu("save")
                    if renpy.has_screen("load"):
                        textbutton "โหลด" style "cr_btn" action ShowMenu("load")
                    textbutton "กลับหน้าล็อบบี้" style "cr_btn" action MainMenu(confirm=False)
                if not renpy.variant("web"):
                    text "กด F เพื่อสลับเต็มจอได้ทุกเมื่อ" style "cr_muted" yalign 0.5

# ---------- หน้าวิธีเล่น ----------

screen cr_howto():

    modal True
    zorder 150

    key "game_menu" action Hide("cr_howto")

    use cr_panel(1300, 820):

        fixed:
            xysize (1228, 764)

            text "วิธีเล่น" style "cr_title"
            textbutton "ปิด":
                style "cr_btn"
                xalign 1.0
                action Hide("cr_howto")

            vbox:
                ypos 100
                spacing 22
                xsize 1228

                text "คุณถูกขังอยู่ชั้นบนสุดของตึกร้าง ประตูทุกชั้นล็อกด้วยรหัสลับ ต้องถอดรหัสให้ได้เพื่อลงไปชั้นถัดไป" style "cr_body"

                null height 4
                text "{color=#ffd86b}1. สำรวจ{/color}  คลิกวัตถุหรือเครื่องหมาย {color=#ffd86b}!{/color} ในห้อง เพื่ออ่านเบาะแส" style "cr_body"
                text "{color=#ffd86b}2. เรียนรู้{/color}  ความรู้ที่เจอจะเข้า {color=#5be3a1}สมุดโน้ต{/color} อัตโนมัติ (ปุ่มขวาบน หรือกด N)" style "cr_body"
                text "{color=#ffd86b}3. ถอดรหัส{/color}  คลิกประตู แล้วใช้ {color=#5be3a1}เครื่องมือ{/color} ในเกมช่วยแปลงรหัส" style "cr_body"
                text "{color=#ffd86b}4. ติดขัด?{/color}  กดขอคำใบ้ได้ 3 ระดับ หรือดูวิธีทำทีละขั้น" style "cr_body"

                null height 4
                text ("ปุ่มลัด:  N = สมุดโน้ต   M = แผนผังตึก" + ("" if renpy.variant("web") else "   F = เต็มจอ")) style "cr_muted"
