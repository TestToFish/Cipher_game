# ==========================================================================
#  script_full.rpy : ลำดับเกมของเวอร์ชันเต็ม (ชั้น F10 - F1)
#  บทในไฟล์นี้เป็น "ร่างใช้งาน" ให้เล่นได้ครบทุกชั้นและทุกตอนจบ
#  บทจริง/คัตซีนเต็มจะเขียนในขั้น M2 แล้วมาแทนที่ทีละ label
#  ตัวแปรที่ใช้แทรกในบท ([x]) ต้องตั้งค่าด้วย $ ก่อนบรรทัดนั้น
# ==========================================================================

# --------------------------------------------------------------------------
#  เริ่มเรื่องเต็ม (C0)
# --------------------------------------------------------------------------

label start_full:

    $ mode = "full"
    $ new_full_run()
    $ t_start = time.time()
    $ current_room = "F10"
    $ unlocked = ["F10"]
    $ items_got.append("brass_key")

    # โหมดทดสอบ: เริ่มที่ชั้นที่เลือกจากหน้าล็อบบี้
    if persistent.dev and persistent.dev_floor:
        $ dev_unlock_to(persistent.dev_floor)
        $ current_room = persistent.dev_floor
        $ persistent.dev_floor = None
        jump enter_room

    stop music fadeout 2.0
    scene expression BG("images/bg_d1.jpg")
    with fade
    "คืนนั้นตึกสูงร้างกลางเมืองยืนนิ่งอยู่ในหมอก ทั้งตึกมืดสนิท"
    "ยกเว้นหน้าต่างบานเดียวที่ชั้นบนสุด"

    scene black
    with fade
    "เสียงฮัมเบา ๆ ของเครื่องคอมพิวเตอร์ปลุกเชนขึ้นมา"
    show kid worry at kid_pos
    me "...ที่นี่ที่ไหน"
    "สิ่งสุดท้ายที่จำได้ คือพี่ผู้ชายคนหนึ่งเข้ามาทักหน้าโรงเรียน บอกว่าเป็นลูกศิษย์ของตา"
    "มือของเชนคว้าไปที่คอโดยอัตโนมัติ กุญแจทองเหลืองดอกเล็กยังห้อยอยู่ที่เดิม"
    me sad "ยังอยู่... ของจากตาที่ผมไม่เคยเจอหน้า"
    $ renpy.notify("บันทึกลงสมุดโน้ตแล้ว: กุญแจทองเหลือง")
    jump enter_room


# --------------------------------------------------------------------------
#  จุดสำรวจทั่วไป / จดหมาย
# --------------------------------------------------------------------------

label fs_generic(sid):
    $ spot_label = SPOTS[sid]["label"]
    show kid think at kid_pos
    "เชนลองสำรวจ[spot_label]ดู แต่ไม่พบอะไรเป็นพิเศษ"
    return

label show_letter(n):
    $ read_letter(n)
    call screen cr_letter(n)
    return


# --------------------------------------------------------------------------
#  ชั้น 10: ห้องขัง (Caesar บอก shift)
# --------------------------------------------------------------------------

label fintro_F10:
    show kid worry at kid_pos
    "ห้องแคบ ๆ ประตูเหล็กถูกล็อกจากด้านนอก มีโปสเตอร์ตัวอักษร ชั้นหนังสือ และคอมพิวเตอร์เครื่องเก่า"
    me determined "ต้องหาทางออกไปให้ได้ ลองมองหาเครื่องหมาย ! ดูก่อน"
    call tip_explore
    return

label fs_F10_poster:
    show kid think at kid_pos
    "โปสเตอร์แถบตัวอักษรสองแถว แถวบนกับแถวล่างเลื่อนไม่ตรงกัน"
    me "เหมือนมีคนจงใจเลื่อนตัวอักษรไปทีละช่อง"
    return

label fs_F10_shelf:
    show kid surprised at kid_pos
    "หนังสือเรื่องรหัสลับเรียงเต็มชั้น มีซองจดหมายเก่าเหน็บอยู่ระหว่างเล่ม"
    me "หน้าซองเขียนว่า... คีรี"
    return

label fs_F10_tally:
    show kid worry at kid_pos
    "รอยขีดนับวันเป็นกลุ่มละห้าขีด เต็มผนังเกือบทั้งด้าน"
    me "มีคนอยู่ที่นี่มานานมาก... นานเป็นปีเลย"
    return

label fs_F10_desk:
    $ s10 = gen["P10"]["clue"]["shift"]
    show kid surprised at kid_pos
    "กระดาษโน้ตแปะข้างจอคอมพิวเตอร์ เขียนด้วยลายมือเร่งรีบ"
    me happy "“รหัสประตูชั้นนี้ใช้ shift [s10]”... นี่คือกุญแจ!"
    return

label fsolved_P10:
    show kid think at kid_pos
    "เสียงกลอนประตูคลายออก"
    scene expression BG("images/bg_d3.jpg")
    with dissolve
    play sound "audio/sfx_crt.ogg"
    "จอคอมพิวเตอร์สว่างวาบขึ้นมาเอง"
    unk "เร็วกว่าที่คิดนะ ยินดีด้วยกับบทเรียนแรก"
    show kid angry at kid_pos
    call screen cr_choice(["ถามอย่างใจเย็น: “คุณเป็นใคร”", "ตะโกนใส่จอ: “ปล่อยผมออกไป!”"])
    if _return == 0:
        $ add_trust(1)
        me "คุณเป็นใคร แล้วพาผมมาที่นี่ทำไม"
        unk "อีกไม่นานเธอจะรู้เอง ตอนนี้เรียนไปทีละชั้นก่อน"
    elif _return == 1:
        $ add_trust(-1)
        me "ปล่อยผมออกไปเดี๋ยวนี้!"
        unk "ประตูทุกบานเปิดได้ เธอแค่ต้องเข้าใจมัน"

    "จอดับลง เหลือเพียงเสียงฮัมของเครื่อง"
    return


# --------------------------------------------------------------------------
#  ชั้น 9: สำนักงาน (Atbash หรือ ROT13)
# --------------------------------------------------------------------------

label fintro_F9:
    show kid think at kid_pos
    "สำนักงานร้าง ลมเย็นโกรกผ่านหน้าต่างที่แตก กระดาษปลิวไปทั่ว"
    me "ครั้งนี้ไม่มีโน้ตบอกกุญแจ ต้องดูว่ารหัสสร้างมาแบบไหน"
    return

label fs_F9_board:
    show kid think at kid_pos
    "กระดาษข้างประตูเขียนตัวอักษรสองแถว แถวบน A ถึง M แถวล่าง Z ย้อนกลับมาถึง N"
    me "เหมือนเงาในกระจกเลย A คู่กับ Z"
    return

label fs_F9_disk:
    show kid surprised at kid_pos
    "จานทองเหลืองสองชั้นหมุนได้ วางอยู่ใต้โคมไฟ"
    me "เครื่องมือถอดรหัสซีซาร์ของจริง"
    return

label fs_F9_cabinet:
    show kid think at kid_pos
    "ในลิ้นชักมีแฟ้มรายงานกับซองจดหมายอีกฉบับ"
    me "“ROT13 เลื่อนครึ่งทาง เข้ารหัสสองรอบได้ข้อความเดิม”... แล้วซองนี้ก็ลงชื่อคีรีอีกแล้ว"
    return

label fs_F9_window:
    show kid worry at kid_pos
    "หน้าต่างบานใหญ่ กระจกแตกหลายบาน ข้างล่างมืดสนิท"
    me "ถ้ากุญแจมีให้ลองแค่ไม่กี่แบบ... ลองทีละอันก็ได้นี่นา"
    return

label fsolved_P9:
    show kid happy at kid_pos
    "ประตูเปิดออก ลมจากช่องบันไดพัดเข้ามา"
    me "รหัสที่ไม่มีกุญแจ ใครรู้วิธีก็อ่านได้หมด"
    return


# --------------------------------------------------------------------------
#  ชั้น 8: ห้อง IT (Caesar ซ่อน shift)
# --------------------------------------------------------------------------

label fintro_F8:
    show kid think at kid_pos
    "ห้อง IT เสียงพัดลมครางต่ำ ไฟบนตู้เซิร์ฟเวอร์กะพริบ"
    me "รหัสซีซาร์อีกแล้ว แต่ไม่รู้ shift... กุญแจต้องซ่อนอยู่ที่ไหนสักแห่ง"
    return

label fs_F8_rack:
    show kid think at kid_pos
    "ป้ายบนตู้เขียนว่า “ทุกคนรู้วิธีได้ ขอแค่เก็บกุญแจไว้ให้ดี”"
    return

label fs_F8_board:
    show kid surprised at kid_pos
    "ไวท์บอร์ดมีขีดเรียงเป็นกลุ่ม ๆ แบบนับคะแนน"
    me "นับดี ๆ นะ... ขีดพวกนี้อาจเป็นตัวเลขที่ซ่อนไว้"
    return

label fs_F8_manual:
    show kid surprised at kid_pos
    "ใต้หนังสือคู่มือบนพื้น มีซองจดหมายสีครีมสอดไว้"
    return

label fs_F8_desk:
    show kid happy at kid_pos
    "โน้ตแปะข้างคอมพิวเตอร์: “กันลืม: กุญแจจดไว้บนไวท์บอร์ดเป็นขีด ๆ”"
    me "เขียนบอกตำแหน่งกุญแจไว้เองเลย"
    return

label fsolved_P8:
    show kid think at kid_pos
    "กลอนประตูคลายออก"
    me "จดหมายพวกนี้... คนชื่อคีรีเป็นใครกันนะ"
    return


# --------------------------------------------------------------------------
#  ชั้น 7: ห้องพักร้าง (Base64 / ฐานสอง / ฐานสิบหก)
# --------------------------------------------------------------------------

label fintro_F7:
    show kid sad at kid_pos
    "ห้องพักเล็ก ๆ ที่เหมือนเจ้าของรีบออกไป ของใช้ยังวางอยู่ครบ"
    me "ห้องนี้... อบอุ่นแปลก ๆ"
    return

label fs_F7_fridge:
    show kid surprised at kid_pos
    "ในตู้เย็นมีขนมปังกับน้ำขวดใหม่เอี่ยม วันหมดอายุยังอีกนาน"
    me "มีคนเตรียมไว้ให้ผม...?"
    return

label fs_F7_shelf:
    show kid think at kid_pos
    "หนังสือคอมพิวเตอร์เล่มหนา เปิดค้างหน้าตาราง ASCII"
    return

label fs_F7_tv:
    show kid think at kid_pos
    "ทีวีเก่าแสดงตัวเลขชุดเดิมซ้ำไปซ้ำมา"
    me "ตัวเลขเดียวกับบนจอที่ประตู"
    return

label fs_F7_photo:
    $ flags.add("photo")
    show kid surprised at kid_pos
    "กรอบรูปคว่ำอยู่บนตู้ เชนพลิกขึ้นมาดู"
    "ชายแก่ใส่แว่นยิ้มกว้าง ห้อยกุญแจทองเหลืองดอกเล็กไว้ที่คอ"
    me "กุญแจแบบเดียวกับของผม..."
    return

label fs_F7_sofa:
    show kid think at kid_pos
    "ใต้เบาะโซฟามีซองจดหมายซ่อนอยู่"
    return

label fs_F7_clock:
    $ hh = gen["P7"]["clue"]["hour"]
    $ mm = "%02d" % gen["P7"]["clue"]["minute"]
    show kid think at kid_pos
    "นาฬิกาแขวนหยุดเดินที่ [hh]:[mm]"
    return

label fsolved_P7:
    show kid happy at kid_pos
    "ประตูเปิดออก"
    me "แปลงรูปแบบไม่ใช่การเก็บความลับ ใครก็แปลงกลับได้"
    return


# --------------------------------------------------------------------------
#  ชั้น 6: ห้องพักน้ำรั่ว (Substitution) + C3
# --------------------------------------------------------------------------

label fintro_F6:
    show kid sad at kid_pos
    "ห้องชื้นและเงียบ ได้ยินแต่เสียงน้ำหยดลงถัง"
    return

label fs_F6_bed:
    show kid think at kid_pos
    "ใต้หมอนเปียก ๆ มีซองจดหมายห่อพลาสติกไว้อย่างดี"
    return

label fs_F6_stain:
    show kid surprised at kid_pos
    "บนคราบน้ำมีตัวอักษรเขียนเป็นคู่ ๆ ด้วยปากกาเมจิก"
    me "ซ้ายคือตัวในรหัส ขวาคือตัวจริง... คีย์บางส่วนของรหัสสลับ"
    return

label fs_F6_bucket:
    show kid think at kid_pos
    "ถังน้ำเกือบเต็ม น้ำหยดลงมาเป็นจังหวะ"
    return

label fs_F6_window:
    show kid worry at kid_pos
    "นอกหน้าต่างมีแต่ความมืด"
    return

label fs_F6_desk:
    show kid think at kid_pos
    "สมุดเปียกบนโต๊ะอธิบายรหัสสลับตัวอักษร"
    return

label fs_F6_camera:
    $ flags.add("c3")
    show kid surprised at kid_pos
    "กล้องวงจรปิดที่มุมเพดาน ไฟสีแดงกะพริบ"
    play sound "audio/sfx_crt.ogg"
    show zerowin normal at zerowin_pos
    unk "ใช่ ฉันเห็นทุกอย่าง ตั้งแต่ชั้นสิบ"
    call screen cr_choice(["จ้องกล้องกลับ: “แล้วเห็นอะไรบ้าง”", "หันหลังให้กล้อง"])
    if _return == 0:
        $ add_trust(1)
        unk smile "เห็นเด็กคนหนึ่งที่เรียนรู้เร็วกว่าที่ฉันเคยเป็น"
    elif _return == 1:
        $ add_trust(-1)
        unk "หันหลังไปก็ไม่เป็นไร ฉันแค่อยากให้เธอลงมาถึงข้างล่างได้"

    hide zerowin
    return

label fsolved_P6:
    show kid happy at kid_pos
    "ประตูบวมน้ำเปิดออกอย่างฝืด ๆ"
    return


# --------------------------------------------------------------------------
#  ชั้น 5: ห้องเครื่อง (Frequency analysis) + C4 ทางแยก A
# --------------------------------------------------------------------------

label fintro_F5:
    show kid worry at kid_pos
    "ห้องเครื่องอึดอัด สายไฟห้อยเป็นเถา ประกายไฟแลบเป็นพัก ๆ"
    return

label fs_F5_fuse:
    show kid surprised at kid_pos
    "ตู้ฟิวส์เปิดค้าง ประกายไฟกระเด็นออกมา"
    me "ไม่แตะดีกว่า"
    return

label fs_F5_generator:
    show kid think at kid_pos
    "ซองจดหมายเหน็บอยู่ข้างเครื่องปั่นไฟ อุ่นจากความร้อนของเครื่อง"
    return

label fs_F5_toolbox:
    show kid think at kid_pos
    "กล่องเครื่องมือมีไขควงกับคีม ไม่มีอะไรช่วยเปิดประตูได้"
    return

label fs_F5_gauges:
    show kid think at kid_pos
    "ป้ายใต้หน้าปัดเขียนตัวอักษรเรียงตามความถี่: E T A O I N"
    return

label fs_F5_paper:
    show kid surprised at kid_pos
    "กระดาษต่อเนื่องยาวเหยียด พิมพ์ตัวอักษรที่ถูกสลับเต็มหน้า"
    me "ยาวขนาดนี้... ยิ่งยาวยิ่งนับได้ว่าตัวไหนเจอบ่อย"
    return

label fs_F5_intercom:
    if "c4" not in flags:
        call fc4
    else:
        show kid think at kid_pos
        "ลำโพงเงียบไปแล้ว"
    return

label fc4:
    $ flags.add("c4")
    show kid think at kid_pos
    "ลำโพงอินเตอร์คอมส่งเสียงซ่า"
    play sound "audio/sfx_crt.ogg"
    show zerowin normal at zerowin_pos
    unk "ฉันมีข้อเสนอ ตอบคำถามฉันตามความจริง แล้วฉันจะส่งคำใบ้ฟรีให้ชั้นต่อไป"
    unk "เธอโกรธฉันไหม"
    call screen cr_choice(["บอกตามจริง: “โกรธ แต่ก็อยากรู้ว่าทำไม”", "โกหก: “ไม่โกรธเลย”", "ไม่ตอบ"])
    if _return == 0:
        $ choice_a = "honest"
        $ add_trust(2)
        $ free_hints += 2
        show kid angry at kid_pos
        me "โกรธ แต่ผมอยากรู้ว่าคุณทำแบบนี้ทำไม"
        unk "...ขอบคุณที่พูดตรง ๆ สัญญาเป็นสัญญา"
    elif _return == 1:
        $ choice_a = "lie"
        $ add_trust(-1)
        $ free_hints += 1
        me "ไม่โกรธเลย"
        unk "กล้องเห็นมือเธอกำแน่นนะ แต่ก็ได้ ให้หนึ่งข้อ"
    elif _return == 2:
        $ choice_a = "refuse"
        show kid determined at kid_pos
        me "..."
        unk "งั้นก็ไปต่อเองนะ"

    hide zerowin
    return

label fsolved_P5:
    show kid happy at kid_pos
    "ประตูเหล็กหนักเปิดออก"
    me "ต่อให้สลับตัวอักษรยังไง ตัว E ก็ยังเจอบ่อยที่สุดอยู่ดี"
    return


# --------------------------------------------------------------------------
#  ชั้น 4: ห้องเครื่องน้ำท่วม (Vigenère) + C5 ย้อนอดีต
# --------------------------------------------------------------------------

label fintro_F4:
    show kid worry at kid_pos
    "น้ำนิ่งท่วมถึงข้อเท้า สะท้อนแสงไฟเหมือนกระจก"
    return

label fs_F4_valves:
    show kid think at kid_pos
    "วาล์วสนิมเขรอะ หมุนไม่ไป"
    return

label fs_F4_crate:
    show kid think at kid_pos
    "ลังไม้ลอยน้ำ ข้างในแห้งสนิท มีซองจดหมายวางอยู่"
    return

label fs_F4_board:
    show kid think at kid_pos
    "กระดานดำมีคำภาษาอังกฤษเขียนไว้หลายคำ หน้าตาคล้ายกันมาก"
    return

label fs_F4_tags:
    show kid think at kid_pos
    "ป้ายโลหะห้อยอยู่ห้าใบ แต่ละใบสลักคำไว้ โน้ตบนท่อเขียนว่า “คีย์เวิร์ดคือคำที่อยู่ทั้งบนกระดานและบนป้าย”"
    return

label fs_F4_tape:
    $ flags.add("c5")
    show kid surprised at kid_pos
    "เชนกดปุ่มเล่นเทป เสียงชายแก่ดังขึ้นท่ามกลางเสียงซ่า"
    hide kid
    show drkey smile at drkey_pos
    with dissolve
    drkey "วันนี้เราจะเรียน Vigenère กัน ซีซาร์ใช้กุญแจตัวเดียว Vigenère ใช้คำทั้งคำ"
    drkey "ตัวอักษรแต่ละตัวจึงเลื่อนไม่เท่ากัน... ใส่หูฟังอีกแล้วเหรอ ฟังตาบ้างสิ"
    drkey worry "...เธอจดเก่งนะ แต่ตาอยากให้เธอเข้าใจด้วย"
    hide drkey
    with dissolve
    show kid think at kid_pos
    me "เสียงในเทปนี่... คือคีรีงั้นเหรอ"
    return

label fsolved_P4:
    show kid happy at kid_pos
    "ประตูกันน้ำหมุนเปิดออก"
    return


# --------------------------------------------------------------------------
#  ชั้น 3: ห้อง CCTV (XOR) + C6 รู้ว่าเป็นหลาน
# --------------------------------------------------------------------------

label fintro_F3:
    show kid worry at kid_pos
    "ไฟฉุกเฉินสีแดงทั้งห้อง จอหลายสิบจอส่องแสงสลับกันไปมา"
    me "บางจอ... คือห้องที่ผมเพิ่งเดินผ่านมา"
    return

label fs_F3_locker:
    show kid think at kid_pos
    "ล็อกเกอร์เปิดแง้ม มีซองจดหมายวางอยู่บนชั้น"
    return

label fs_F3_fan:
    show kid think at kid_pos
    "พัดลมระบายอากาศหมุนช้า ๆ"
    return

label fs_F3_monitors:
    if "c6" not in flags:
        call fc6
    else:
        show kid sad at kid_pos
        "จอยังฉายภาพเก่าวนไปมา"
    return

label fc6:
    $ flags.add("c6")
    show kid surprised at kid_pos
    "จอกลางเปลี่ยนเป็นภาพบันทึกเก่า ชายแก่ในรูปถ่ายกำลังอุ้มทารก"
    "เขาเอากุญแจทองเหลืองใส่ซองพร้อมจดหมาย แล้วจ่าหน้าซองถึงลูกสาว"
    show kid sad at kid_pos
    me "นั่นชื่อแม่ผม..."
    me "คีรี... ดร.คีย์... คือตาของผม"
    return

label fs_F3_lamp:
    show kid think at kid_pos
    "ใต้โคมไฟมีเอกสารอธิบาย XOR วางอยู่ข้างถ้วยกาแฟเย็นชืด"
    return

label fs_F3_switches:
    show kid think at kid_pos
    "สวิตช์ 8 ตัวเรียงกัน เหนือแต่ละตัวมีไฟดวงเล็ก บางดวงติด บางดวงดับ"
    return

label fs_F3_console:
    show kid think at kid_pos
    "จอเล็กแสดงข้อความ “กำลังบันทึก”"
    return

label fsolved_P3:
    if "c6" not in flags:
        call fc6
    show kid determined at kid_pos
    "ประตูเปิดออก"
    return


# --------------------------------------------------------------------------
#  ชั้น 2: ห้องรักษาความปลอดภัย (Hash) + C7 ทางแยก B
# --------------------------------------------------------------------------

label fintro_F2:
    show kid think at kid_pos
    "ห้องยาม มีเตียงพับกับเสื้อฮู้ด มีคนอาศัยอยู่ที่นี่จริง ๆ"
    me "หน้าต่างบานนั้นมองลงไปเห็นล็อบบี้แล้ว"
    return

label fs_F2_safe:
    if "S2" not in solved:
        show kid think at kid_pos
        "ตู้เซฟใช้ PIN 3 หลัก ป้ายข้างตู้มีแค่ค่า hash ของ PIN"
        call run_puzzle("S2")
    if "S2" in solved and 9 not in letters_read:
        "ในตู้เซฟมีซองจดหมายวางอยู่ซองเดียว"
        call show_letter(9)
    elif "S2" in solved:
        "ตู้เซฟว่างเปล่าแล้ว"
    return

label fsolved_S2:
    "ตู้เซฟเปิดออกเสียงดังคลิก"
    return

label fs_F2_board:
    show kid think at kid_pos
    "บอร์ดมีรายการรหัสผ่านยอดนิยม หัวกระดาษเขียนว่า “ห้ามใช้รหัสพวกนี้!”"
    return

label fs_F2_terminal:
    show kid think at kid_pos
    "คอมพิวเตอร์ยามเปิดโปรแกรม hash ค้างไว้"
    return

label fs_F2_headphones:
    show kid surprised at kid_pos
    "หูฟังบนโต๊ะยังอุ่นอยู่"
    me "เด็กชายใส่หูฟังในจดหมาย..."
    return

label fs_F2_keys:
    show kid think at kid_pos
    "ตู้กุญแจว่างเปล่า ทุกตะขอไม่มีกุญแจเลยสักดอก"
    return

label fs_F2_window:
    show kid worry at kid_pos
    "มองลงไปเห็นล็อบบี้มืด ๆ มีไฟแดงดวงเล็กที่ประตูบานกลม"
    return

label fs_F2_cot:
    show kid sad at kid_pos
    "เตียงพับกับผ้าห่มยับ ๆ บนเก้าอี้มีเสื้อฮู้ดสีเทาพาดอยู่"
    return

label fsolved_P2:
    call fc7
    return

label fc7:
    $ flags.add("c7")
    show kid determined at kid_pos
    "ประตูเปิดออก แต่มีคนยืนขวางอยู่"
    show zero normal at zero_pos
    with dissolve
    zero "ฉันชื่อซีโร่ ลูกศิษย์คนสุดท้ายของดร.คีย์"
    zero guilty "ฉันเป็นคนพาเธอมาที่นี่ ขอโทษ ฉันรู้ว่าวิธีนี้ผิด"
    zero "อาจารย์หายไปสามปี ทิ้งไว้แค่ประตูห้องกุญแจหลักที่ฉันเปิดไม่ได้ กับจดหมายที่เขียนว่า หลานของฉันจะเป็นคนเปิดได้"
    zero cold "ฉันท่องได้ทุกสูตร แต่ประตูบานนั้นไม่สนว่าฉันจำอะไรได้ มันถามว่าฉันเข้าใจหรือเปล่า"
    zero normal "ช่วยฉันเปิดห้องนั้นได้ไหม"
    call screen cr_choice(["ช่วย", "ต่อรอง: “ช่วย ถ้าพี่พาผมกลับบ้านและบอกแม่ทุกอย่าง”", "ปฏิเสธ แล้วไปคนเดียว"])
    if _return == 0:
        $ choice_b = "help"
        $ add_trust(2)
        show kid gentle at kid_pos
        me "ผมจะช่วย ผมก็อยากรู้ว่าตาทิ้งอะไรไว้"
        zero smile "...ขอบคุณ"
    elif _return == 1:
        $ choice_b = "deal"
        $ add_trust(1)
        show kid determined at kid_pos
        me "ผมช่วยได้ แต่พี่ต้องพาผมกลับบ้าน แล้วบอกแม่ทุกอย่างด้วยตัวเอง"
        zero guilty "...ได้ ฉันสัญญา"
    elif _return == 2:
        $ choice_b = "refuse"
        $ add_trust(-2)
        show kid angry at kid_pos
        me "พี่ขังผมไว้ แล้วยังจะให้ผมช่วยอีกเหรอ ผมจะไปคนเดียว"
        zero guilty "...เข้าใจแล้ว"

    hide zero
    with dissolve
    return


# --------------------------------------------------------------------------
#  ชั้น 1: ล็อบบี้ (ด่านรวม) + C8 ทางแยก C
# --------------------------------------------------------------------------

label fintro_F1:
    show kid worry at kid_pos
    "ล็อบบี้สูงสองชั้น เย็นยะเยือกและเงียบสนิท แสงจันทร์ส่องเข้ามาลำเดียว"
    me "ประตูหน้า คันโยกแดง แล้วก็ประตูบานกลม... แผงควบคุมอยู่ที่เคาน์เตอร์"
    return

label fs_F1_counter:
    $ renpy.pop_call()
    $ explored.add("F1_counter")
    if door_done("F1"):
        show kid think at kid_pos
        "แผงควบคุมปลดล็อกแล้ว"
        jump explore
    jump door_interact

label fs_F1_stairs:
    $ renpy.pop_call()
    $ explored.add("F1_stairs")
    show kid think at kid_pos
    "บันไดกลับขึ้นไปชั้นบน (เปิดแผนผังเพื่อเลือกชั้นได้)"
    hide kid
    $ renpy.show_screen("cr_map_full")
    jump explore

label fs_F1_painting:
    show kid surprised at kid_pos
    "หลังภาพวาดมีซองจดหมายเหน็บไว้ หน้าซองเขียนว่า ถึงเชน"
    return

label fs_F1_chandelier:
    show kid worry at kid_pos
    "โคมระย้าตกลงมาแตกกระจาย เศษคริสตัลสะท้อนแสงไฟแดง"
    return

label f1_unlocked:
    $ flags.add("c8")
    show kid determined at kid_pos
    "แผงควบคุมส่งเสียงยาว ไฟทั้งล็อบบี้สว่างขึ้น"
    if choice_b in ("help", "deal"):
        show zero normal at zero_pos
        zero "ประตูหน้าเปิดได้แล้ว คันโยกนั่นปิดระบบทั้งตึก ส่วนห้องกุญแจหลัก... ต้องใช้กุญแจส่วนตัว"
        hide zero
    me "ทางออก ห้องของตา หรือทำลายทุกอย่าง... ต้องเลือกแล้ว"
    jump explore

label fs_F1_frontdoor:
    $ renpy.pop_call()
    $ explored.add("F1_frontdoor")
    if not door_done("F1"):
        show kid think at kid_pos
        "ประตูหน้าถูกล็อกด้วยแผงควบคุมที่เคาน์เตอร์"
        jump explore
    show kid think at kid_pos
    call screen cr_choice(["ออกจากตึกทางประตูหน้า", "ยังก่อน"])
    if _return == 0:
        $ choice_c = "exit"
        jump fend_route
    elif _return == 1:
        jump explore

label fs_F1_lever:
    $ renpy.pop_call()
    $ explored.add("F1_lever")
    if not door_done("F1"):
        show kid think at kid_pos
        "คันโยกถูกล็อกไว้ใต้ฝาครอบกระจก"
        jump explore
    show kid worry at kid_pos
    "ป้ายเตือนข้างคันโยก: “ทำลายระบบล็อกและข้อมูลทั้งหมดในตึก”"
    call screen cr_choice(["ดึงคันโยก", "ไม่ดีกว่า"])
    if _return == 0:
        $ choice_c = "destroy"
        jump fend_route
    elif _return == 1:
        jump explore

label fs_F1_vault:
    $ renpy.pop_call()
    $ explored.add("F1_vault")
    if not door_done("F1"):
        show kid think at kid_pos
        "ประตูบานกลมไม่ขยับ ไฟสถานะยังเป็นสีแดง"
        jump explore
    if letters_count() < 8 and "L3" not in solved:
        show kid sad at kid_pos
        "บนประตูมีตัวเลขเรียงกัน กับรูกุญแจทองเหลือง"
        me "ผมยังไม่เข้าใจว่าต้องทำยังไง... ถ้าได้อ่านจดหมายของตามากกว่านี้คงรู้"
        $ renpy.notify("ลองเก็บจดหมายของดร.คีย์ให้ได้อย่างน้อย 8 ฉบับ")
        jump explore
    if "L3" not in solved:
        show kid determined at kid_pos
        me "กุญแจสาธารณะอยู่บนประตู กุญแจส่วนตัวอยู่ที่คอผม"
        call run_puzzle("L3")
        if _return != "solved":
            jump explore
    $ choice_c = "vault"
    jump fend_route

label fsolved_L3:
    "รูกุญแจหมุนได้ ประตูบานกลมค่อย ๆ เปิดออก แสงสีทองอุ่น ๆ ลอดออกมา"
    return

label fsolved_L1:
    "ล็อกแรกปลดแล้ว ไฟบนแผงเปลี่ยนเป็นสีเขียวหนึ่งดวง"
    return

label fsolved_L2:
    "ล็อกที่สองปลดแล้ว"
    return


# --------------------------------------------------------------------------
#  ตอนจบ (ร่าง)
# --------------------------------------------------------------------------

label fend_route:
    $ eid = ending_id()
    $ persistent.endings_seen = set(persistent.endings_seen or set()) | set([eid])
    hide kid
    hide zero
    hide zerowin
    play music "audio/music_ending.ogg" fadein 2.0
    call expression ("fend_" + str(eid))
    call screen cr_summary_full(eid)
    $ renpy.full_restart()

label fend_1:
    scene expression BG("images/bg_d1.jpg")
    with fade
    "ประตูหน้าเปิดออกสู่อากาศยามเช้า เชนกับซีโร่เดินออกมาด้วยกัน"
    show zero smile at zero_pos
    zero "ฉันจะไปพบแม่ของเธอ แล้วบอกทุกอย่าง"
    show kid gentle at kid_pos
    me "แล้วตึกนี้ล่ะ"
    zero "ถ้าเธอยอมช่วย ฉันอยากเปิดสถาบันกุญแจอีกครั้ง ให้เด็กคนอื่นได้เรียนแบบที่เธอเรียน"
    return

label fend_2:
    scene black
    with fade
    "ในห้องกุญแจหลัก มีสมุดงานวิจัยเรียงเต็มชั้น กับเครื่องเล่นเทปเก่าบนแท่นกลางห้อง"
    show drkey smile at drkey_pos
    with dissolve
    drkey "ถ้าหลานได้ยินเสียงนี้ แปลว่าหลานเข้าใจแล้ว ไม่ได้แค่จำ"
    drkey worry "ตาไม่มีเวลาพอจะรอเจอหลาน ขอโทษนะ ที่มาไม่ทัน"
    drkey smile "ความรู้ในห้องนี้เป็นของหลานแล้ว ส่งต่อมันให้ดีนะ เชน"
    hide drkey
    with dissolve
    show kid sad at kid_pos
    me "...ขอบคุณครับ ตา"
    return

label fend_3:
    scene expression BG("images/bg_d1.jpg")
    with fade
    "เชนออกมาจากตึกคนเดียวตอนรุ่งสาง ปลอดภัยดีทุกอย่าง"
    "แต่เมื่อหันกลับไปมอง หน้าต่างชั้นบนสุดยังมีไฟสว่างอยู่"
    show kid sad at kid_pos
    me "เขายังอยู่ข้างในนั้น..."
    return

label fend_4:
    scene expression BG("images/bg_d1.jpg")
    with fade
    "ไฟไซเรนสีแดงน้ำเงินสะท้อนบนพื้นถนนเปียก ๆ"
    "ซีโร่ถูกจับ ตึกถูกปิดผนึก และไม่มีใครรู้ว่าดร.คีย์ทิ้งอะไรไว้ข้างใน"
    show kid angry at kid_pos
    me "...มันคือสิ่งที่เขาสมควรได้รับ ใช่ไหม"
    return

label fend_5:
    scene expression BG("images/bg_d7.jpg")
    with fade
    "เสียงระเบิดดังกึกก้อง ทุกประตูในตึกปลดล็อกพร้อมกัน"
    "ทุกคนรอดออกมาได้ แต่กระดาษงานวิจัยหลายพันแผ่นปลิวว่อนขึ้นฟ้า แล้วหายไปในความมืด"
    show kid sad at kid_pos
    me "ผมข้ามขั้นตอน... แล้วทุกอย่างที่ตาสร้างไว้ก็หายไป"
    return
