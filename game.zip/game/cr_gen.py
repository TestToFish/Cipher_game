# -*- coding: utf-8 -*-
"""
cr_gen.py : เครื่องสุ่มโจทย์ของ Cipher Tower เวอร์ชันเต็ม (Python ล้วน ไม่พึ่ง Ren'Py)

make_run(seed) -> dict ของโจทย์ทุกชั้นในรอบนั้น (สุ่มจาก seed เดียวกันได้ผลเหมือนเดิมเสมอ)
ทุกโจทย์เป็น dict ธรรมดา (เซฟลงไฟล์เซฟของ Ren'Py ได้)

พิกัด overlay อิงภาพต้นฉบับ 1672x941 เหมือนจุดสำรวจ
ข้อความทั้งหมดห้ามมีเครื่องหมาย [ ] { } (Ren'Py จะตีความเป็นคำสั่ง)
"""
from __future__ import unicode_literals
import random
import base64

ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

# --------------------------------------------------------------------------
# คลังคำ (ตัวพิมพ์ใหญ่ ไม่มีช่องว่าง)
# --------------------------------------------------------------------------
WORDS = [
    "ESCAPE", "SHADOW", "SECRET", "LADDER", "CANDLE", "WINDOW", "GARDEN", "SILVER",
    "MIRROR", "LANTERN", "COMPASS", "JOURNEY", "HIDDEN", "BRIDGE", "FOREST", "CASTLE",
    "ROCKET", "PUZZLE", "TUNNEL", "SIGNAL", "ANCHOR", "BUTTON", "CIRCLE", "FUTURE",
    "GOLDEN", "HARBOR", "ISLAND", "JUNGLE", "KNIGHT", "LEGEND", "MARBLE", "PENCIL",
    "RIBBON", "SPIRAL", "THUNDER", "VELVET", "WINTER", "FALCON", "PLANET", "SUMMER",
]
SHORT_WORDS = ["DOOR", "KEYS", "LAMP", "MOON", "STAR", "EXIT", "HOPE", "LOCK", "OPEN",
               "BYTE", "CODE", "WIRE", "BOLT", "LIGHT", "STAIR", "SPARK", "CLOUD", "STONE", "RIVER"]
RSA_WORDS = ["HOME", "LOVE", "TRUST", "HEART", "LIGHT", "DREAM", "SMILE", "PEACE", "HOPE"]
KEY_WORDS = ["KEY", "LOCK", "GATE", "VAULT", "TOWER", "CHAIN", "CLOCK", "BRASS"]
PASSWORDS = ["SUNSHINE", "DRAGON", "MONKEY", "PASSWORD", "QWERTY", "LETMEIN",
             "FOOTBALL", "PRINCESS", "MASTER", "WELCOME", "FLOWER", "BASEBALL"]
VIG_FAMILIES = [
    ["LOCK", "LOOK", "LUCK", "LACK", "LICK", "ROCK", "SOCK"],
    ["CODE", "CORE", "COVE", "CONE", "MODE", "RODE", "COPE"],
    ["MIND", "MILD", "WIND", "KIND", "BIND", "FIND", "MINT"],
    ["STAR", "STIR", "SCAR", "SOAR", "STAY", "SPAR", "STAB"],
    ["LAMP", "LIMP", "LUMP", "DAMP", "CAMP", "RAMP", "LAMB"],
]
PASSAGES = [
    "LONG AGO PEOPLE SENT SECRET LETTERS BY SWAPPING EVERY LETTER FOR ANOTHER ONE "
    "THE TRICK SEEMED SAFE BUT A CAREFUL READER CAN COUNT WHICH LETTERS APPEAR MOST "
    "OFTEN AND GUESS THE REST THE PASSWORD IS %s",
    "EVERY LANGUAGE HAS A RHYTHM SOME LETTERS APPEAR AGAIN AND AGAIN WHILE OTHERS HIDE "
    "IN RARE WORDS IN ENGLISH THE LETTER E IS THE MOST COMMON AND THE WORD THE IS "
    "EVERYWHERE THE PASSWORD IS %s",
    "THIS MACHINE ROOM WAS BUILT TO KEEP THE TOWER ALIVE THE GENERATOR HUMS ALL NIGHT "
    "AND THE PAPER NEVER STOPS PRINTING IF YOU CAN READ THIS MESSAGE THEN YOU HAVE "
    "LEARNED TO LISTEN TO THE LETTERS THE PASSWORD IS %s",
]
# ตัวเลือก RSA ขนาดจิ๋ว (n > 26 เพื่อให้ A=1..Z=26 เข้ารหัสได้)
RSA_KEYS = [  # (p, q, e, d)
    (3, 11, 3, 7), (5, 7, 5, 5), (3, 13, 5, 5), (5, 11, 3, 27), (3, 17, 3, 11),
]

# --------------------------------------------------------------------------
# อัลกอริทึม
# --------------------------------------------------------------------------
def caesar_enc(t, s):
    return "".join(ALPHA[(ALPHA.index(c) + s) % 26] if c in ALPHA else c for c in t)


def caesar_dec(t, s):
    return caesar_enc(t, -s)


def atbash(t):
    return "".join(ALPHA[25 - ALPHA.index(c)] if c in ALPHA else c for c in t)


def b64enc(t):
    return base64.b64encode(t.encode("ascii")).decode("ascii")


def b64dec(t):
    return base64.b64decode(t.encode("ascii")).decode("ascii")


def sub_enc(t, key):
    """key: dict plain->cipher"""
    return "".join(key.get(c, c) for c in t)


def sub_dec(t, key):
    inv = dict((v, k) for k, v in key.items())
    return "".join(inv.get(c, c) for c in t)


def vig_enc(t, k):
    out, j = [], 0
    for c in t:
        if c in ALPHA:
            out.append(ALPHA[(ALPHA.index(c) + ALPHA.index(k[j % len(k)])) % 26]); j += 1
        else:
            out.append(c)
    return "".join(out)


def vig_dec(t, k):
    out, j = [], 0
    for c in t:
        if c in ALPHA:
            out.append(ALPHA[(ALPHA.index(c) - ALPHA.index(k[j % len(k)])) % 26]); j += 1
        else:
            out.append(c)
    return "".join(out)


def xor_hex(t, key):
    return " ".join("%02X" % (ord(c) ^ key) for c in t)


def xor_unhex(h, key):
    return "".join(chr(int(b, 16) ^ key) for b in h.split())


def rsa_enc(word, n, e):
    return [pow(ALPHA.index(c) + 1, e, n) for c in word]


def rsa_dec(nums, n, d):
    out = []
    for c in nums:
        m = pow(c, d, n)
        out.append(ALPHA[m - 1] if 1 <= m <= 26 else "?")
    return "".join(out)


# ----- SHA-256 แบบ Python ล้วน (ใช้ได้ทุกแพลตฟอร์ม รวมถึงเวอร์ชันเว็บ) -----
_K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]


def sha256_hex(text):
    msg = bytearray(text.encode("utf-8"))
    ml = len(msg) * 8
    msg.append(0x80)
    while (len(msg) * 8) % 512 != 448:
        msg.append(0)
    msg += bytearray((ml >> (8 * (7 - i))) & 0xff for i in range(8))
    h = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]
    M = 0xffffffff
    rotr = lambda x, n: ((x >> n) | (x << (32 - n))) & M
    for off in range(0, len(msg), 64):
        w = [(msg[off + 4 * i] << 24) | (msg[off + 4 * i + 1] << 16) | (msg[off + 4 * i + 2] << 8) | msg[off + 4 * i + 3]
             for i in range(16)]
        for i in range(16, 64):
            s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3)
            s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10)
            w.append((w[i - 16] + s0 + w[i - 7] + s1) & M)
        a, b, c, d, e, f, g, hh = h
        for i in range(64):
            S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
            ch = (e & f) ^ ((~e) & g)
            t1 = (hh + S1 + ch + _K[i] + w[i]) & M
            S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
            mj = (a & b) ^ (a & c) ^ (b & c)
            t2 = (S0 + mj) & M
            hh, g, f, e, d, c, b, a = g, f, e, (d + t1) & M, c, b, a, (t1 + t2) & M
        h = [(x + y) & M for x, y in zip(h, [a, b, c, d, e, f, g, hh])]
    return "".join("%08x" % x for x in h)


def short_hash(text):
    """ค่า hash ที่แสดงในเกม: 16 ตัวแรกของ SHA-256 (ตัวพิมพ์ใหญ่)"""
    return sha256_hex(text)[:16].upper()


# --------------------------------------------------------------------------
# ตัวช่วยสร้างข้อความ
# --------------------------------------------------------------------------
def T(x, y, text, size=26, color="#f2efe6", angle=0, font="mono", stroke=2, stroke_color="#000000aa"):
    """ข้อความวาดทับฉาก: มีเส้นขอบเสมอ ไม่ให้สีกลืนกับพื้นหลัง"""
    return {"kind": "text", "x": x, "y": y, "text": text, "size": size, "color": color,
            "angle": angle, "font": font, "stroke": stroke, "stroke_color": stroke_color}


def note(spot, style, lines, margin=0.08, mx=46):
    """ข้อความบนฉากที่ผูกกับกรอบจุดสำรวจ: เกมจัดให้อยู่ในกรอบ ปรับขนาดเอง และมีพื้นหลังตัดสีเสมอ"""
    return {"kind": "note", "spot": spot, "style": style, "lines": list(lines), "margin": margin, "max": mx}


def _pick(rng, pool, used):
    choices = [w for w in pool if w not in used]
    w = rng.choice(choices)
    used.add(w)
    return w


def _perm_key(rng):
    letters = list(ALPHA)
    while True:
        rng.shuffle(letters)
        if all(a != b for a, b in zip(ALPHA, letters)):
            return dict(zip(ALPHA, letters))


def _base(pid, floor, title, desc, cipher, answer, tool, tool_args, hints, walk, tip, teach):
    return {
        "id": pid, "floor": floor, "title": title, "desc": desc, "cipher": cipher,
        "answer": answer, "tool": tool, "tool_args": tool_args, "hints": hints,
        "walk": walk, "tip": tip, "teach": teach, "success": "fsolved_" + pid,
        "overlays": [], "clue": {}, "items": {},
    }


# --------------------------------------------------------------------------
# โจทย์แต่ละชั้น
# --------------------------------------------------------------------------
def gen_p10(rng, used):
    w = _pick(rng, WORDS, used)
    s = rng.choice([x for x in range(1, 26) if x != 13])
    c = caesar_enc(w, s)
    p = _base("P10", 10, "ประตูชั้น 10",
              "แผ่นป้ายข้างประตูมีรหัสที่ถูกเข้ารหัสไว้ ถอดให้ได้แล้วพิมพ์คำที่ได้",
              c, w, "wheel", {"cipher": c, "auto": False},
              ["มีโน้ตบอกค่า shift อยู่ในห้องนี้ ลองหาดูบนโต๊ะ",
               "รหัสนี้เลื่อนไป %d ตัว ต้องถอยกลับ %d ตัวถึงจะอ่านออก" % (s, s),
               "ตัวแรก %s ถอยกลับ %d ตัวได้ %s ลองตั้งวงล้อเป็น shift = %d" % (c[0], s, w[0], s)],
              "1. โน้ตบนโต๊ะบอกว่า shift = %d\n2. เปิดวงล้อซีซาร์ ตั้ง shift = %d\n"
              "3. ถอดทีละตัว: %s\n4. คำตอบคือ %s" % (s, s, ", ".join("%s เป็น %s" % (a, b) for a, b in zip(c, w)), w),
              "หน้ากรอกรหัสของประตู\n\nใช้ความรู้จากสมุดโน้ตถอดรหัสแล้วพิมพ์คำตอบ กด เครื่องมือ เพื่อเปิดวงล้อซีซาร์\nตอบผิดไม่เสียอะไร และมีคำใบ้เสมอ",
              "caesar")
    p["clue"] = {"shift": s}
    p["items"] = {"clue_p10": {"title": "โน้ตบนโต๊ะ (shift)", "body":
                  "{b}โน้ตลายมือเร่งรีบ{/b}\n\n“รหัสประตูชั้นนี้ใช้ shift %d”\n\nข้อความที่เลื่อนไป %d ตัว ต้องถอยกลับ %d ตัวถึงจะอ่านออก" % (s, s, s)}}
    return p


def gen_p9(rng, used):
    w = _pick(rng, WORDS, used)
    kind = rng.choice(["atbash", "rot13"])
    if kind == "atbash":
        c = atbash(w)
        p = _base("P9", 9, "ประตูชั้น 9", "รหัสชุดนี้ดูเหมือนตัวอักษรถูกสะท้อนในกระจก ถอดแล้วพิมพ์คำที่ได้",
                  c, w, "mirror", {"cipher": c},
                  ["ลองอ่านเรื่องรหัสกระจก (Atbash) ในสมุดโน้ต",
                   "Atbash จับคู่ A กับ Z, B กับ Y, C กับ X ไปเรื่อย ๆ ไม่มีกุญแจเลย",
                   "ตัวแรก %s คู่กับ %s เปิดตารางกระจกในเครื่องมือแล้วถอดทีละตัว" % (c[0], w[0])],
                  "1. Atbash สลับตัวอักษรกับคู่ของมันจากอีกฝั่ง A-Z\n2. เปิดตารางกระจก\n3. ถอดทีละตัว: %s\n4. คำตอบคือ %s"
                  % (", ".join("%s เป็น %s" % (a, b) for a, b in zip(c, w)), w),
                  "ประตูชั้นนี้ไม่มีโน้ตบอกกุญแจ\n\nเพราะรหัสแบบนี้ไม่มีกุญแจเลย ลองสำรวจห้องดูว่ารหัสถูกสร้างอย่างไร", "atbash")
    else:
        c = caesar_enc(w, 13)
        p = _base("P9", 9, "ประตูชั้น 9", "รหัสชุดนี้เลื่อนตัวอักษรไปครึ่งทางของตัวอักษรทั้งหมด ถอดแล้วพิมพ์คำที่ได้",
                  c, w, "wheel", {"cipher": c, "auto": False},
                  ["ลองอ่านเรื่อง ROT13 ในสมุดโน้ต",
                   "ROT13 คือ Caesar ที่ shift = 13 พอดีครึ่งหนึ่งของ 26 ตัว",
                   "ตั้งวงล้อ shift = 13 ตัวแรก %s จะกลายเป็น %s" % (c[0], w[0])],
                  "1. ROT13 = เลื่อน 13 ตัว\n2. เปิดวงล้อซีซาร์ ตั้ง shift = 13\n3. ถอดทีละตัว: %s\n4. คำตอบคือ %s"
                  % (", ".join("%s เป็น %s" % (a, b) for a, b in zip(c, w)), w),
                  "ประตูชั้นนี้ไม่มีโน้ตบอกกุญแจ\n\nลองสำรวจห้องดูว่าคนที่นี่ชอบเลื่อนตัวอักษรไปกี่ตัว", "rot13")
    p["clue"] = {"kind": kind}
    return p


def gen_p8(rng, used):
    w = _pick(rng, WORDS, used)
    s = rng.choice([x for x in range(3, 24) if x != 13])
    c = caesar_enc(w, s)
    p = _base("P8", 8, "ประตูชั้น 8", "รหัสซีซาร์อีกครั้ง แต่คราวนี้ค่า shift ถูกซ่อนไว้ในห้อง หาให้เจอแล้วถอดรหัส",
              c, w, "wheel", {"cipher": c, "auto": False},
              ["มีคนจดว่า กุญแจซ่อนอยู่บนไวท์บอร์ด",
               "นับจำนวนขีดบนไวท์บอร์ด นั่นคือค่า shift",
               "บนไวท์บอร์ดมี %d ขีด ตั้งวงล้อ shift = %d" % (s, s)],
              "1. นับขีดบนไวท์บอร์ดได้ %d ขีด\n2. shift = %d\n3. ถอดทีละตัว: %s\n4. คำตอบคือ %s"
              % (s, s, ", ".join("%s เป็น %s" % (a, b) for a, b in zip(c, w)), w),
              "ด่านนี้รู้วิธีถอดแล้ว แต่ไม่รู้กุญแจ\n\nคนตั้งรหัสซ่อนกุญแจไว้ในห้อง สังเกตให้ดี", "kerckhoffs")
    groups, left = [], s
    while left > 0:
        g = min(5, left); groups.append("|" * g); left -= g
    # ขีดบนไวท์บอร์ด (ผูกกับกรอบจุดสำรวจ F8_board)
    p["overlays"] = [note("F8_board", "marker",
                          ["   ".join(groups[i * 2:(i + 1) * 2]) for i in range((len(groups) + 1) // 2)], mx=52)]
    p["clue"] = {"shift": s}
    return p


def gen_p7(rng, used):
    w = _pick(rng, SHORT_WORDS, used)
    kind = rng.choice(["b64", "bin", "hex"])
    if kind == "b64":
        c = b64enc(w)
        p = _base("P7", 7, "ประตูชั้น 7", "บนจอข้างประตูมีข้อความที่ลงท้ายด้วย = ถอดแล้วพิมพ์คำที่ได้",
                  c, w, "b64", {"cipher": c},
                  ["เครื่องหมาย = ท้ายข้อความคือเบาะแสของ Base64",
                   "Base64 แปลงทีละ 4 ตัวอักษรกลับเป็น 3 ไบต์ ใช้ตัวช่วย Base64",
                   "คลิกตัวอักษรเรียงจากซ้ายไปขวาในตัวช่วย แล้วอ่านตัวอักษร ASCII ที่ได้"],
                  "1. แต่ละตัวอักษรของ Base64 = เลข 0-63 = 6 บิต\n2. รวมบิต แล้วตัดใหม่ชุดละ 8 บิต\n3. แปลงเป็นตัวอักษร ASCII\n4. คำตอบคือ %s" % w,
                  "ข้อความบนจอไม่ใช่รหัสลับ แต่เป็นการแปลงรูปแบบข้อมูล\n\nใช้ตัวช่วย Base64 ในเครื่องมือ", "base64")
    else:
        if kind == "bin":
            c = " ".join(format(ord(ch), "08b") for ch in w)
            how = "เลขฐานสอง 8 หลักต่อตัว"
        else:
            c = " ".join("%02X" % ord(ch) for ch in w)
            how = "เลขฐานสิบหก 2 หลักต่อตัว"
        p = _base("P7", 7, "ประตูชั้น 7", "ทีวีและจอข้างประตูแสดงตัวเลขชุดนี้ซ้ำไปซ้ำมา แปลงกลับเป็นตัวอักษรแล้วพิมพ์คำที่ได้",
                  c, w, "base", {"cipher": c, "base": 2 if kind == "bin" else 16},
                  ["แต่ละกลุ่มตัวเลขคือตัวอักษร 1 ตัว (%s)" % how,
                   "แปลงแต่ละกลุ่มเป็นเลขฐานสิบ แล้วดูตาราง ASCII: 65 = A ไปจนถึง 90 = Z",
                   "กลุ่มแรก %s = %d = %s ใช้ตัวแปลงเลขฐานในเครื่องมือ" % (c.split()[0], ord(w[0]), w[0])],
                  "1. แบ่งเป็นกลุ่ม: %s\n2. แปลงเป็นเลขฐานสิบ: %s\n3. เทียบตาราง ASCII ได้ %s"
                  % (c, ", ".join(str(ord(ch)) for ch in w), w),
                  "คอมพิวเตอร์เก็บตัวอักษรเป็นตัวเลข\n\nใช้ตัวแปลงเลขฐานในเครื่องมือ แปลงทีละกลุ่ม", "ascii")
    hh, mm = rng.randint(1, 12), rng.choice([0, 15, 30, 45])
    # นาฬิกาแขวนในภาพ F7 (กลางราว 1248, 297) + ตัวเลขบนทีวี
    if kind == "b64":
        tv_lines = [c[i:i + 6] for i in range(0, min(len(c), 12), 6)]
    else:
        per = 1 if kind == "bin" else 3
        grp = c.split()
        tv_lines = [" ".join(grp[i:i + per]) for i in range(0, min(len(grp), 3 * per), per)]
    p["overlays"] = [{"kind": "clock", "x": 1248, "y": 297, "r": 48, "hour": hh, "minute": mm},
                     note("F7_tv", "screen", tv_lines, margin=0.12)]
    p["clue"] = {"kind": kind, "hour": hh, "minute": mm}
    return p


def gen_p6(rng, used):
    cands = [x for x in WORDS if x not in used and len(set(x)) >= 5 and len(x) <= 7]
    w = rng.choice(cands); used.add(w)
    key = _perm_key(rng)
    c = sub_enc(w, key)
    letters = list(dict.fromkeys(w))
    hidden = rng.sample(letters[1:], 2)           # 2 ตัวที่ไม่บอก (ไม่ซ่อนตัวแรก)
    given = [ch for ch in letters if ch not in hidden]
    decoys = rng.sample([ch for ch in ALPHA if ch not in letters], 3)
    pairs = [(key[ch], ch) for ch in given + decoys]
    rng.shuffle(pairs)
    p = _base("P6", 6, "ประตูชั้น 6", "รหัสสลับตัวอักษร: แต่ละตัวถูกแทนด้วยตัวอื่นแบบสุ่ม คีย์บางส่วนเขียนอยู่บนผนัง",
              c, w, "subst", {"cipher": c, "given": dict(pairs), "freq": False},
              ["คีย์บางส่วนเขียนอยู่บนคราบน้ำที่ผนัง ใช้ตารางสลับตัวอักษรเติมคู่ที่รู้แล้ว",
               "เติมคู่จากผนังแล้ว จะเหลือช่องว่าง 2 ตัว เดาจากรูปคำภาษาอังกฤษ",
               "ตัวที่ขาดคือ %s และ %s" % (hidden[0], hidden[1])],
              "1. เติมคู่จากผนัง: %s\n2. ข้อความกลายเป็น %s\n3. เดาตัวที่ขาดจากรูปคำ ได้ %s"
              % (", ".join("%s=%s" % (a, b) for a, b in pairs), "".join(ch if ch in given else "_" for ch in w), w),
              "รหัสนี้ไม่ได้เลื่อนตัวอักษร แต่สลับแบบสุ่ม\n\nเปิดตารางสลับตัวอักษรในเครื่องมือ แล้วเติมคู่ที่รู้", "substitution")
    # คู่ตัวอักษรบนคราบน้ำ (ผูกกับกรอบจุดสำรวจ F6_stain)
    p["overlays"] = [note("F6_stain", "paint", ["%s = %s" % (a, b) for a, b in pairs], mx=40)]
    p["clue"] = {"pairs": pairs, "hidden": hidden, "key": key}
    return p


def gen_p5(rng, used):
    w = _pick(rng, WORDS, used)
    text = rng.choice(PASSAGES) % w
    key = _perm_key(rng)
    c = sub_enc(text, key)
    counts = sorted(((c.count(ch), ch) for ch in ALPHA if ch in c), reverse=True)
    top = counts[0][1]
    p = _base("P5", 5, "ประตูชั้น 5", "กระดาษต่อเนื่องยาวเหยียดถูกเข้ารหัสด้วยการสลับตัวอักษร ข้อความจบด้วยรหัสผ่าน หาให้เจอ",
              c, w, "subst", {"cipher": c, "given": {}, "freq": True},
              ["นับว่าตัวอักษรไหนเจอบ่อยที่สุด ในภาษาอังกฤษตัวที่เจอบ่อยสุดมักเป็น E",
               "ตัวที่เจอบ่อยสุดในรหัสคือ %s ลองให้มันเป็น E แล้วหาคำ 3 ตัวที่เจอบ่อย มักเป็น THE" % top,
               "ข้อความจบด้วย THE PASSWORD IS ... ใช้คำนี้เติมตัวอักษรที่เหลือ: %s"
               % ", ".join("%s=%s" % (key[ch], ch) for ch in "THEPASWORDI")],
              "1. นับความถี่: %s เจอบ่อยสุด = E\n2. คำ 3 ตัวที่เจอบ่อย = THE\n3. ประโยคท้ายคือ THE PASSWORD IS\n4. เติมตัวอักษรที่เหลือ คำตอบคือ %s"
              % (top, w),
              "ข้อความยาวแบบนี้ไม่ต้องรู้กุญแจก็แกะได้\n\nเปิดตัวนับความถี่ในเครื่องมือ ตัวอักษรที่เจอบ่อยจะบอกใบ้", "frequency")
    p["clue"] = {"top": top, "key": key, "text": text}
    return p


def gen_p4(rng, used):
    w = _pick(rng, WORDS, used)
    fam = list(rng.choice(VIG_FAMILIES))
    rng.shuffle(fam)
    k = fam[0]
    board = [k] + fam[1:4]
    others = fam[4:] + [x for f in VIG_FAMILIES for x in f if x not in fam]
    tags = [k] + rng.sample(others, 4)
    rng.shuffle(board); rng.shuffle(tags)
    c = vig_enc(w, k)
    p = _base("P4", 4, "ประตูชั้น 4", "รหัส Vigenère: เลื่อนแต่ละตัวไม่เท่ากันตามคีย์เวิร์ด คีย์เวิร์ดคือคำที่อยู่ทั้งบนกระดานดำและบนป้ายโลหะ",
              c, w, "vig", {"cipher": c},
              ["ดูคำบนกระดานดำ แล้วเทียบกับคำบนป้ายโลหะ หาคำที่ซ้ำกัน",
               "คำที่อยู่ทั้งสองที่คือ %s นี่คือคีย์เวิร์ด" % k,
               "ใส่คีย์เวิร์ด %s ในตัวช่วย Vigenère ตัวแรก %s ถอยกลับ %d ได้ %s" % (k, c[0], ALPHA.index(k[0]), w[0])],
              "1. คำบนกระดาน: %s\n2. คำบนป้าย: %s\n3. คำที่ซ้ำ = คีย์เวิร์ด %s\n4. ถอดทีละตัวด้วยคีย์ที่วนซ้ำ ได้ %s"
              % (", ".join(board), ", ".join(tags), k, w),
              "Vigenère ใช้ Caesar หลายวงสลับกันตามคีย์เวิร์ด\n\nหาคีย์เวิร์ดให้เจอ แล้วใช้ตัวช่วย Vigenère", "vigenere")
    # คำบนกระดานดำ (F4_board) และบนป้ายโลหะ (F4_tags)
    p["overlays"] = [note("F4_board", "chalk", [board[0] + "   " + board[1], board[2] + "   " + board[3]], mx=44),
                     note("F4_tags", "metal", ["  ".join(tags[:3]), "  ".join(tags[3:])], margin=0.02)]
    p["clue"] = {"key": k, "board": board, "tags": tags}
    return p


def gen_p3(rng, used):
    cands = [x for x in WORDS if x not in used and len(x) <= 6]
    w = rng.choice(cands); used.add(w)
    key = rng.randint(17, 239)
    c = xor_hex(w, key)
    bits = format(key, "08b")
    p = _base("P3", 3, "ประตูชั้น 3", "ข้อความเป็นเลขฐานสิบหกที่ถูก XOR กับคีย์ 8 บิต คีย์คือสวิตช์ 8 ตัวบนโต๊ะ",
              c, w, "xor", {"cipher": c},
              ["สังเกตไฟเหนือสวิตช์ 8 ตัว ไฟเขียวคือ 1 ไฟดับคือ 0",
               "อ่านไฟจากซ้ายไปขวาได้คีย์ %s" % bits,
               "ตั้งสวิตช์ในเครื่องคิดเลข XOR เป็น %s แล้วดูตัวอักษรที่ได้" % bits],
              "1. คีย์จากสวิตช์ = %s (= %d)\n2. แปลงแต่ละไบต์ hex เป็นบิต แล้ว XOR กับคีย์\n3. ได้รหัส ASCII: %s\n4. คำตอบคือ %s"
              % (bits, key, ", ".join(str(ord(ch)) for ch in w), w),
              "XOR: บิตเหมือนกันได้ 0 ต่างกันได้ 1 และ XOR ซ้ำด้วยคีย์เดิมจะได้ข้อความเดิมกลับมา\n\nใช้เครื่องคิดเลข XOR ในเครื่องมือ", "xor")
    # ไฟ 8 ดวงเหนือแผงสวิตช์ (ผูกกับกรอบจุดสำรวจ F3_switches)
    p["overlays"] = [{"kind": "leds", "spot": "F3_switches", "bits": bits}]
    p["clue"] = {"key": key, "bits": bits}
    return p


def gen_p2(rng, used):
    cands = rng.sample(PASSWORDS, 7)
    ans = rng.choice(cands)
    target = short_hash(ans)
    p = _base("P2", 2, "ประตูชั้น 2", "ระบบไม่ได้เก็บรหัสผ่านไว้ตรง ๆ เก็บแค่ค่า hash ของมัน รหัสผ่านคือคำไหนในรายการบนบอร์ด",
              target, ans, "hash", {"target": target, "mode": "match"},
              ["hash เป็นทางเดียว ถอดกลับไม่ได้ แต่ลอง hash คำที่เดาได้แล้วเทียบได้",
               "ใช้เทอร์มินัล hash พิมพ์คำจากบอร์ดทีละคำ แล้วดูว่าค่าไหนตรงกับบนประตู",
               "คำที่ได้ hash ตรงกันคือ %s" % ans],
              "1. คำบนบอร์ด: %s\n2. hash ทีละคำด้วยเทอร์มินัล\n3. %s ให้ค่า %s ตรงกับประตู\n4. คำตอบคือ %s"
              % (", ".join(cands), ans, target, ans),
              "Hash คือ ลายนิ้วมือของข้อมูล\n\nข้อมูลเดิมให้ hash เดิมเสมอ แต่ย้อนกลับไม่ได้ ใช้เทอร์มินัล hash ลองคำที่เดาได้", "hash")
    # รายการรหัสผ่านบนบอร์ดกระดาษ (ผูกกับกรอบจุดสำรวจ F2_board)
    rows = [cands[i:i + 2] for i in range(0, len(cands), 2)]
    p["overlays"] = [note("F2_board", "paper", ["  ".join(w.lower().ljust(8) for w in r).rstrip() for r in rows], margin=0.04)]
    p["clue"] = {"list": cands}
    return p


def gen_s2(rng):
    """โจทย์เสริม: ตู้เซฟ PIN 3 หลัก (เปิดแล้วได้จดหมายฉบับที่ 9)"""
    pin = "%03d" % rng.randint(0, 999)
    target = short_hash(pin)
    p = _base("S2", 2, "ตู้เซฟ", "ตู้เซฟใช้ PIN 3 หลัก บนป้ายเขียนแค่ค่า hash ของ PIN ไว้",
              target, pin, "hash", {"target": target, "mode": "pin"},
              ["PIN 3 หลักมีแค่ 1,000 แบบ (000 ถึง 999)",
               "ลองให้เทอร์มินัล hash ไล่ทุกตัวเลข (brute force)",
               "PIN คือ %s" % pin],
              "1. PIN 3 หลักมี 1,000 แบบ\n2. hash ทุกแบบแล้วเทียบกับค่าบนป้าย\n3. PIN คือ %s" % pin,
              "รหัสสั้นแค่ 3 หลัก ต่อให้เก็บเป็น hash ก็ไม่ปลอดภัย\n\nลองใช้ปุ่ม brute force ในเทอร์มินัล hash", "brute_pin")
    p["success"] = "fsolved_S2"
    return p


def gen_p1(rng, used):
    k1 = rng.choice(KEY_WORDS)
    c1 = b64enc(k1)
    w2 = _pick(rng, WORDS, used)
    c2 = vig_enc(w2, k1)
    w3 = rng.choice(RSA_WORDS)
    pp, qq, e, d = rng.choice(RSA_KEYS)
    n = pp * qq
    nums = rsa_enc(w3, n, e)
    l1 = _base("L1", 1, "แผงควบคุมล็อบบี้: ล็อก 1/2", "ชั้นแรกของรหัสเป็น Base64 ถอดให้ได้ คำที่ได้คือกุญแจของล็อกถัดไป",
               c1, k1, "b64", {"cipher": c1},
               ["ลงท้ายด้วย = หรือเปล่า ถ้าใช่ น่าจะเป็น Base64", "ใช้ตัวช่วย Base64 คลิกเรียงจากซ้ายไปขวา", "คำที่ได้คือ %s" % k1],
               "1. Base64 -> บิต -> ตัดชุดละ 8 -> ASCII\n2. ได้คำว่า %s" % k1,
               "ด่านสุดท้ายมีสามชั้นซ้อนกัน\n\nทุกสิ่งที่เรียนมาตั้งแต่ชั้น 10 จะได้ใช้ที่นี่", "base64")
    l2 = _base("L2", 1, "แผงควบคุมล็อบบี้: ล็อก 2/2", "รหัส Vigenère ที่ใช้คำจากล็อกแรกเป็นคีย์เวิร์ด",
               c2, w2, "vig", {"cipher": c2},
               ["คีย์เวิร์ดคือคำตอบของล็อกที่ 1", "ใส่คีย์เวิร์ด %s ในตัวช่วย Vigenère" % k1, "คำตอบคือ %s" % w2],
               "1. คีย์เวิร์ด = %s\n2. ถอด Vigenère ได้ %s" % (k1, w2),
               "ล็อกนี้ใช้คำตอบจากล็อกก่อนหน้าเป็นกุญแจ", "vigenere")
    l3 = _base("L3", 1, "ประตูห้องกุญแจหลัก", "ตัวเลขบนประตูถูกเข้ารหัสด้วยกุญแจสาธารณะ ต้องใช้กุญแจส่วนตัวถอด (A=1 ถึง Z=26)",
               " ".join(str(x) for x in nums), w3, "rsa", {"nums": nums, "n": n, "e": e},
               ["กุญแจสาธารณะ (e, n) ใช้ล็อก กุญแจส่วนตัว (d, n) ใช้ปลดล็อก",
                "ตัวเลขที่สลักบนกุญแจทองเหลืองของคุณคือ d",
                "ใช้ d = %d และ n = %d ในเครื่องคิดเลข แต่ละตัวเลขยกกำลัง d แล้ว mod n" % (d, n)],
               "1. กุญแจส่วนตัว d = %d (สลักบนกุญแจทองเหลือง), n = %d\n2. m = c ยกกำลัง d mod n ทีละตัว\n3. แปลงเลข 1-26 เป็นตัวอักษร ได้ %s" % (d, n, w3),
               "ประตูบานนี้ล็อกด้วยกุญแจสาธารณะ ใครก็ล็อกได้ แต่เปิดได้เฉพาะคนที่มีกุญแจส่วนตัว", "rsa")
    l3["success"] = "fsolved_L3"
    l3["clue"] = {"d": d, "n": n, "e": e, "p": pp, "q": qq}
    return l1, l2, l3


def make_run(seed):
    rng = random.Random(seed)
    used = set()
    out = {}
    for fn in (gen_p10, gen_p9, gen_p8, gen_p7, gen_p6, gen_p5, gen_p4, gen_p3, gen_p2):
        p = fn(rng, used)
        out[p["id"]] = p
    s2 = gen_s2(rng); out[s2["id"]] = s2
    for p in gen_p1(rng, used):
        out[p["id"]] = p
    return out
