# ==========================================================================
#  cr_tools2.rpy : เครื่องมือของเวอร์ชันเต็ม + จดหมาย + แผนผังตึก + DEV + หน้าจบ
#  (กรอบ cr_panel(w, h) มีพื้นที่เนื้อหาจริง w-72 x h-56)
# ==========================================================================

style cr_key_btn is button:
    activate_sound "audio/sfx_tick.ogg"
    background Solid("#0d0b14")
    hover_background Solid("#2a2440")
    selected_background Solid("#6b5bd6")
    insensitive_background Solid("#14111d")
    xysize (52, 60)

style cr_key_btn_text is cr_mono:
    size 30
    color "#5be3a1"
    hover_color "#ffd86b"
    selected_color "#ffffff"
    insensitive_color "#3a3555"
    xalign 0.5
    yalign 0.5

style cr_small_input is input:
    font "fonts/DejaVuSansMono.ttf"
    size 40
    color "#ffffff"

# ---------- ส่วนหัวของเครื่องมือ (ชื่อ + ปุ่มปิด) ----------

screen cr_tool_head(title, desc, scr):
    hbox:
        xfill True
        vbox:
            xsize 1260
            spacing 6
            text title style "cr_title"
            text desc style "cr_muted" size 25
        textbutton "ปิด" style "cr_btn" xalign 1.0 action Hide(scr)

# ---------- ตารางกระจก (Atbash) ----------

screen cr_mirror(cipher):
    modal True
    zorder 130
    default rev = []
    default show_all = False
    key "game_menu" action Hide("cr_mirror")

    use cr_panel(1560, 860):
        vbox:
            spacing 22
            xfill True
            use cr_tool_head("ตารางกระจก (Atbash)", "ตัวอักษรแต่ละคู่สะท้อนกันจากหัวกับท้าย A คู่ Z, B คู่ Y ... ถอดกับเข้ารหัสใช้ตารางเดียวกัน", "cr_mirror")
            frame:
                background Solid("#0d0b14")
                padding (20, 14)
                vbox:
                    spacing 4
                    hbox:
                        for i in range(13):
                            text ALPHA[i] style "cr_cell" color "#5be3a1"
                    hbox:
                        for i in range(13):
                            text "|" style "cr_cell" color "#4a4270"
                    hbox:
                        for i in range(13):
                            text ALPHA[25 - i] style "cr_cell" color "#ffd86b"
            text "คลิกตัวอักษรของรหัสเพื่อดูคู่ของมัน" style "cr_muted" size 26
            hbox:
                spacing 12
                for i, ch in enumerate(cipher):
                    vbox:
                        spacing 6
                        textbutton ch style "cr_letter_btn" action ToggleSetMembership(rev, i)
                        if show_all or (i in rev):
                            text cr_gen.atbash(ch) style "cr_mono" size 56 color "#ffd86b" xalign 0.5
                        else:
                            text "?" style "cr_mono" size 56 color "#4a4270" xalign 0.5
            textbutton ("ซ่อนผลทั้งข้อความ" if show_all else "แสดงผลทั้งข้อความ") style "cr_btn" action ToggleScreenVariable("show_all")

# ---------- ตัวแปลงเลขฐาน (ฐานสอง / ฐานสิบหก -> ASCII) ----------

screen cr_baseconv(cipher, base):
    modal True
    zorder 130
    default sel = 0
    default rev = []
    key "game_menu" action Hide("cr_baseconv")

    $ groups = cipher.split()
    $ g = groups[sel]
    $ val = int(g, base)

    use cr_panel(1560, 900):
        vbox:
            spacing 18
            xfill True
            use cr_tool_head("ตัวแปลงเลขฐาน", ("แต่ละกลุ่มเป็นเลขฐานสอง 8 หลัก" if base == 2 else "แต่ละกลุ่มเป็นเลขฐานสิบหก 2 หลัก") + " คลิกกลุ่มเพื่อดูวิธีแปลงเป็นเลขฐานสิบและตัวอักษร", "cr_baseconv")
            hbox:
                spacing 14
                for i, grp in enumerate(groups):
                    vbox:
                        spacing 4
                        textbutton grp:
                            style "cr_btn"
                            selected (i == sel)
                            text_font MONO
                            action [SetScreenVariable("sel", i), AddToSet(rev, i)]
                        if i in rev:
                            text (str(int(grp, base)) + " = " + chr(int(grp, base))) style "cr_mono" size 30 color "#ffd86b" xalign 0.5
                        else:
                            text "?" style "cr_mono" size 30 color "#4a4270" xalign 0.5
            frame:
                background Solid("#0d0b14")
                xfill True
                padding (24, 18)
                vbox:
                    spacing 10
                    text ("กลุ่มที่เลือก: " + g) style "cr_text" color "#5be3a1"
                    if base == 2:
                        hbox:
                            spacing 6
                            for k in range(8):
                                vbox:
                                    text str(2 ** (7 - k)) style "cr_mono" size 22 color "#8f89a8" xalign 0.5 xminimum 70 text_align 0.5
                                    text g[k] style "cr_mono" size 40 color ("#ffd86b" if g[k] == "1" else "#4a4270") xalign 0.5
                        text bin_sum_text(g) style "cr_mono" size 26
                    else:
                        text (g[0] + " x 16 + " + g[1] + " = " + str(int(g[0], 16)) + " x 16 + " + str(int(g[1], 16)) + " = " + str(val)) style "cr_mono" size 28
                        text "(ฐานสิบหก: A=10 B=11 C=12 D=13 E=14 F=15)" style "cr_muted" size 22
                    text ("เลข " + str(val) + " ในตาราง ASCII คือ " + chr(val)) style "cr_text" color "#ffd86b"
            text "ตาราง ASCII ตัวพิมพ์ใหญ่: A=65 B=66 C=67 ... M=77 N=78 ... Z=90" style "cr_muted" size 24

# ---------- ตารางสลับตัวอักษร + ตัวนับความถี่ ----------

screen cr_subst(pid, cipher, given, freq):
    modal True
    zorder 130
    default sel = None
    key "game_menu" action Hide("cr_subst")

    $ m = subst_map(pid, given)
    $ counts = letter_counts(cipher)
    $ maxc = max(counts.values()) if counts else 1
    $ top = top_letters(counts, 6)

    use cr_panel(1560, 980):
        vbox:
            spacing 14
            xfill True
            use cr_tool_head("ตารางสลับตัวอักษร" + (" + ตัวนับความถี่" if freq else ""), "คลิกตัวอักษรรหัส (แถวบน) แล้วเลือกตัวที่คิดว่าเป็นตัวจริง (แถวล่าง) ตัวที่ยังไม่รู้แสดงเป็นตัวเล็กสีจาง", "cr_subst")

            frame:
                background Solid("#0d0b14")
                xfill True
                padding (18, 12)
                text subst_preview(cipher, m):
                    style "cr_mono"
                    size (40 if len(cipher) < 20 else 24)
                    line_spacing 6

            if freq:
                text ("เจอบ่อยที่สุดในรหัส: " + freq_line(counts, top) + "     ภาษาอังกฤษ: E T A O I N") style "cr_text" size 24 color "#5be3a1"

            # แถวตัวอักษรรหัส
            hbox:
                spacing 2
                for c in ALPHA:
                    vbox:
                        spacing 2
                        if freq:
                            fixed:
                                xysize (52, 60)
                                add Solid("#6b5bd6", xysize=(34, max(2, int(56 * counts[c] / maxc)))) xalign 0.5 yalign 1.0
                        textbutton c:
                            style "cr_key_btn"
                            selected (sel == c)
                            sensitive (counts[c] > 0)
                            action SetScreenVariable("sel", c)
                        text (m.get(c, "-")) style "cr_mono" size 28 color ("#8f89a8" if c in given else "#ffd86b") xalign 0.5

            if sel:
                if sel in given:
                    text ("ตัว " + sel + " = " + given[sel] + " มาจากเบาะแสบนผนัง (ล็อกไว้)") style "cr_muted" size 24
                else:
                    text ("ให้ตัวรหัส " + sel + " เป็นตัวจริง:") style "cr_text" size 26
                    hbox:
                        spacing 2
                        for p in ALPHA:
                            textbutton p:
                                style "cr_key_btn"
                                selected (m.get(sel) == p)
                                action Function(subst_set, pid, given, sel, p)
                    textbutton "ล้างตัวนี้" style "cr_btn" action Function(subst_set, pid, given, sel, None)
            else:
                text "เลือกตัวอักษรรหัสด้านบนก่อน" style "cr_muted" size 24

# ---------- ตัวช่วย Vigenère ----------

screen cr_vig(cipher):
    modal True
    zorder 130
    default kw = ""
    default kw_iv = ScreenVariableInputValue("kw", default=True)
    on "show" action kw_iv.Enable()
    on "hide" action Function(refocus_puzzle)
    key "game_menu" action Hide("cr_vig")

    $ cols = vig_columns(cipher, kw)

    use cr_panel(1560, 900):
        vbox:
            spacing 18
            xfill True
            use cr_tool_head("ตัวช่วย Vigenère", "พิมพ์คีย์เวิร์ด ตัวช่วยจะวางคีย์ใต้รหัสทีละตัว (A=0, B=1 ...) แล้วถอยกลับตามค่านั้น", "cr_vig")
            hbox:
                spacing 16
                text "คีย์เวิร์ด:" style "cr_text" yalign 0.5
                button:
                    background Solid("#0d0b14")
                    hover_background Solid("#15121f")
                    xsize 520
                    padding (16, 8)
                    action kw_iv.Enable()
                    input:
                        style "cr_small_input"
                        value kw_iv
                        length 10
                        allow "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
            frame:
                background Solid("#0d0b14")
                xfill True
                padding (20, 16)
                hbox:
                    spacing 8
                    vbox:
                        spacing 8
                        text "รหัส" style "cr_text" size 26 yminimum 50
                        text "คีย์" style "cr_text" size 26 yminimum 50
                        text "ถอย" style "cr_text" size 26 yminimum 50
                        text "จริง" style "cr_text" size 26 yminimum 50
                    for c, k, sh, pl in cols:
                        vbox:
                            spacing 8
                            xminimum 84
                            text c style "cr_mono" size 44 color "#5be3a1" xalign 0.5 yminimum 50
                            text (k or "-") style "cr_mono" size 44 color "#8f89a8" xalign 0.5 yminimum 50
                            text (str(sh) if k else "-") style "cr_mono" size 30 color "#8f89a8" xalign 0.5 yminimum 50
                            text pl style "cr_mono" size 44 color "#ffd86b" xalign 0.5 yminimum 50
            text "ตัวอย่าง: รหัส R กับคีย์ K (=10) ถอยกลับ 10 ตัวได้ H" style "cr_muted" size 24

# ---------- เครื่องคิดเลข XOR ----------

screen cr_xor(cipher):
    modal True
    zorder 130
    default bits = [0, 0, 0, 0, 0, 0, 0, 0]
    key "game_menu" action Hide("cr_xor")

    $ rows = xor_rows(cipher, bits)

    use cr_panel(1560, 940):
        vbox:
            spacing 16
            xfill True
            use cr_tool_head("เครื่องคิดเลข XOR", "ตั้งสวิตช์ 8 ตัวเป็นคีย์ (1 = เปิด) แล้วดูว่าแต่ละไบต์ XOR กับคีย์ได้ตัวอักษรอะไร: บิตเหมือนกันได้ 0 ต่างกันได้ 1", "cr_xor")
            hbox:
                spacing 10
                text "คีย์:" style "cr_text" yalign 0.5
                for i in range(8):
                    textbutton str(bits[i]):
                        style "cr_key_btn"
                        selected (bits[i] == 1)
                        action SetScreenVariable("bits", bits[:i] + [1 - bits[i]] + bits[i + 1:])
                text ("= " + str(bits_value(bits))) style "cr_mono" size 34 color "#ffd86b" yalign 0.5
            frame:
                background Solid("#0d0b14")
                xfill True
                padding (20, 14)
                vbox:
                    spacing 8
                    text "hex    บิตของรหัส    XOR คีย์      ผลลัพธ์    ตัวอักษร" style "cr_muted" size 24
                    for h, b, r, v, ch in rows:
                        text (h + "     " + b + "  ->  " + r + "  =  " + str(v).rjust(3) + "    " + ch) style "cr_mono" size 30 color "#5be3a1"
            text ("ผลรวม: " + join_col(rows, 4)) style "cr_mono" size 40 color "#ffd86b"

# ---------- เทอร์มินัล hash ----------

screen cr_hash(target, hmode):
    modal True
    zorder 130
    default word = ""
    default word_iv = ScreenVariableInputValue("word", default=True)
    on "show" action word_iv.Enable()
    on "hide" action Function(refocus_puzzle)
    default bf = None
    key "game_menu" action Hide("cr_hash")

    $ h = hash_of(word)

    use cr_panel(1560, 860):
        vbox:
            spacing 18
            xfill True
            use cr_tool_head("เทอร์มินัล hash", "พิมพ์คำแล้วดูค่า hash (SHA-256 16 ตัวแรก) ถ้าตรงกับค่าที่ต้องการ แปลว่าเจอแล้ว", "cr_hash")
            frame:
                background Solid("#0d0b14")
                xfill True
                padding (20, 14)
                text ("ค่าที่ต้องการ:  " + target) style "cr_mono" size 34 color "#ff9f43"
            hbox:
                spacing 16
                text "พิมพ์:" style "cr_text" yalign 0.5
                button:
                    background Solid("#0d0b14")
                    hover_background Solid("#15121f")
                    xsize 700
                    padding (16, 8)
                    action word_iv.Enable()
                    input:
                        style "cr_small_input"
                        value word_iv
                        length 16
                        allow "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
            frame:
                background Solid("#0d0b14")
                xfill True
                padding (20, 14)
                vbox:
                    spacing 8
                    text ("hash:  " + (h or "-")) style "cr_mono" size 34 color ("#5be3a1" if h == target else "#e8e4f5")
                    if h and h == target:
                        text "ตรงกัน! นี่คือคำที่ถูก hash ไว้" style "cr_text" color "#5be3a1"
                    elif h:
                        text "ไม่ตรง ลองคำอื่น (เปลี่ยนแค่ตัวเดียว hash ก็ต่างกันหมด)" style "cr_muted"
            if hmode == "pin":
                hbox:
                    spacing 16
                    textbutton "Brute force: ลอง 000 ถึง 999" style "cr_btn" action SetScreenVariable("bf", brute_pin(target))
                    if bf:
                        text ("เจอ PIN = " + bf[0] + " หลังลองไป " + str(bf[1]) + " ครั้ง") style "cr_text" color "#5be3a1" yalign 0.5

# ---------- เครื่องคิดเลขกุญแจสาธารณะ ----------

screen cr_rsa(nums, n, e):
    modal True
    zorder 130
    default dtxt = ""
    default dtxt_iv = ScreenVariableInputValue("dtxt", default=True)
    on "show" action dtxt_iv.Enable()
    on "hide" action Function(refocus_puzzle)
    key "game_menu" action Hide("cr_rsa")

    $ d = to_int(dtxt, 0)
    $ rows = rsa_rows(nums, n, d) if d > 0 else []

    use cr_panel(1560, 900):
        vbox:
            spacing 18
            xfill True
            use cr_tool_head("เครื่องคิดเลขกุญแจ", "ถอดรหัส: m = c ยกกำลัง d แล้ว mod n จากนั้นแปลงเลข 1-26 เป็นตัวอักษร (A=1 ... Z=26)", "cr_rsa")
            frame:
                background Solid("#0d0b14")
                xfill True
                padding (20, 14)
                text ("กุญแจสาธารณะบนประตู:  e = " + str(e) + "   n = " + str(n)) style "cr_mono" size 32 color "#ff9f43"
            hbox:
                spacing 16
                text "กุญแจส่วนตัว d =" style "cr_text" yalign 0.5
                button:
                    background Solid("#0d0b14")
                    hover_background Solid("#15121f")
                    xsize 260
                    padding (16, 8)
                    action dtxt_iv.Enable()
                    input:
                        style "cr_small_input"
                        value dtxt_iv
                        length 4
                        allow "0123456789"
            frame:
                background Solid("#0d0b14")
                xfill True
                padding (20, 14)
                vbox:
                    spacing 6
                    if rows:
                        for c, mm, ch in rows:
                            text (str(c).rjust(3) + " ^ " + str(d) + " mod " + str(n) + " = " + str(mm).rjust(3) + "  ->  " + ch) style "cr_mono" size 30 color "#5be3a1"
                        text ("ผลรวม: " + join_col(rows, 2)) style "cr_mono" size 40 color "#ffd86b"
                    else:
                        text "ใส่ค่า d ก่อน" style "cr_muted"

# ---------- จดหมายของดร.คีย์ ----------

screen cr_letter(n):
    modal True
    zorder 160
    on "show" action Play("sound", "audio/sfx_page.ogg")
    add Solid("#000000bb")
    frame:
        background Solid("#c9b88f")
        padding (6, 6)
        align (0.5, 0.5)
        frame:
            background Solid("#efe4c8")
            padding (70, 50)
            xsize 1200
            vbox:
                spacing 26
                text LETTERS[n][0] style "cr_title" color "#6b3f1f"
                text LETTERS[n][1] style "cr_body" color "#3b2a1a" size 32 line_spacing 12
                textbutton "พับเก็บ (บันทึกลงสมุดโน้ตแล้ว)" style "cr_btn" xalign 1.0 action Return()

# ---------- แผนผังตึก (เวอร์ชันเต็ม: ภาพตัดขวาง 10 ชั้น) ----------

screen cr_map_full():
    modal True
    zorder 120
    on "show" action Play("sound", "audio/sfx_page.ogg")
    key "game_menu" action Hide("cr_map_full")
    key "K_m" action Hide("cr_map_full")

    use cr_panel(1300, 1000):
        vbox:
            spacing 10
            xfill True
            use cr_tool_head("แผนผังตึก", "คลิกชั้นที่ปลดล็อกแล้วเพื่อเดินกลับไป (เช่น กลับไปเก็บจดหมายหรือจุดที่ยังไม่ได้สำรวจ)", "cr_map_full")
            for rid in FULL_ORDER:
                $ r = FROOMS[rid]
                $ opened = rid in unlocked
                $ here = (rid == current_room)
                $ todo = len(unexplored(rid)) if opened else 0
                button:
                    xfill True
                    ysize 68
                    padding (20, 6)
                    background Solid("#ffd86b" if here else ("#2a2540" if opened else "#15121f"))
                    hover_background Solid("#ffd86b" if here else "#3a3260")
                    sensitive (opened and not here)
                    activate_sound "audio/sfx_steps.ogg"
                    action [Hide("cr_map_full"), Return(("travel", rid))]
                    hbox:
                        spacing 20
                        yalign 0.5
                        text (r["name"] if opened else ("ชั้น " + str(r["floor"]) + ": ???")) style "cr_text" size 28 color ("#0d0b14" if here else ("#e8e4f5" if opened else "#5a5575")) yalign 0.5
                        if here:
                            text "(คุณอยู่ที่นี่)" style "cr_text" size 24 color "#0d0b14" yalign 0.5
                        if todo:
                            frame:
                                background Solid("#e0453a")
                                padding (12, 0)
                                yalign 0.5
                                text ("! " + str(todo)) style "cr_alert_text" size 26
                        if opened and door_done(rid) and rid != "F1":
                            text "ผ่านแล้ว" style "cr_text" size 22 color ("#0d0b14" if here else "#5be3a1") yalign 0.5

# ---------- เมนู DEV (เปิดได้ด้วยรหัสลับเท่านั้น) ----------

screen cr_dev(in_puzzle=False):
    modal True
    zorder 300
    key "game_menu" action (Return(None) if in_puzzle else Hide("cr_dev"))

    use cr_panel(1300, 900):
        vbox:
            spacing 14
            xfill True
            hbox:
                xfill True
                text "โหมดทดสอบ (DEV)" style "cr_title" color "#ff9f43"
                textbutton "ปิด" style "cr_btn" xalign 1.0 action (Return(None) if in_puzzle else Hide("cr_dev"))
            text ("seed " + str(run_seed) + "   trust " + str(trust) + "   จดหมาย " + str(len(letters_read)) + "/10   เข้าใจ " + str(understand) + "   A=" + str(choice_a) + " B=" + str(choice_b)) style "cr_mono" size 22 color "#8f89a8"
            hbox:
                spacing 12
                if in_puzzle:
                    textbutton "ผ่านโจทย์นี้ทันที" style "cr_btn" action Return("solve")
                textbutton ("ซ่อนคำตอบ" if dev_show_answers else "แสดงคำตอบในหน้ารหัส") style "cr_btn" action ToggleVariable("dev_show_answers")
                textbutton "สำรวจครบห้องนี้" style "cr_btn" action Function(dev_explore_room)
            if mode == "full":
                hbox:
                    spacing 12
                    textbutton "จดหมายครบ 10" style "cr_btn" action Function(dev_all_letters)
                    textbutton "trust -1" style "cr_btn" action Function(add_trust, -1)
                    textbutton "trust +1" style "cr_btn" action Function(add_trust, 1)
                if not in_puzzle:
                    text "ไปชั้น (ผ่านทุกชั้นด้านบนให้อัตโนมัติ):" style "cr_text" size 26
                    hbox:
                        spacing 8
                        for rid in FULL_ORDER:
                            textbutton rid style "cr_btn" action [Function(dev_unlock_to, rid), Hide("cr_dev"), Return(("travel", rid))]
                    text "ดูตอนจบ:" style "cr_text" size 26
                    hbox:
                        spacing 8
                        for eid in range(1, 6):
                            textbutton (str(eid) + " " + ENDINGS[eid]) style "cr_btn" action [Function(dev_set_ending_route, eid), Hide("cr_dev"), Return(("devend", eid))]
            textbutton "ปิดโหมดทดสอบ (ซ่อนปุ่ม DEV)" style "cr_btn" action [SetField(persistent, "dev", False), (Return(None) if in_puzzle else Hide("cr_dev"))]

# ---------- ช่องใส่รหัสลับจากหน้าล็อบบี้ ----------

screen cr_devcode():
    modal True
    zorder 200
    default code = ""
    default code_iv = ScreenVariableInputValue("code", default=False)
    on "show" action code_iv.Enable()
    default bad = False
    key "game_menu" action Hide("cr_devcode")

    use cr_panel(900, 420):
        vbox:
            spacing 18
            xfill True
            text "?" style "cr_title"
            button:
                background Solid("#0d0b14")
                xfill True
                padding (16, 8)
                action code_iv.Enable()
                input:
                    style "cr_small_input"
                    value code_iv
                    length 20
                    allow "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
            if bad:
                text "..." style "cr_muted"
            hbox:
                spacing 14
                textbutton "ตกลง" style "cr_btn" action (If(is_dev_code(code), [SetField(persistent, "dev", True), Hide("cr_devcode"), Show("cr_dev_lobby")], SetScreenVariable("bad", True)))
                textbutton "ปิด" style "cr_btn" action Hide("cr_devcode")

screen cr_dev_lobby():
    modal True
    zorder 200
    key "game_menu" action Hide("cr_dev_lobby")
    use cr_panel(1300, 520):
        vbox:
            spacing 16
            xfill True
            hbox:
                xfill True
                text "โหมดทดสอบ: เริ่มเรื่องเต็มที่ชั้น" style "cr_title" color "#ff9f43"
                textbutton "ปิด" style "cr_btn" xalign 1.0 action Hide("cr_dev_lobby")
            hbox:
                spacing 8
                for rid in FULL_ORDER:
                    textbutton rid style "cr_btn" action [SetField(persistent, "dev_floor", rid), Hide("cr_dev_lobby"), Start("start_full")]
            text "ในเกมจะมีปุ่ม DEV มุมขวาบน (ไปชั้นอื่น ดูตอนจบ แสดงคำตอบ ฯลฯ)" style "cr_muted"
            textbutton "ปิดโหมดทดสอบ" style "cr_btn" action [SetField(persistent, "dev", False), Hide("cr_dev_lobby")]

# ---------- หน้าสรุปหลังตอนจบ (เวอร์ชันเต็ม) ----------

screen cr_summary_full(eid):
    modal True
    zorder 200
    key "K_n" action Show("cr_notebook")
    add Solid("#0d0b14")

    $ topics = []
    for pid in ["P10", "P9", "P8", "P7", "P6", "P5", "P4", "P3", "P2", "S2", "L1", "L2", "L3"]:
        if pid in solved and pid in gen and gen[pid]["teach"] in TEACH_TEXT and TEACH_TEXT[gen[pid]["teach"]] not in topics:
            $ topics.append(TEACH_TEXT[gen[pid]["teach"]])
    $ seen_n = len(persistent.endings_seen or set())

    frame:
        background Solid("#6b5bd6")
        padding (5, 5)
        align (0.5, 0.5)
        frame:
            background Solid("#1a1626")
            padding (50, 36)
            xysize (1500, 980)
            vbox:
                spacing 16
                xfill True
                text ("ตอนจบที่ " + str(eid) + ": " + ENDINGS[eid]) style "cr_title" xalign 0.5
                frame:
                    background Solid("#0d0b14")
                    xfill True
                    padding (24, 14)
                    vbox:
                        spacing 6
                        text ("เวลาที่ใช้: " + elapsed_text() + "     ประตูที่ถอดได้: " + str(count_full_solved()) + "     จดหมาย: " + str(len(letters_read)) + "/10") style "cr_text" size 28
                        text ("ตอบผิด: " + str(wrong_total) + " ครั้ง   ใช้คำใบ้: " + str(hints_used) + " ครั้ง   ดูวิธีทำ: " + str(walk_used) + " ครั้ง   ตอนจบที่ค้นพบ: " + str(seen_n) + "/5") style "cr_muted"
                text "สิ่งที่คุณได้เรียนรู้" style "cr_text" color "#5be3a1"
                viewport:
                    ysize 520
                    mousewheel True
                    vbox:
                        spacing 6
                        for t in topics:
                            text ("- " + t) style "cr_body" size 27
                if seen_n < 5:
                    text "ยังมีตอนจบอื่นรออยู่ ลองเลือกต่างออกไป หรือเก็บจดหมายให้ครบ" style "cr_muted"
                hbox:
                    xalign 0.5
                    spacing 24
                    textbutton "สมุดโน้ต (N)" style "cr_btn" action Show("cr_notebook")
                    textbutton "กลับหน้าล็อบบี้" style "cr_btn" action Return("end")

# ---------- ตัวเลือกในบทสนทนา (ใช้แทน menu ของ Ren'Py ไม่พึ่งไฟล์ template) ----------
# ใช้ในบท:  call screen cr_choice(["ตัวเลือก 1", "ตัวเลือก 2"])  แล้วเช็ก _return == 0, 1, ...

style cr_choice_btn is button:
    activate_sound "audio/sfx_click.ogg"
    hover_sound "audio/sfx_hover.ogg"
    background Solid("#1a1626ee")
    hover_background Solid("#3a3260f0")
    padding (40, 18)
    xsize 1180

style cr_choice_btn_text is cr_text:
    size 34
    idle_color "#e8e4f5"
    hover_color "#ffd86b"
    xalign 0.5
    text_align 0.5

screen cr_choice(options):
    modal True
    zorder 140
    add Solid("#00000066")
    for i, cap in enumerate(options):
        if i < 9:
            key str(i + 1) action Return(i)
    vbox:
        align (0.5, 0.42)
        spacing 18
        for i, cap in enumerate(options):
            frame:
                background Solid("#6b5bd6")
                padding (3, 3)
                textbutton (str(i + 1) + ".  " + cap):
                    style "cr_choice_btn"
                    action Return(i)
