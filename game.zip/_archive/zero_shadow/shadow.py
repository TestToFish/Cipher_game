"""Silhouette of the mystery voice: a dark human figure (messy hair, headphones around the neck)
back-lit by green monitor light. Several frames per expression for static/blink animation."""
import sys, os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)
W, H = 600, 760
SS = 2  # supersample for smooth edges
G = np.array([110, 255, 180], float)


def silhouette_mask():
    m = Image.new("L", (W * SS, H * SS), 0)
    d = ImageDraw.Draw(m)
    s = lambda pts: [(x * SS, y * SS) for x, y in pts]
    e = lambda b: [v * SS for v in b]
    # body: hoodie + coat shoulders
    d.ellipse(e((30, 450, 570, 1060)), fill=255)
    # hood bunched behind the neck
    d.ellipse(e((190, 395, 410, 505)), fill=255)
    # neck
    d.rectangle(e((258, 330, 342, 450)), fill=255)
    # head (slightly turned: jaw a bit to the left)
    d.ellipse(e((205, 140, 395, 370)), fill=255)
    d.polygon(s([(215, 300), (258, 372), (300, 384), (345, 365), (385, 300)]), fill=255)
    # ears
    d.ellipse(e((193, 245, 222, 300)), fill=255)
    d.ellipse(e((378, 245, 407, 300)), fill=255)
    # soft, messy hair (like the boy's art): lumpy mass + a few drooping strands
    for b in [(178, 104, 330, 262), (246, 92, 424, 250), (170, 160, 262, 318), (338, 150, 428, 300),
              (214, 86, 330, 190)]:
        d.ellipse(e(b), fill=255)
    strands = [
        [(176, 210), (138, 236), (150, 226), (182, 248)],     # left, flicking out
        [(186, 150), (150, 128), (164, 124), (204, 140)],
        [(232, 100), (214, 70), (226, 72), (252, 96)],
        [(300, 92), (322, 62), (330, 70), (318, 96)],
        [(392, 128), (438, 116), (432, 128), (404, 146)],
        [(420, 230), (452, 262), (440, 262), (414, 248)],     # right, drooping
        [(178, 290), (170, 326), (184, 318), (196, 300)],
    ]
    for st in strands:
        d.polygon(s(st), fill=255)
    # headphones resting on the neck: cups stick out past the neck
    d.rounded_rectangle(e((222, 372, 266, 438)), 15 * SS, fill=255)
    d.rounded_rectangle(e((334, 372, 378, 438)), 15 * SS, fill=255)
    return m.resize((W, H), Image.LANCZOS)


def shift(a, dx, dy):
    out = np.zeros_like(a)
    h, w = a.shape
    ys = slice(max(dy, 0), h + min(dy, 0)); yd = slice(max(-dy, 0), h + min(-dy, 0))
    xs = slice(max(dx, 0), w + min(dx, 0)); xd = slice(max(-dx, 0), w + min(-dx, 0))
    out[ys, xs] = a[yd, xd]
    return out


MASK = np.array(silhouette_mask()) / 255.0


def frame(face, seed, blink=False):
    rng = np.random.default_rng(seed)
    m = MASK.copy()
    yy, xx = np.mgrid[0:H, 0:W]
    # interior: almost black, faint scanlines + grain (seen through a screen)
    lum = 0.035 + rng.normal(0, 0.012, (H, W))
    lum *= np.where((yy % 4) < 2, 1.0, 0.6)
    band = rng.uniform(100, 700)
    lum += 0.03 * np.exp(-((yy - band) / 14) ** 2)
    # rim light from behind-right: edges facing up/right glow, plus a faint full outline
    rim_r = np.clip(m - shift(m, -7, 5), 0, 1)
    rim_all = np.clip(m - np.array(Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.MinFilter(5))) / 255.0, 0, 1)
    rim = rim_r * 0.9 + rim_all * 0.10
    rim = np.array(Image.fromarray((np.clip(rim, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.2))) / 255.0
    # faint inner hints: coat lapels + headphone band (very subtle)
    hint = Image.new("L", (W, H), 0)
    hd = ImageDraw.Draw(hint)
    hd.line([(268, 470), (300, 560), (332, 470)], fill=60, width=3)
    hd.arc([238, 360, 362, 452], 20, 160, fill=70, width=4)
    lum = lum + np.array(hint.filter(ImageFilter.GaussianBlur(1.5))) / 255.0 * 0.5

    # face: only light points / lines, nothing else readable
    f = Image.new("L", (W, H), 0)
    fd = ImageDraw.Draw(f)
    lx, rx, ey = 262, 338, 262
    if face == "normal" and not blink:
        fd.ellipse([lx - 5, ey - 3, lx + 5, ey + 3], fill=255)
        fd.ellipse([rx - 5, ey - 3, rx + 5, ey + 3], fill=255)
    elif face == "normal" and blink:
        pass
    elif face == "smile":
        fd.arc([lx - 12, ey - 6, lx + 12, ey + 8], 200, 340, fill=255, width=3)
        fd.arc([rx - 12, ey - 6, rx + 12, ey + 8], 200, 340, fill=255, width=3)
        fd.arc([238, 270, 362, 336], 25, 155, fill=220, width=3)
    elif face == "glitch":
        o = int(rng.integers(-10, 10))
        fd.ellipse([lx - 5, ey - 3, lx + 5, ey + 3], fill=255)
        fd.ellipse([rx - 5 + o, ey - 8, rx + 5 + o, ey - 2], fill=255)
    fa = np.array(f) / 255.0
    fg = np.array(f.filter(ImageFilter.GaussianBlur(6))) / 255.0

    light = np.clip(lum + rim * 0.9 + fa * 1.0 + fg * 0.8, 0, 1.3)
    rgb = light[..., None] * G[None, None, :]
    base_dark = np.array([8, 7, 14], float)
    rgb = base_dark * (1 - np.clip(light * 3, 0, 1))[..., None] + rgb
    rgb[..., 0] += np.clip(light - 0.85, 0, 1) * 150
    rgb[..., 2] += np.clip(light - 0.85, 0, 1) * 110

    alpha = m.copy()
    # body dissolves into darkness toward the bottom
    alpha *= np.clip((H - 20 - yy) / 160, 0, 1)
    # soft green halo behind the figure (the screen he sits in front of)
    halo = np.array(Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(28))) / 255.0
    halo = halo * np.clip((H - 120 - yy) / 260, 0, 1) * 0.16
    tint = G if face != "glitch" else np.array([210, 90, 120], float)
    out_rgb = rgb * alpha[..., None] + tint * halo[..., None] * (1 - alpha[..., None])
    out_a = np.clip(alpha + halo * (1 - alpha), 0, 1)
    out_rgb = out_rgb / np.maximum(out_a, 1e-4)[..., None]

    if face == "glitch":
        for _ in range(6):
            y0 = int(rng.integers(80, H - 120)); h = int(rng.integers(4, 16)); s = int(rng.integers(-36, 36))
            out_rgb[y0:y0 + h] = np.roll(out_rgb[y0:y0 + h], s, axis=1)
            out_a[y0:y0 + h] = np.roll(out_a[y0:y0 + h], s, axis=0 if False else 1)
        y0 = int(rng.integers(150, 450)); x0 = int(rng.integers(180, 360))
        out_rgb[y0:y0 + 12, x0:x0 + 64] = [200, 40, 60]; out_a[y0:y0 + 12, x0:x0 + 64] = 1
        out_rgb[..., 0] = np.roll(out_rgb[..., 0], 5, axis=1)

    arr = np.dstack([np.clip(out_rgb, 0, 255), np.clip(out_a, 0, 1) * 255]).astype(np.uint8)
    return Image.fromarray(arr, "RGBA")


if __name__ == "__main__":
    off = {"normal": 0, "smile": 100, "glitch": 200}
    for face in ("normal", "smile", "glitch"):
        for k, s in enumerate((11, 23, 37)):
            frame(face, s + off[face]).save(f"{OUT}/zero_{face}_{k}.png", optimize=True)
    frame("normal", 5, blink=True).save(f"{OUT}/zero_normal_blink.png", optimize=True)
    print("ok")
