"""Mysterious CRT for '???': dark monitor emerging from shadow, glowing screen, static, unreadable face.
Renders several frames per expression so the game can animate static and blinking."""
import sys, os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)
W, H = 560, 560
SX0, SY0, SX1, SY1 = 108, 112, 452, 362          # screen area
G = np.array([110, 255, 180])                     # phosphor green


def rr_mask(box, r, size=(W, H), blur=0):
    m = Image.new("L", size, 0)
    ImageDraw.Draw(m).rounded_rectangle(box, radius=r, fill=255)
    return m.filter(ImageFilter.GaussianBlur(blur)) if blur else m


def body():
    """Dark case: nearly black, lit only by the screen's green spill along the inner bezel and top edge."""
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    case = rr_mask((60, 70, 500, 430), 46)
    # vertical gradient: case fades into darkness toward the bottom
    y = np.linspace(0, 1, H)[:, None] * np.ones((1, W))
    fade = np.clip(1.25 - y * 1.1, 0, 1)
    a = (np.array(case) / 255.0) * fade
    col = np.zeros((H, W, 3)); col[...] = (14, 12, 22)
    # green spill on case, strongest near the screen
    yy, xx = np.mgrid[0:H, 0:W]
    d = np.hypot((xx - W / 2) / 260, (yy - 237) / 190)
    spill = np.clip(1 - d, 0, 1) ** 2 * 0.35
    col = col + spill[..., None] * G * 0.35
    # top edge rim light
    rim = np.array(rr_mask((60, 70, 500, 430), 46)) / 255.0 - np.array(rr_mask((60, 76, 500, 436), 46)) / 255.0
    col = col + np.clip(rim, 0, 1)[..., None] * np.array([22, 44, 38])
    # deep inner bezel (shadow ring around screen)
    bez = np.array(rr_mask((SX0 - 22, SY0 - 22, SX1 + 22, SY1 + 22), 34, blur=6)) / 255.0
    col = col * (1 - bez[..., None] * 0.6)
    arr = np.dstack([np.clip(col, 0, 255), a * 255]).astype(np.uint8)
    im = Image.fromarray(arr, "RGBA")
    d = ImageDraw.Draw(im)
    # vents (barely visible) and the cable falling into darkness
    for i in range(7):
        d.line([(128 + i * 14, 396), (128 + i * 14, 410)], fill=(30, 40, 40, 160), width=3)
    cable = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    cd = ImageDraw.Draw(cable)
    pts = [(300, 425), (308, 455), (300, 490), (318, 530), (312, 560)]
    cd.line(pts, fill=(20, 22, 30, 255), width=7, joint="curve")
    cfade = np.array(cable)
    cfade[..., 3] = (cfade[..., 3] * np.clip(1.4 - np.linspace(0, 1, H) * 1.3, 0, 1)[:, None]).astype(np.uint8)
    im = Image.alpha_composite(Image.fromarray(cfade), im)
    return im


def screen(face, seed, blink=False):
    rng = np.random.default_rng(seed)
    sw, sh = SX1 - SX0, SY1 - SY0
    yy, xx = np.mgrid[0:sh, 0:sw]
    # base: dark phosphor with a dim glow in the middle (curved-glass vignette)
    d = np.hypot((xx - sw / 2) / (sw / 2), (yy - sh / 2) / (sh / 2))
    base = 0.10 + 0.16 * np.clip(1 - d, 0, 1)
    base *= np.clip(1.25 - d ** 3 * 0.6, 0, 1)
    # static grain + rolling band (position differs per frame)
    base += rng.normal(0, 0.035, (sh, sw))
    band_y = rng.uniform(0, sh)
    base += 0.05 * np.exp(-((yy - band_y) / 10) ** 2)
    # face layer drawn separately, then bloomed
    f = Image.new("L", (sw, sh), 0)
    fd = ImageDraw.Draw(f)
    cx, cy = sw / 2, sh / 2 - 8
    ex = 62
    if face == "normal":
        if blink:
            fd.line([(cx - ex - 30, cy + 4), (cx - ex + 30, cy + 4)], fill=150, width=3)
            fd.line([(cx + ex - 30, cy + 4), (cx + ex + 30, cy + 4)], fill=150, width=3)
        else:
            # two narrow horizontal slits: watching, unreadable, no mouth
            fd.rounded_rectangle([cx - ex - 32, cy - 4, cx - ex + 32, cy + 8], 6, fill=255)
            fd.rounded_rectangle([cx + ex - 32, cy - 4, cx + ex + 32, cy + 8], 6, fill=255)
    elif face == "smile":
        # eyes become thin arcs, and a mouth that is a little too wide
        # narrow arc eyes and a thin mouth stretched almost to the screen edges: polite, but wrong
        fd.arc([cx - ex - 24, cy - 4, cx - ex + 24, cy + 18], 205, 335, fill=255, width=4)
        fd.arc([cx + ex - 24, cy - 4, cx + ex + 24, cy + 18], 205, 335, fill=255, width=4)
        fd.arc([cx - 150, cy - 70, cx + 150, cy + 78], 32, 148, fill=230, width=3)
    elif face == "glitch":
        off = rng.integers(-14, 14)
        fd.rounded_rectangle([cx - ex - 32, cy - 4, cx - ex + 32, cy + 8], 6, fill=255)
        fd.rounded_rectangle([cx + ex - 32 + off, cy - 10, cx + ex + 32 + off, cy + 2], 6, fill=255)
    fa = np.array(f) / 255.0
    glow = np.array(f.filter(ImageFilter.GaussianBlur(9))) / 255.0
    lum = np.clip(base + fa * 0.95 + glow * 0.55, 0, 1.2)
    # scanlines
    lum *= np.where((yy % 4) < 2, 1.0, 0.72)
    rgb = np.clip(lum[..., None] * G[None, None, :] * 1.0, 0, 255)
    rgb[..., 0] += np.clip(lum - 0.85, 0, 1) * 160   # hot core toward white
    rgb[..., 2] += np.clip(lum - 0.85, 0, 1) * 120
    if face == "glitch":
        # horizontal tears: shift strips sideways, red static block
        for _ in range(5):
            y0 = rng.integers(0, sh - 12); h = rng.integers(3, 12); s = rng.integers(-40, 40)
            rgb[y0:y0 + h] = np.roll(rgb[y0:y0 + h], s, axis=1)
        y0 = rng.integers(20, sh - 40); x0 = rng.integers(10, sw - 90)
        rgb[y0:y0 + 14, x0:x0 + 70] = [200, 40, 60]
        # chromatic split
        rgb[..., 0] = np.roll(rgb[..., 0], 4, axis=1)
    rgb = np.clip(rgb, 0, 255).astype(np.uint8)
    scr = Image.fromarray(rgb, "RGB").convert("RGBA")
    mask = rr_mask((0, 0, sw - 1, sh - 1), 26, size=(sw, sh))
    scr.putalpha(mask)
    return scr


def compose(face, seed, blink=False):
    im = body()
    # light halo spilling from the screen into the dark around the monitor
    halo = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    hm = rr_mask((SX0 - 30, SY0 - 30, SX1 + 30, SY1 + 30), 60, blur=46)
    tint = (110, 255, 180) if face != "glitch" else (200, 120, 140)
    halo = Image.new("RGBA", (W, H), tint + (0,))
    halo.putalpha(hm.point(lambda v: int(v * 0.33)))
    out = Image.alpha_composite(halo, im)
    out.alpha_composite(screen(face, seed, blink), (SX0, SY0))
    # glass glare
    g = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(g).ellipse([SX0 + 20, SY0 + 10, SX0 + 150, SY0 + 70], fill=(255, 255, 255, 18))
    out = Image.alpha_composite(out, g.filter(ImageFilter.GaussianBlur(10)))
    # red recording LED (it is watching)
    led = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ld = ImageDraw.Draw(led)
    ld.ellipse([423, 393, 437, 407], fill=(255, 50, 60, 255))
    led = Image.alpha_composite(led.filter(ImageFilter.GaussianBlur(5)), led)
    out = Image.alpha_composite(out, led)
    return out


if __name__ == "__main__":
    for face in ("normal", "smile", "glitch"):
        for k, s in enumerate((11, 23, 37)):
            compose(face, s + {"normal": 0, "smile": 100, "glitch": 200}[face]).save(f"{OUT}/zero_{face}_{k}.png", optimize=True)
    compose("normal", 5, blink=True).save(f"{OUT}/zero_normal_blink.png", optimize=True)
    print("ok")
